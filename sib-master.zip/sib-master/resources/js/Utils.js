export default {
    objectToModel(model, object){
        const keys = object.getAllKeys();
        for(let key in keys){
            let model = new model();
        }
    }
}
