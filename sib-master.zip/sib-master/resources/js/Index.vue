<template>
    <div id="app" class="wrapper">
        <Sidebar v-if="showMenu" background="#ff0125" :hide="hideMenu" @change-state="hideMenu = $event" :menu="menu">
            <template slot="header">
                <h3>{{ this.user.name }}</h3>
                <h6>Año {{ year }} <a href="#" style="font-size: 0.6rem" @click="selectYearOpen = true">Cambiar</a></h6>
            </template>
        </Sidebar>
        <div class="w-100">
            <div class="container-fluid px-0" v-if="showMenu">
                <Nav class="bg-white shadow" >

                    <template slot="end">

                        <Notifications class="d-inline-block"></Notifications>
                        <div class="dropdown text-right d-inline-block">
                            <button class="btn dropdown-toggle" type="button" id="userMenu" data-toggle="dropdown">
                                <span class="w-50 d-inline-block text-left breakSpace align-top">{{ this.user.name }}</span>
                                <Avatar class="position-relative d-inline-block w-50" :src="'/avatar/' + this.user.id" alt="" />

                            </button>
                            <div class="dropdown-menu">
                                <router-link class="dropdown-item" to="/profile">Perfil</router-link>
                                <a class="dropdown-item" href="#" @click="logout">Cerrar sesión</a>
                            </div>
                        </div>
                    </template>
                </Nav>
            </div>
            <SelectYear @open="selectYearOpen = true" @setYear="reload" :open="selectYearOpen"></SelectYear>
            <router-view @onData="onData($event)"/>
        </div>
    </div>
</template>

<script>
import Sidebar from './components/Sidebar/index';
import CollapseItem from './components/Sidebar/CollapseItem/Index';
import Nav from './components/Nav/index';
import Avatar from './components/Avatar';
import SelectYear from './components/SelectYear';
import Notifications from './components/Notifications'
import AddActivity from "./components/Budget/AddActivity";
import menu from "./menu";
import axios from "axios";

export default {
    name: 'App',
    data(){
        return {
            showMenu: true,
            hideMenu: false,
            selectYearOpen: false,
            user: {},
            menu: [],
            menu2: [],
        }
    },
    components: {
        Sidebar,
        Nav,
        Avatar,
        CollapseItem,
        Notifications,
        SelectYear,
        AddActivity
    },
    methods: {
        onData(data){
            this.$set(this, data.key, data.value);
        },
        logout(){
            localStorage.clear();
            this.$router.push("/");
        },
        reload(){
            this.$router.go();
        },
        async permissionModule(module){
            return await axios.post("/api/canSee", {
                module: module
            }, {
                headers: {
                    Accept: 'application/json',
                    Authorization: 'Bearer ' + localStorage.autenticate_token
                }
            })
            .then(response => {
                if(response.data.can){
                    return true;
                }else{
                    return false;
                }
            })
            .catch(error => {
                return false;
            })
        }
    },
    computed: {
        year(){
            return localStorage.year ? localStorage.year : "Sin seleccionar"
        }
    },
    mounted() {
        if(localStorage.autenticate_token !== undefined){
            this.user = JSON.parse(localStorage.user);
            this.menu = menu.principal;
            /*menu.principal.map(item => {
                if(item.permission != undefined || item.subs != undefined){
                    if(item.permission){
                        this.permissionModule(item.title);
                    }else{
                        let newSubs = [];
                        item.subs.map(async sub => {
                            console.log(this.permissionModule(sub.title));
                        })
                        console.log("despues")
                    }


                }else{
                    this.menu2.push(item);
                }
            })*/
        }
        setInterval(() => {
            if(localStorage.user !== undefined){
                this.user = JSON.parse(localStorage.user);
            }
        }, 1000);
    }
}
</script>

<style>
    .wrapper {
        display: flex;
        width: 100%;
        align-items: stretch;
    }
    #userMenu{
        width: 150px;
        max-width: 150px;
    }
    .breakSpace{
        white-space: break-spaces;
    }
</style>
