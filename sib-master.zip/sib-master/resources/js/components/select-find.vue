<template>
    <div class="selectFind form-control" :class="{open: isOpen}">
        <input type="hidden" v-model="selectedValue">
        <div class="selected" @click="openToggle">
            {{ selected.text }}
        </div>
        <div class="list">
            <input type="text" class="form-control" v-model="find">
            <ul class="list-group list-group-flush">
                <template v-if="items.length > 0">
                    <template v-for="(item, index) in items" v-if="index <= length">
                        <li class="list-group-item" @click="setSelected(item)">{{item.text}}</li>
                    </template>
                </template>
                <template v-else-if="find != '' && this.ajaxCreate != null">
                    <li class="list-group-item" @click="createItem">Crear categoria <strong>{{ find }}</strong></li>
                </template>
            </ul>
        </div>
    </div>
</template>
<script>
import axios from "axios";
import jQuery from "jquery";
export default {
    data: function(){
        return {
            items: [],
            find: "",
            selectedValue: null
        }
    },
    props: {
        selected: {
            default: () => {
                return {
                    id: 0,
                    text: ""
                }
            }
        },
        isOpen: {
            default: false
        },
        ajax: {
            default: null
        },
        ajaxCreate: {
            default: null
        },
        ajaxUpdate: {
            default: null
        },
        length: {
            default: 10
        },
        page: {
            default: 1
        }
    },
    methods: {
        openToggle(){
            this.isOpen = !this.isOpen;
        },
        close(e){
            for(let index in e.path){
                console.log(e.path[index]);
            }
            this.isOpen = false;
        },
        setSelected(item){
            this.selected = item;
            this.selectedValue = item.id;
            this.isOpen = false;
            if(this.ajaxUpdate != null){
                this.updateItem()
            }
        },
        getItems(){
            let params = {
                length: this.length,
                page: this.page,
                find: this.find
            };

            axios.get(this.ajax, {
                params: params
            })
            .then(response => {
                this.items = response.data.data;
            })
        },
        createItem(){
            axios.post(this.ajaxCreate, {
                name: this.find
            })
            .then(response => {
                this.isOpen = false;
            })
            .catch(error => {
                this.isOpen = false;
            })
        },
        updateItem(){
            axios.post(this.ajaxUpdate, {
                category: this.selected.id
            })
            .then(response => {
                this.isOpen = false;
                this.$emit("update", this.selected);
            })
            .catch(error => {
                this.isOpen = false;
            })
        }
    },
    watch:{
        find(value){
            this.getItems();
        },
        selected(value){
            this.selectedValue = value.id;
            this.items.map(item => {
                if(item.id == value.id){
                    this.$set(this, "selected", item);
                    console.log(item, "se")
                }
            })
        }
    },
    mounted() {
        let offset = jQuery(this.$el).offset();
        jQuery(this.$el).find(".list").css({
            top: (offset.top + jQuery(this.$el).outerHeight()) + "px",
            left: offset.left + "px",
            width: jQuery(this.$el).outerWidth() + "px"
        })
        if(this.ajax != null) {
            this.getItems()
        }
        this.selectedValue = this.selected.id;
    }
}
</script>
<style>
.selectFind {
    /*position: relative;*/
}

.selected:after {
    content: "expand_more";
    position: absolute;
    top: 0%;
    right: 0%;
    font-family: 'Material Icons';
    font-size: 20px;
}

.list {
    position: fixed;
    min-height: 100px;
    background-color: #fff;
    z-index: 1000;
    border: 1px solid #e3e6e9;
    border-radius: 5px;
}

.selectFind:not(.open) .list {
    display: none;
}
li{
    cursor: pointer;
}
li:hover {
    cursor: pointer;
    background-color: rgb(255 0 0 / 50%);
    color: #fff;
}

</style>
