<template>
    <div class="container py-4">
        <div class="row">
            <div class="col-12">
                <h3 class="title">{{ title }}</h3>
            </div>
        </div>
        <div class="card">
            <div class="card-head pt-4">
                <slot name="head"></slot>
            </div>
            <div class="card-body">
                <slot name="body" v-if="authorized"></slot>
            </div>
        </div>
        <PageLoad :state="page.state"
                  :depends="page.depends"
                  @refresh="getPage"
                  @page-changes="pageChanges($event)"></PageLoad>
    </div>
</template>

<script>
import PageLoad from '../components/PageLoad';

export default {
    props: {
        title: {
            type: String,
            default: ""
        },
        page: {
            type: Object,
            default(){
                return {
                    state: 0
                }
            }
        },
        authorized: {
            type: Boolean,
            default: 0
        },
        getPage: {
            type: Function,
            default: () => {
                return false
            }
        }
    },
    components: {
        PageLoad
    },
    methods: {
        pageChanges(data){
            const keys = data.getAllKeys();
            for(let key in keys){
                this.$set(this.$parent.page, keys[key], data[keys[key]]);
            }
        }
    }
}
</script>
