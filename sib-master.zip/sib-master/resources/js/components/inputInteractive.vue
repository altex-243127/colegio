<template>
    <div class="input-group mb-3" :class="{ 'border border-success' : (this.state == 1),  'border border-danger' : (this.state == 2)  }">
        <div class="input-group-prepend" v-if="icon != ''">
            <span class="input-group-text">
                <i class="material-icons">{{ icon }}</i>
            </span>
        </div>
        <template v-if="type == 'select'">
            <select class="form-control" v-model="value">
                <option value="">{{ label }}</option>
                <template v-if="items.length > 0">
                    <template v-for="item in items">
                        <option :value="item.value">{{ item.label }}</option>
                    </template>
                </template>
            </select>
        </template>
        <input v-else :type="type" class="form-control" :placeholder="label" v-model="value">
    </div>
</template>
<script>
import axios from "axios";
import jQuery from "jquery";
export default {
    data(){
        return {
            value: "",
            state: 0
        }
    },
    props:{
        label: {
            default: ""
        },
        valueDefault: {
            default: ""
        },
        icon: {
            default: ""
        },
        type: {
            default: "text"
        },
        url: {
            default: ""
        },
        optionRequest: {
            default(){
                return {}
            }
        },
        items: {
            default() {
                return [];
            }
        }
    },
    methods: {
        update(){
            axios.post(this.url, {
                value: this.value
            }, this.optionRequest)
            .then(response => {
                console.log(response, "success");
                this.state = 1;
                setTimeout(() => {
                    this.state = 0;
                }, 1000)
            })
            .catch(error => {
                console.log(error)
                this.state = 2
            })
        }
    },
    mounted() {
        this.value = this.valueDefault;
        jQuery(this.$el).on("change", (e) => {
            this.update();
        })
    }
}
</script>
