<template>
    <div class="modal fade" data-keyboard="false" data-backdrop="static">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Nuevo grupo de interes</h5>
                    <button type="button" class="close" @click="close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row" v-if="message.value.length > 0">
                        <div class="col">
                            <p class="p-2" :class="'alert-' + message.type" v-for="value in message.value">
                                {{ value }}
                            </p>
                        </div>
                    </div>
                    <div class="row py-2">
                        <div class="col-12">
                            <label>Categoria</label>
                            <select class="form-control" v-model="category">
                                <template v-for="$category in categories">
                                    <option :value="$category.id">{{ $category.name }}</option>
                                </template>
                            </select>
                        </div>
                    </div>
                    <div class="row py-2">
                        <div class="col-12">
                            <label>Grupo de interes</label>
                            <input type="text" class="form-control" v-model="name">
                        </div>
                    </div>
                    <div class="row py-2">
                        <div class="col-12">
                            <label>Grado de poder</label>
                            <div class="row m-0">
                                <div class="form-check col">
                                    <input class="form-check-input" id="power1" type="radio" :value="1" v-model="power">
                                    <label class="form-check-label" for="power1">
                                        Alto
                                    </label>
                                </div>
                                <div class="form-check col">
                                    <input class="form-check-input" id="power2" type="radio" :value="0" v-model="power">
                                    <label class="form-check-label" for="power2">
                                        Bajo
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row py-2">
                        <div class="col-12">
                            <label>Grado de interes</label>
                            <div class="row m-0">
                                <div class="form-check col">
                                    <input class="form-check-input" id="intrest1" type="radio" :value="1" v-model="interest">
                                    <label class="form-check-label" for="intrest1">
                                        Alto
                                    </label>
                                </div>
                                <div class="form-check col">
                                    <input class="form-check-input" id="intrest2" type="radio" :value="0" v-model="interest">
                                    <label class="form-check-label" for="intrest2">
                                        Bajo
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <label>Necesidades</label>
                            <select class="form-control" v-model="selectNeed">
                                <option value=""></option>
                                <template v-for="need in needs">
                                    <option :value="need.id">{{ need.name }}</option>
                                </template>
                                <template v-for="otherNeed in othersNeeds">
                                    <option :value="otherNeed">{{ otherNeed }}</option>
                                </template>
                                <option value="otherNeed">Otro</option>
                            </select>
                            <div class="input-group my-3" v-if="selectNeed == 'otherNeed'">
                                <input type="text" class="form-control" placeholder="Otro" v-model="otherNeedText">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <label>Expectativas</label>
                            <select class="form-control" v-model="selectExpectation">
                                <option value=""></option>
                                <template v-for="expectation in expectations">
                                    <option :value="expectation.id">{{ expectation.name }}</option>
                                </template>
                                <template v-for="otherExpectation in othersExpectations">
                                    <option :value="otherExpectation">{{ otherExpectation }}</option>
                                </template>
                                <option value="otherExpectation">Otro</option>
                            </select>
                            <div class="input-group my-3" v-if="selectExpectation == 'otherExpectation'">
                                <input type="text" class="form-control" placeholder="Otro" v-model="otherExpectationText">
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-12">
                            <label>Area encargada</label>
                            <select class="form-control" v-model="selectArea">
                                <option value=""></option>
                                <template v-for="area in areas">
                                    <option :value="area.id">{{ area.name }}</option>
                                </template>
                            </select>
                        </div>
                    </div>

                    <div class="row py-2">
                        <div class="col-12">
                            <div class="row m-0">
                                <div class="form-check col">
                                    <input class="form-check-input" id="required" type="checkbox" :value="1" v-model="required">
                                    <label class="form-check-label" for="required">
                                        Es requerido
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>


                    <div class="row py-2">
                        <div class="col-12">
                            <label>Riesgo / Oportunidad</label>
                            <div class="row m-0">
                                <div class="form-check col">
                                    <input class="form-check-input" id="risk1" type="radio" :value="1" v-model="risk">
                                    <label class="form-check-label" for="risk1">
                                        Riesgo
                                    </label>
                                </div>
                                <div class="form-check col">
                                    <input class="form-check-input" id="risk2" type="radio" :value="0" v-model="risk">
                                    <label class="form-check-label" for="risk2">
                                        Oportunidad
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary w-25" @click="close">Cerrar</button>
                    <button type="button" class="btn btn-red w-25" @click="save">Añadir</button>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import jQuery from "jquery";
    import Axios from "axios";

    export default {
        data(){
            return {
                category: 0,
                name: "",
                power: 0,
                interest: 0,
                selectNeed: 0,
                othersNeeds: [],
                selectArea: 0,
                otherNeedShow: false,
                otherNeedText: "",
                selectExpectation: 0,
                othersExpectations: [],
                otherExpectationShow: false,
                otherExpectationText: "",
                required: false,
                risk: 1,
                message: {
                    type: "success",
                    value: []
                }
            }
        },
        props: {
            show: {
                type: Boolean,
                default: false
            },
            categories: {
                type: Array,
                default: []
            },
            needs: {
                type: Array,
                default(){
                    return []
                }
            },
            expectations: {
                type: Array,
                default(){
                    return []
                }
            },
            areas: {
                type: Array,
                default(){
                    return []
                }
            }
        },
        methods: {
            setOtherNeed(){
                if(this.otherNeedText != ''){
                    this.othersNeeds.push(this.otherNeedText);
                    this.$set(this, "selectNeed", this.otherNeedText);
                    this.otherNeedText = "";
                    this.otherNeedShow = false;
                }else{
                    this.message.value.push("El campo otro es requerido");
                }
            },
            setOtherExpectation(){
                if(this.otherExpectationText != ''){
                    this.othersExpectations.push(this.otherExpectationText);
                    this.$set(this, "selectExpectation", this.otherExpectationText);
                    this.otherExpectationText = "";
                    this.otherExpectationShow = false;
                }else{
                    this.message.value.push("El campo otro es requerido");
                }
            },
            close() {
                this.$emit("close");
                this.category = 0;
                this.name = "";
                this.power = 0;
                this.interest = 0;
                this.selectNeed = 0;
                this.selectArea = 0;
                this.otherNeedText = "";
                this.selectExpectation = 0;
                this.otherExpectationText = "";
                this.required = false;
                this.risk = 1;
            },
            validated(){
                let errors = 0;
                this.message.value = [];
                if(this.category == 0){
                    this.message.value.push("El campo categoria es obligatorio");
                    errors += 1;
                }
                if(this.name == 0){
                    this.message.value.push("El campo grupo de interes es obligatorio");
                    errors += 1;
                }
                if(this.selectNeed == 0){
                    this.message.value.push("El campo nesesidades es obligatorio");
                    errors += 1;
                }else if(this.selectNeed == "otherNeed"){
                    if(this.otherNeedText == ""){
                        this.message.value.push("El campo otro (necesidad) es obligatorio");
                        errors += 1;
                    }
                }
                if(this.selectExpectation == 0){
                    this.message.value.push("El campo expectativas es obligatorio");
                    errors += 1;
                }else if(this.selectExpectation == "otherExpectation"){
                    if(this.otherExpectationText == ""){
                        this.message.value.push("El campo otro (Expectativa) es obligatorio");
                        errors += 1;
                    }
                }

                if(errors > 0){
                    this.message.type = "danger";
                    return false;
                }
                return true;
            },
            save(){
                if(!this.validated()){
                    return;
                }
                Axios.post("/api/InterestGroups", {
                    category_id: this.category,
                    name: this.name,
                    power: this.power,
                    interest: this.interest,
                    required: this.required ? 1 : 0,
                    need: this.selectNeed == "otherNeed" ? this.otherNeedText : this.selectNeed,
                    expectation: this.selectExpectation == "otherExpectation" ? this.otherExpectationText : this.selectExpectation,
                    risk: this.risk,
                    area_id: this.selectArea
                }, {
                    headers: {
                        Accept: 'application/json',
                        Authorization: 'Bearer ' + localStorage.autenticate_token
                    }
                }).then(response => {
                    this.$set(this.message, "type", "success");
                    this.message.value.push(response.data.message);
                    setTimeout(() => {
                        this.$emit("new-group");
                        this.close();
                        this.reset();
                    }, 1000)
                }).catch(error => {
                    this.$set(this.message, "type", "danger");
                    if(error.response.status == 406){
                        for(let i in error.response.data.message){
                            this.message.value.push(error.response.data.message[i])
                        }
                    }else{
                        this.message.value.push("No fue posible");
                    }
                })
            },
            reset(){
                this.category = 0;
                this.name = "";
                this.power = 0;
                this.interest = 0;
                this.selectNeed = 0;
                this.selectExpectation = 0;
                this.required = false;
                this.risk = 1;
                this.$set(this, "message", {
                    type: "success",
                    value: []
                });
            }
        },
        watch: {
            show(value) {
                if (value) {
                    jQuery(this.$el).modal("show");
                } else {
                    jQuery(this.$el).modal("hide");
                }
            }
        },
        mounted() {
            if(this.show)
                jQuery(this.$el).modal("show");
        }
    }
</script>
