<template>
    <div class="row justify-content-between m-0">
        <div class="col">
            <slot name="start"></slot>
        </div>
        <div class="col">
            <slot name="center"></slot>
        </div>
        <div class="col">
            <slot name="end"></slot>
        </div>
    </div>
</template>

<script>
export default {
    name: "Nav",
}
</script>
