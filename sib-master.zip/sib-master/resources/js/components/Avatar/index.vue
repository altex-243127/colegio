<template>
    <div :id="id" class="avatar-vue">
        <div class="avatar-content" :style="avatarContentStyle"></div>
        <slot name="otherContent"></slot>
    </div>
</template>

<script>
export default {
    data(){
        return {
            id: '',
            el: null,
            width: 0
        }
    },
    props: {
        src: {
            type: String,
            default: ""
        },
        alt: {
            type: String,
            default: ""
        }
    },
    methods: {
        resizeWindows(){
            this.$forceUpdate();
        }
    },
    computed: {
        avatarContentStyle(){
            if(this.id == ''){
                return '';
            }
            return {
                minHeight: this.width + 'px',
                backgroundImage: 'url(' + this.src + ')',
                backgroundSize: 'cover',
                backgroundPosition: 'center'
            }
        }
    },
    updated(){
        this.id = 'avatar_' + this._uid;
        this.el = document.getElementById(this.id);
        this.width = this.el.offsetWidth;
    },
    mounted() {
        this.id = 'avatar_' + this._uid;
        this.el = document.getElementById(this.id);
        window.addEventListener("resize", this.resizeWindows)
    }
}
</script>

<style scoped>
    .avatar-vue{
        width: 100%;
    }

    .avatar-content{
        border-radius: 50%;
    }

</style>
