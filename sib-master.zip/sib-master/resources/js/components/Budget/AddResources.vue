<template>
    <div class="modal fade" id="addResources" tabindex="-1" role="dialog">
        <div class="modal-dialog  modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header alert">
                    <h5 class="modal-title">Añadir recursos</h5>
                    <button type="button" class="close" @click="close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body" v-if="Object.keys(budget).length > 0">

                    <div class="row">
                        <div class="col-12">
                            <h5>Objetivo</h5>
                            <p>{{ budget.objective.objective }}</p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <h5>Estrategia</h5>
                            <p>{{ budget.strategy.name }}</p>
                        </div>
                    </div>

                    <div class="row" v-if="message.value != ''">
                        <div class="col">
                            <p class="p-2" :class="'alert-' + message.type">
                                {{ message.value }}
                            </p>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <add-activity v-for="(activity, index) in activities"
                                      @remove="removeActivity($event)"
                                      @set-activity="setActivity($event)"
                                      :finalized="finalized"
                                      :key="index"
                                      :index="index"
                                      :activity="activity">
                        </add-activity>
                    </div>


                    <div class="row" v-if="!finalized">
                        <div class="col-12 text-right">
                            <button type="button" class="btn btn-red text-white" @click="addActivity">
                                <i class="fa fa-plus"></i> Nueva actividad
                            </button>
                        </div>
                    </div>

                </div>
                <div class="modal-footer">
                    <div class="w-100">
                        <div class="row justify-content-end">
                            <div class="col-6">
                                <button type="button" class="btn btn-secondary w-100"  @click="close">Cerrar</button>
                            </div>
                            <div class="col-6" v-if="!finalized">
                                <button type="button" class="btn btn-success w-100" @click="save">Guardar</button>
                            </div>
                        </div>
                    </div>


                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import jQuery from 'jquery'
    import Axios from 'axios';
    import AddActivity from "./AddActivity";

    export default {
        name: "addResources",
        components: {
            AddActivity
        },
        data(){
            return {
                activities: [],
                message: {
                    type: "danger",
                    value: ""
                },
            }
        },
        props: {
            show: {
                type: Boolean,
                default: false
            },
            budget: {
                type: Object,
                default(){
                    return {}
                }
            },
            finalized: {
                type: Boolean,
                default: false
            }
        },
        watch: {
            show(value){
                jQuery(this.$el).modal(value ? "show" : "hide");
            },
            budget(value){
                this.activities = value.activities;
            }
        },
        methods: {
            close(){
                this.$emit('close');
            },
            removeActivity(index){
                this.activities = this.activities.filter((item, key) => {
                    return index != key;
                })
            },
            setActivity(data){
                this.$set(this.activities, data.index, data.activity);
            },
            addActivity(){
                this.message.value = "";
                if(this.validateActivities()){
                    this.activities.push({
                        action: "",
                        end_date: "",
                        start_date: "",
                        description: "",
                        executor: {},
                        office: {},
                        area_id: null,
                        responsable: {},
                        resources: []
                    });
                }else{
                    this.message.type = "danger";
                    this.message.value = "Todos los campos de la actividad son obligatorios";
                    jQuery(this.$el).scrollTop(0);
                }
            },
            validateActivities(){
                let errors = 0;
                this.activities.map(item => {
                    errors += this.validateActivity(item) ? 0 : 1;
                });
                console.log("validateActivities", errors);
                return errors == 0;
            },
            validateActivity(activity){
                let errors = 0;
                errors += activity.action == "" ? 1 : 0;
                errors += activity.dateEnd === "" ? 1 : 0;
                errors += activity.dateInit === "" ? 1 : 0;
                errors += activity.description == "" ? 1 : 0;
                errors += activity.executor.name === undefined ? 1 : 0;
                errors += activity.responsable.name === undefined ? 1 : 0;
                errors += activity.office.name === undefined ? 1 : 0;
                errors += this.validateResourcesActivity(activity) ? 0 : 1;
                return errors == 0;
            },
            validateResourcesActivity(activity){
                let errors = 0;
                if(activity.resources !== undefined){
                    activity.resources.map(item => {
                        errors += this.validateResource(item) ? 0 : 1;
                    });
                }
                console.log("validateResourcesActivity", errors);
                return errors == 0;
            },
            validateResource(resource){
                let errors = 0;
                errors += resource.quantity <= 0 ? 1 : 0;
                errors += resource.unit == "" ? 1 : 0;
                errors += resource.value <= 0 ? 1 : 0;
                errors += resource.description == "" ? 1 : 0;
                return errors == 0;
            },
            async save(){
                this.message.value = "";
                if(this.validateActivities() && this.activities.length > 0){
                    await Axios.post("/api/Budget/" + this.budget.id + "/activity", {
                        activities: this.activities
                    }, {
                        headers: {
                            Accept: 'application/json',
                            Authorization: 'Bearer ' + localStorage.autenticate_token
                        }
                    }).then(response => {
                        this.close();
                        this.$emit("success", response.data.message);

                    }).catch(error => {
                        this.close();
                        this.$emit("error", error.response.data.message);
                    })
                }else{
                    this.message.type = "danger";
                    this.message.value = "Todos los campos de la actividad son obligatorios";
                    jQuery(this.$el).scrollTop(0);
                }
            }
        }
    }
</script>
