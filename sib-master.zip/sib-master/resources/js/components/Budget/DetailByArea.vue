<template>
    <div class="modal fade" id="DetailBudget" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content" v-if="Object.keys(area).length > 0">
                <div class="modal-header alert">
                    <h5 class="modal-title">Detalle presupuesto area ({{ area.name }})</h5>
                    <button type="button" class="close" @click="close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row border-bottom border-primary mb-3" v-for="budget in area.budgets" >
                        <template v-if="budget.objective != undefined">
                        <div class="col-12">
                            <h5>Objetivo</h5>
                            <p>{{ budget.objective.objective }}</p>
                        </div>
                        <div class="col-12">
                            <h5>Estrategia</h5>
                            <p>{{ budget.strategy.name }}</p>
                        </div>
                        </template>
                        <template v-else>
                            <div class="col-12">
                                <h5>REF</h5>
                                <p>{{ budget.ref }}</p>
                            </div>
                        </template>
                        <div class="col-12">
                            <h5>Actividades</h5>
                            <hr>
                        </div>
                        <div class="col-12">
                            <template v-for="activity in budget.activities">
                                <div class="row mb-3" v-if="activity != null">
                                    <div class="col-4">
                                        <p><strong>Oficina</strong></p>
                                        <p>{{activity.office != null ? activity.office.name : "" }}</p>
                                    </div>
                                    <div class="col-4">
                                        <p><strong>Acción</strong></p>
                                        <p>{{activity.action}}</p>
                                    </div>
                                    <div class="col-4">
                                        <p><strong>Descripción</strong></p>
                                        <p>{{activity.description}}</p>
                                    </div>
                                    <div class="col-4">
                                        <p><strong>Responsable</strong></p>
                                        <p>{{activity.responsable != null ? activity.responsable.name : ""}}</p>
                                    </div>
                                    <div class="col-4">
                                        <p><strong>Ejecutor</strong></p>
                                        <p>{{activity.executor != null ? activity.executor.name : ""}}</p>
                                    </div>
                                    <div class="col-2">
                                        <p><strong>Fecha inicio</strong></p>
                                        <p>{{months[activity.start_date]}}</p>
                                    </div>
                                    <div class="col-2">
                                        <p><strong>Fecha fin</strong></p>
                                        <p>{{months[activity.end_date]}}</p>
                                    </div>

                                    <div class="col-12">
                                        <div class="table-responsive">
                                            <table class="table table-hover">
                                                <thead>
                                                <tr>
                                                    <th><p style="width: 150px">Descripción</p></th>
                                                    <th><p style="width: 70px">Cant</p></th>
                                                    <th><p style="width: 150px">Unidad</p></th>
                                                    <th><p style="width: 150px">Valor Unidad</p></th>
                                                    <th><p style="width: 150px">Valor total</p></th>
                                                    <th><p style="width: 150px">Cuenta contable</p></th>
                                                    <th><p style="width: 150px">Centro de costos</p></th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <template v-for="resource in activity.resources">
                                                    <tr>
                                                        <td>{{ resource.description }}</td>
                                                        <td>{{ resource.quantity }}</td>
                                                        <td>{{ resource.unit }}</td>
                                                        <td>{{ resource.value }}</td>
                                                        <td>{{ resource.quantity*resource.value }}</td>
                                                        <td>{{ resource.account }}</td>
                                                        <td>{{ resource.center_cost != null ? resource.center_cost.name : "" }}</td>
                                                    </tr>
                                                </template>
                                                </tbody>
                                            </table>
                                        </div>

                                    </div>

                                </div>
                            </template>
                        </div>

                        <div class="col-12 mb-3">
                            <button type="button" class="btn btn-success" @click="approve(budget)" v-if="budget.state == 0">
                                Aprobar
                            </button>
                            <button type="button" class="btn btn-red" @click="refuse(budget)" v-if="budget.state == 0">
                                Rechazar
                            </button>
                        </div>

                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-success" @click="close">Cerrar</button>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import Axios from 'axios';
    import jQuery from 'jquery';

    export default {
        name: "DetailBudget",
        data(){
            return {
                months: [
                    "Enero",
                    "Febrero",
                    "Marzo",
                    "Abril",
                    "Mayo",
                    "Junio",
                    "Julio",
                    "Agosto",
                    "Septiembre",
                    "Octubre",
                    "Noviembre",
                    "Diciembre"
                ],
            }
        },
        props: {
            show: {
                type: Boolean,
                default: false
            },
            area: {
                type: Object,
                default(){
                    return {}
                }
            }
        },
        watch: {
            show(value){
                if(Object.keys(this.area).length > 0){
                    jQuery(this.$el).modal(value ? "show" : "hide");
                }
            },
            area(value){
                if(value.extras != undefined){
                    this.$set(this.area, "budgets", value.extras);
                }
            }
        },
        methods: {
            close(){
                this.$emit('close');
            },
            approve(budget){
                let url = "/api/Budget/Approve/" + budget.id;
                if(this.area.extras != undefined){
                    url = "/api/Budget/ApproveExtra/" + budget.id;
                }
                Axios.post(url, {}, {
                    headers: {
                        Accept: 'application/json',
                        Authorization: 'Bearer ' + localStorage.autenticate_token
                    }
                })
                    .then(response => {
                        //this.close();
                        budget.state = 1;
                        this.$emit("success", {
                            title: "La operación se completo con éxito",
                            message: response.data.message,
                            type: "success"
                        })
                    })
                    .catch(error => {
                        //this.close();
                        this.$emit("error", {
                            title: "La operación no se pudo completar",
                            message: error.response.data.message,
                            type: "danger"
                        })
                    })
            },
            refuse(budget){
                let url = "/api/Budget/Refuse/" + budget.id;
                if(this.area.extras != undefined){
                    url = "/api/Budget/RefuseExtra/" + budget.id;
                }
                Axios.post(url, {}, {
                    headers: {
                        Accept: 'application/json',
                        Authorization: 'Bearer ' + localStorage.autenticate_token
                    }
                })
                    .then(response => {
                        //this.close();
                        budget.state = 2;
                        this.$emit("success", {
                            title: "La operación se completo con éxito",
                            message: response.data.message,
                            type: "success"
                        });
                    })
                    .catch(error => {
                        //this.close();
                        this.$emit("error", {
                            title: "La operación no se pudo completar",
                            message: error.response.data.message,
                            type: "danger"
                        })
                    })
            }
        }
    }
</script>
