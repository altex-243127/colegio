<template>
    <tr>
        <td>
            <p>{{ currentRecourse.description }}</p>
        </td>
        <td>
            <p>{{ currentRecourse.quantity }}</p>
        </td>
        <td>
            <p>{{ currentRecourse.unit }}</p>
        </td>
        <td>
            <p>{{ currentRecourse.value }}</p>
        </td>
        <td>
            <p class="text-center">{{valueTotal}}</p>
        </td>
        <td>
            <input type="text" class="form-control" v-model="currentRecourse.account" v-if="!finalized">
            <p v-else>{{ currentRecourse.account }}</p>
        </td>
        <td>
            <center-cost-select v-model="currentRecourse.center_cost" v-if="!finalized"></center-cost-select>
            <p v-else>{{ currentRecourse.center_cost.name }}</p>
        </td>
        <td v-if="!finalized">
            <button class="btn btn-success text-white px-1" type="button" @click="setAccount">
                <i class="material-icons align-middle">check</i> Asignar cuenta
            </button>
        </td>
    </tr>
</template>

<script>
    import centerCostSelect from "../CenterCostSelect"
    import Axios from 'axios';
    export default {
        data(){
            return {
                currentRecourse: {
                    description: "",
                    quantity: 0,
                    unit: "",
                    value: 0,
                    account: 0,
                    center_cost: {}
                }
            }
        },
        components: {
            centerCostSelect
        },
        props: {
            index: {
                type: Number,
                default: 0
            },
            resource: {
                description: "",
                quantity: 0,
                unit: "",
                value: 0,
                account: 0,
                center_cost: {}
            },
            finalized: {
                type: Boolean,
                default: false
            }
        },
        methods: {
            setAccount(){
                if(confirm("¿Esta seguro de esta acción?")){
                    Axios.put("/api/SetAccounts/" + this.resource.id, {
                        account: this.currentRecourse.account,
                        centerCost: this.currentRecourse.center_cost.id,
                    },{
                        headers: {
                            Accept: 'application/json',
                            Authorization: 'Bearer ' + localStorage.autenticate_token
                        }
                    }).then(response => {
                        alert(response.data.message);
                    }).catch(error => {
                        this.message.type = "danger";
                        this.message.value = error.response.data.message;
                    })
                }
            }
        },
        computed: {
            valueTotal(){
                return this.currentRecourse.quantity*this.currentRecourse.value;
            }
        },
        watch: {
            resource(value){
                this.currentRecourse = value;
            }
        },
        mounted() {
            this.currentRecourse = this.resource;
        }
    }
</script>
