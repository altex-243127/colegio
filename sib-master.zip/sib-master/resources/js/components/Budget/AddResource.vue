<template>
    <tr>
        <td>
            <input type="text" class="form-control" v-model="currentRecourse.description" v-if="!finalized">
            <p v-else>{{ currentRecourse.description }}</p>
        </td>
        <td>
            <input type="number" class="form-control" v-model="currentRecourse.quantity" v-if="!finalized">
            <p v-else>{{ currentRecourse.quantity }}</p>
        </td>
        <td>
            <input type="text" class="form-control" v-model="currentRecourse.unit" v-if="!finalized">
            <p v-else>{{ currentRecourse.unit }}</p>
        </td>
        <td>
            <input type="number" class="form-control" v-model="currentRecourse.value" v-if="!finalized">
            <p v-else>{{ currentRecourse.value }}</p>
        </td>
        <td>
            <p class="text-center">{{valueTotal}}</p>
        </td>
        <td v-if="!finalized">
            <button class="btn btn-red text-white px-1" type="button" @click="remove">
                <i class="material-icons align-middle">delete</i>
            </button>
        </td>
    </tr>
</template>

<script>
    import centerCostSelect from "../CenterCostSelect"
    import Axios from 'axios';
    export default {
        data(){
            return {
                currentRecourse: {
                    description: "",
                    quantity: 0,
                    unit: "",
                    value: 0,
                    account: 0,
                    center_cost: {}
                }
            }
        },
        components: {
            centerCostSelect
        },
        props: {
            index: {
                type: Number,
                default: 0
            },
            resource: {
                description: "",
                quantity: 0,
                unit: "",
                value: 0,
                account: 0,
                center_cost: {}
            },
            finalized: {
                type: Boolean,
                default: false
            }
        },
        methods: {
            remove(){
                if(confirm("¿Esta seguro de eliminar este recurso")){
                    if(this.resource.id !== undefined){
                        Axios.delete("/api/Budget/resource/" + this.resource.id, {
                            headers: {
                                Accept: 'application/json',
                                Authorization: 'Bearer ' + localStorage.autenticate_token
                            }
                        }).then(response => {
                            this.$emit("remove", this.index)
                        }).catch(error => {
                            this.message.type = "danger";
                            this.message.value = error.response.data.message;
                        })
                    }else{
                        this.$emit("remove", this.index)
                    }
                }
            }
        },
        computed: {
            valueTotal(){
                return this.currentRecourse.quantity*this.currentRecourse.value;
            }
        },
        watch: {
            currentRecourse(){

            },
            resource(value){
                this.currentRecourse = value;
            }
        },
        mounted() {
            this.currentRecourse = this.resource;
        }
    }
</script>
