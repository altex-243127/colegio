<template>
    <div class="modal fade" id="addResources" tabindex="-1" role="dialog">
        <div class="modal-dialog  modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header alert">
                    <h5 class="modal-title">Recursos</h5>
                    <button type="button" class="close" @click="close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body" v-if="Object.keys(budget).length > 0">

                    <div class="row">
                        <div class="col-12">
                            <h5>Area</h5>
                            <p>{{ budget.area.name }}</p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <h5>Objetivo</h5>
                            <p>{{ budget.objective.objective }}</p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <h5>Estrategia</h5>
                            <p>{{ budget.strategy.name }}</p>
                        </div>
                    </div>

                    <div class="row" v-if="message.value != ''">
                        <div class="col">
                            <p class="p-2" :class="'alert-' + message.type">
                                {{ message.value }}
                            </p>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <activity v-for="(activity, index) in activities"
                                      :key="index"
                                      :index="index"
                                      :activity="activity">
                        </activity>
                    </div>

                </div>
                <div class="modal-footer">
                    <div class="w-100">
                        <div class="row justify-content-end">
                            <div class="col-6">
                                <button type="button" class="btn btn-secondary w-100"  @click="close">Cerrar</button>
                            </div>
                        </div>
                    </div>


                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import jQuery from 'jquery'
    import activity from "./Activity";

    export default {
        name: "ShowResources",
        components: {
            activity
        },
        data(){
            return {
                activities: [],
                message: {
                    type: "danger",
                    value: ""
                },
            }
        },
        props: {
            show: {
                type: Boolean,
                default: false
            },
            budget: {
                type: Object,
                default(){
                    return {}
                }
            },
            finalized: {
                type: Boolean,
                default: false
            }
        },
        watch: {
            show(value){
                jQuery(this.$el).modal(value ? "show" : "hide");
            },
            budget(value){
                this.activities = value.activities;
            }
        },
        methods: {
            close(){
                this.$emit('close');
            }
        }
    }
</script>
