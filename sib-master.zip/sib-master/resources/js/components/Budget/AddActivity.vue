<template>
    <div class="col-12 mt-4 py-3 border">
        <div class="row">
            <div class="col-11">
                <h5>Actividad</h5>
            </div>
            <div class="col-1 text-right" >
                <button type="button" class="btn btn-red text-white px-1" @click="remove" v-if="!finalized">
                    <i class="material-icons align-middle">delete</i>
                </button>
            </div>
            <div class="col-4">
                Oficina
                <office-select v-model="currentActivity.office" :area="currentActivity.area_id" v-if="!finalized"></office-select>
                <p v-else>{{ currentActivity.office.name }}</p>
            </div>
            <div class="col-4">
                Acción a ejecutar
                <textarea class="form-control" rows="2" v-model="currentActivity.action" v-if="!finalized"></textarea>
                <p v-else>{{ currentActivity.action }}</p>
            </div>
            <div class="col-4">
                Descripción de actividad
                <textarea class="form-control" rows="2" v-model="currentActivity.description" v-if="!finalized"></textarea>
                <p v-else>{{ currentActivity.description }}</p>
            </div>
        </div>
        <div class="row">
            <div class="col-4">
                Responsable
                <user-select v-model="currentActivity.responsable" :office="currentActivity.office.id" v-if="!finalized"></user-select>
                <p v-else>{{ currentActivity.responsable.name }}</p>
            </div>
            <div class="col-4">
                Ejecutor
                <user-select v-model="currentActivity.executor" :office="currentActivity.office.id" v-if="!finalized"></user-select>
                <p v-else>{{ currentActivity.executor.name }}</p>
            </div>
            <div class="col-2">
                Fecha inicio
                <select class="form-control" required v-model="currentActivity.start_date" v-if="!finalized">
                    <option value=""></option>
                    <option v-for="(month, index) in months" :value="index">{{ month }}</option>
                </select>
                <p v-else>{{ months[currentActivity.start_date] }}</p>
            </div>
            <div class="col-2">
                Fecha fin
                <select class="form-control" required v-model="currentActivity.end_date" v-if="!finalized">
                    <option value=""></option>
                    <option v-for="(month, index) in months" :value="index">{{ month }}</option>
                </select>
                <p v-else>{{ months[currentActivity.end_date] }}</p>
            </div>
        </div>
        <div class="row mt-3">
            <div class="col-6">
                <h5>Recursos</h5>
            </div>
            <div class="col-6 text-right" v-if="!finalized">
                <button class="btn btn-red text-white my-2" @click="addResource">
                    <i class="fa fa-plus"></i> Nuevo recurso
                </button>
            </div>

            <div class="col-12">
                <div class="row" v-if="message.value != ''">
                    <div class="col">
                        <p class="p-2" :class="'alert-' + message.type">
                            {{ message.value }}
                        </p>
                    </div>
                </div>
            </div>

            <div class="col-12">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                        <tr>
                            <th><p style="width: 150px">Descripción</p></th>
                            <th><p style="width: 70px">Cant</p></th>
                            <th><p style="width: 150px">Unidad</p></th>
                            <th><p style="width: 150px">Valor Unidad</p></th>
                            <th><p style="width: 150px">Valor total</p></th>
                            <th v-if="!finalized"></th>
                        </tr>
                        </thead>
                        <tbody>
                            <template v-for="(resource, index) in activity.resources">
                                <add-resource :index="index" :resource="resource" :finalized="finalized" @remove="removeResource($event)"></add-resource>
                            </template>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>
</template>

<script>
    import officeSelect from "../Office/select";
    import userSelect from "../users/select";
    import AddResource from "./AddResource";
    import Axios from "axios";
    export default {
        name: "addActivity",
        data(){
            return {
                months: [
                    "Enero",
                    "Febrero",
                    "Marzo",
                    "Abril",
                    "Mayo",
                    "Junio",
                    "Julio",
                    "Agosto",
                    "Septiembre",
                    "Octubre",
                    "Noviembre",
                    "Diciembre"
                ],
                currentActivity: {
                    action: "",
                    end_date: "",
                    start_date: "",
                    description: "",
                    executor: {},
                    office: {},
                    area_id: null,
                    responsable: {},
                    resources: []
                },
                message: {
                    type: "danger",
                    value: ""
                },
            }
        },
        components: {
            officeSelect,
            userSelect,
            AddResource
        },
        props: {
            index: {
                type: Number,
                default: 0
            },
            activity: {
                type: Object,
                default: () => {
                    return {
                        action: "",
                        end_date: "",
                        start_date: "",
                        description: "",
                        executor: {},
                        office: {},
                        area_id: null,
                        responsable: {},
                        resources: []
                    };
                }
            },
            finalized: {
                type: Boolean,
                default: false
            }
        },
        methods: {
            addResource(){
                this.message.value = "";
                if(this.validateResources()){
                    this.currentActivity.resources.push({
                        description: "",
                        quantity: 0,
                        unit: "",
                        value: 0,
                        account: 0,
                        center_cost: {}
                    })
                }else{
                    this.message.type = "danger";
                    this.message.value = "Todos los campos del recurso son obligatorios";
                }
            },
            remove(){
                if(confirm("¿Esta seguro de eliminar esta actividad")){
                    if(this.activity.id !== undefined){
                        Axios.delete("/api/Budget/activity/" + this.activity.id, {
                            headers: {
                                Accept: 'application/json',
                                Authorization: 'Bearer ' + localStorage.autenticate_token
                            }
                        }).then(response => {
                            this.$emit("remove", this.index)
                        }).catch(error => {
                            this.message.type = "danger";
                            this.message.value = error.response.data.message;
                        })
                    }else{
                        this.$emit("remove", this.index)
                    }
                }
            },
            setResource(data){
                this.$set(this.activity.resources, data.index, data);
            },
            removeResource(index){
                this.activity.resources = this.activity.resources.filter((item, key) => {
                    console.log(index , key)
                    return index != key;
                })
            },
            validateResources(){
                let errors = 0;
                this.activity.resources.map(item => {
                    errors += this.validateResource(item) ? 0 : 1;
                });
                return errors == 0;
            },
            validateResource(resource){
                let errors = 0;
                errors += resource.quantity <= 0 ? 1 : 0;
                errors += resource.unit == "" ? 1 : 0;
                errors += resource.value <= 0 ? 1 : 0;
                errors += resource.description == "" ? 1 : 0;
                console.log(resource, errors);
                return errors == 0;
            },
        },
        watch: {
            currentActivity(value){

            },
            activity(value){
                this.$set(this, "currentActivity", value);
            }
        },
        mounted() {
            this.$set(this, "currentActivity", this.activity);
        }
    }
</script>
