<template>
    <div class="col-12">
        <div class="row mb-3">
            <add-activity v-for="(activity, index) in activities"
                          @remove="removeActivity($event)"
                          @set-activity="setActivity($event)"
                          :key="index"
                          :index="index"
                          :activity="activity">
            </add-activity>
        </div>

        <div class="row">
            <div class="col-12 text-right">
                <button type="button" class="btn btn-red text-white" @click="addActivity">
                    <i class="fa fa-plus"></i> Nueva actividad
                </button>
            </div>
        </div>

        <div class="row justify-content-end" v-if="activities.length > 0">
            <div class="col-6">
                <button type="button" class="btn btn-secondary w-100"  @click="close">Cerrar</button>
            </div>
            <div class="col-6">
                <button type="button" class="btn btn-success w-100" @click="save">Guardar</button>
            </div>
        </div>

    </div>

</template>
<script>
import jQuery from 'jquery'
import Axios from 'axios';
import AddActivity from "./AddActivity";
import Swal from 'sweetalert2';
import alert from "../Alert";

export default {
    name: "addResources",
    components: {
        AddActivity
    },
    data(){
        return {
            activities: [],
            message: {
                type: "danger",
                value: ""
            },
        }
    },
    methods: {
        removeActivity(index){
            this.activities = this.activities.filter((item, key) => {
                return index != key;
            })
        },
        setActivity(data){
            this.$set(this.activities, data.index, data.activity);
        },
        addActivity(){
            this.message.value = "";
            if(this.validateActivities()){
                this.activities.push({
                    action: "",
                    end_date: "",
                    start_date: "",
                    description: "",
                    executor: {},
                    office: {},
                    area_id: null,
                    responsable: {},
                    resources: []
                });
            }else{
                this.message.type = "danger";
                this.message.value = "Todos los campos de la actividad son obligatorios";
                jQuery(this.$el).scrollTop(0);
            }
        },
        validateActivities(){
            let errors = 0;
            this.activities.map(item => {
                errors += this.validateActivity(item) ? 0 : 1;
            });
            console.log("validateActivities", errors);
            return errors == 0;
        },
        validateActivity(activity){
            let errors = 0;
            errors += activity.action == "" ? 1 : 0;
            errors += activity.dateEnd === "" ? 1 : 0;
            errors += activity.dateInit === "" ? 1 : 0;
            errors += activity.description == "" ? 1 : 0;
            errors += activity.executor.name === undefined ? 1 : 0;
            errors += activity.responsable.name === undefined ? 1 : 0;
            errors += activity.office.name === undefined ? 1 : 0;
            errors += this.validateResourcesActivity(activity) ? 0 : 1;
            return errors == 0;
        },
        validateResourcesActivity(activity){
            let errors = 0;
            if(activity.resources !== undefined){
                activity.resources.map(item => {
                    errors += this.validateResource(item) ? 0 : 1;
                });
            }
            console.log("validateResourcesActivity", errors);
            return errors == 0;
        },
        validateResource(resource){
            let errors = 0;
            errors += resource.quantity <= 0 ? 1 : 0;
            errors += resource.unit == "" ? 1 : 0;
            errors += resource.value <= 0 ? 1 : 0;
            errors += resource.description == "" ? 1 : 0;
            return errors == 0;
        },
        async save(){
            this.message.value = "";
            if(this.validateActivities() && this.activities.length > 0){
                await Axios.post("/budget/newActivityExtra", {
                    activities: this.activities,
                    ref: jQuery("#ref").val(),
                    uee: jQuery("#uee").val()
                }, {
                    headers: {
                        Accept: 'application/json',
                        Authorization: 'Bearer ' + localStorage.autenticate_token
                    }
                }).then(response => {
                    Swal.fire({
                        title: response.data.message,
                        icon: "success",
                        preConfirm: function(){
                            window.location.href = "/";
                        }
                    })

                }).catch(error => {
                    Swal.fire({
                        title: error.response.data.message,
                        icon: "error"
                    })
                })
            }else{
                this.message.type = "danger";
                this.message.value = "Todos los campos de la actividad son obligatorios";
                jQuery(this.$el).scrollTop(0);
            }
        }
    }
}
</script>
