<template>
    <div class="col-12 mt-4 py-3 border">
        <div class="row">
            <div class="col-11">
                <h5>Actividad</h5>
            </div>
            <div class="col-4">
                Oficina
                <p>{{ currentActivity.office.name }}</p>
            </div>
            <div class="col-4">
                Acción a ejecutar
                <p>{{ currentActivity.action }}</p>
            </div>
            <div class="col-4">
                Descripción de actividad
                <p>{{ currentActivity.description }}</p>
            </div>
        </div>
        <div class="row">
            <div class="col-4">
                Responsable
                <p>{{ currentActivity.responsable.name }}</p>
            </div>
            <div class="col-4">
                Ejecutor
                <p>{{ currentActivity.executor.name }}</p>
            </div>
            <div class="col-2">
                Fecha inicio
                <p>{{ months[currentActivity.start_date] }}</p>
            </div>
            <div class="col-2">
                Fecha fin
                <p>{{ months[currentActivity.end_date] }}</p>
            </div>
        </div>
        <div class="row mt-3">
            <div class="col-6">
                <h5>Recursos</h5>
            </div>

            <div class="col-12">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                        <tr>
                            <th><p style="width: 150px">Descripción</p></th>
                            <th><p style="width: 70px">Cant</p></th>
                            <th><p style="width: 150px">Unidad</p></th>
                            <th><p style="width: 150px">Valor Unidad</p></th>
                            <th><p style="width: 150px">Valor total</p></th>
                            <th><p style="width: 150px">Cuneta contable</p></th>
                            <th><p style="width: 150px">Centro de costos</p></th>
                            <th v-if="!finalized"><p style="width: 150px"></p></th>
                        </tr>
                        </thead>
                        <tbody>
                            <template v-for="(resource, index) in activity.resources">
                                <resource :index="index" :resource="resource" :finalized="finalized" @success="setAccountSuccess($event)"></resource>
                            </template>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>
</template>

<script>
    import officeSelect from "../Office/select";
    import userSelect from "../users/select";
    import resource from "./Resource";
    import Axios from "axios";
    export default {
        data(){
            return {
                months: [
                    "Enero",
                    "Febrero",
                    "Marzo",
                    "Abril",
                    "Mayo",
                    "Junio",
                    "Julio",
                    "Agosto",
                    "Septiembre",
                    "Octubre",
                    "Noviembre",
                    "Diciembre"
                ],
                currentActivity: {
                    action: "",
                    end_date: "",
                    start_date: "",
                    description: "",
                    executor: {},
                    office: {},
                    area_id: null,
                    responsable: {},
                    resources: []
                },
                message: {
                    type: "danger",
                    value: ""
                },
            }
        },
        components: {
            officeSelect,
            userSelect,
            resource
        },
        props: {
            index: {
                type: Number,
                default: 0
            },
            activity: {
                type: Object,
                default: () => {
                    return {
                        action: "",
                        end_date: "",
                        start_date: "",
                        description: "",
                        executor: {},
                        office: {},
                        area_id: null,
                        responsable: {},
                        resources: []
                    };
                }
            },
            finalized: {
                type: Boolean,
                default: false
            }
        },
        watch: {
            activity(value){
                this.$set(this, "currentActivity", value);
            }
        },
        methods: {
            setAccountSuccess(message){
                this.message.type = "success";
                this.message.value = message;
            }
        },
        mounted() {
            this.$set(this, "currentActivity", this.activity);
        }
    }
</script>
