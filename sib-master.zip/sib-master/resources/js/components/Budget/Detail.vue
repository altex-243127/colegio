<template>
    <div class="modal fade" id="detailBudget" tabindex="-1" role="dialog">
        <div class="modal-dialog  modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header alert">
                    <h5 class="modal-title">Actividades</h5>
                    <button type="button" class="close" @click="close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body" v-if="Object.keys(budget).length > 0">

                    <div class="row">
                        <div class="col-12">
                            <h5>Objetivo</h5>
                            <p>{{ budget.objective.objective }}</p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <h5>Estrategia</h5>
                            <p>{{ budget.strategy.name }}</p>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <template v-for="activity in budget.activities">
                            <div class="col-12 mt-4 py-3 border">
                                <div class="row">
                                    <div class="col-9 mt-4">
                                        <h5>Actividad</h5>
                                    </div>
                                    <div class="col-4">
                                        <h6 class="font-weight-bold">Oficina</h6>
                                        <p>{{ activity.office.name }}</p>
                                    </div>
                                    <div class="col-4">
                                        <h6 class="font-weight-bold">Acción a ejecutar</h6>
                                        <p>{{ activity.action }}</p>
                                    </div>
                                    <div class="col-4">
                                        <h6 class="font-weight-bold">Descripción de actividad</h6>
                                        <p>{{ activity.description }}</p>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-4">
                                        <h6 class="font-weight-bold">Responsable</h6>
                                        <p>{{ activity.responsable.name }}</p>
                                    </div>
                                    <div class="col-4">
                                        <h6 class="font-weight-bold">Ejecutor</h6>
                                        <p>{{ activity.executor.name }}</p>
                                    </div>
                                    <div class="col-2">
                                        <h6 class="font-weight-bold">Fecha inicio</h6>
                                        <p>{{ months[activity.start_date] }}</p>
                                    </div>
                                    <div class="col-2">
                                        <h6 class="font-weight-bold">Fecha fin</h6>
                                        <p>{{ months[activity.end_date] }}</p>
                                    </div>
                                </div>

                                <div class="row justify-content-end">

                                    <div class="col-12 text-right mt-4">
                                        <button class="btn btn-success" type="button" v-if="activity.request == null" @click="request(activity)">
                                            Solicitar monto
                                        </button>
                                        <p class="alert alert-info" v-else-if="activity.request.state == 0">
                                            Esperando respuesta
                                        </p>
                                        <template v-else-if="activity.request.state == 1">
                                            <p class="alert alert-success">
                                                Este monto fue aprobado  <a href="#" @click="requestSupplies(activity)">Solicitar insumos</a>
                                            </p>
                                        </template>
                                        <p class="alert alert-danger" v-else-if="activity.request.state == 2">
                                            Esta solicitud fue rechazada
                                        </p>
                                    </div>
                                </div>

                                <div class="row mt-3">
                                    <div class="col-6">
                                        <h5>Recursos</h5>
                                    </div>

                                    <div class="col-12 recursosBox">
                                        <div class="table-responsive">
                                            <table class="table table-hover">
                                                <thead>
                                                <tr>
                                                    <th><p style="width: 150px">Descripción</p></th>
                                                    <th><p style="width: 70px">Cant</p></th>
                                                    <th><p style="width: 150px">Unidad</p></th>
                                                    <th><p style="width: 150px">Valor Unidad</p></th>
                                                    <th><p style="width: 150px">Valor total</p></th>
                                                    <th><p style="width: 150px">Cuenta contable</p></th>
                                                    <th><p style="width: 150px">Centro de costos</p></th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <template v-for="(resource, index) in activity.resources">
                                                    <tr>
                                                        <td>
                                                            <p>{{ resource.description }}</p>
                                                        </td>
                                                        <td>
                                                            <p>{{ resource.quantity }}</p>
                                                        </td>
                                                        <td>
                                                            <p>{{ resource.unit }}</p>
                                                        </td>
                                                        <td>
                                                            <p>{{ resource.value }}</p>
                                                        </td>
                                                        <td>
                                                            <p class="text-center">{{resource.quantity * resource.value}}</p>
                                                        </td>
                                                        <td>
                                                            <p>{{ resource.account }}</p>
                                                        </td>
                                                        <td>
                                                            <p>{{ resource.center_cost ? resource.center_cost.name : "" }}</p>
                                                        </td>
                                                    </tr>
                                                </template>
                                                </tbody>
                                            </table>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </template>
                    </div>

                </div>
                <div class="modal-footer">
                    <div class="w-100">
                        <div class="row justify-content-end">
                            <div class="col-6">
                                <button type="button" class="btn btn-secondary w-100"  @click="close">Cerrar</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</template>

<script>
    import Axios from "axios";
    import jQuery from "jquery";
    export default {
        data(){
            return {
                months: [
                    "Enero",
                    "Febrero",
                    "Marzo",
                    "Abril",
                    "Mayo",
                    "Junio",
                    "Julio",
                    "Agosto",
                    "Septiembre",
                    "Octubre",
                    "Noviembre",
                    "Diciembre"
                ]
            }
        },
        props: {
            show: {
                type: Boolean,
                default: false
            },
            budget: {
                type: Object,
                default(){
                    return {}
                }
            },
        },
        methods: {
            close() {
                this.$emit('close');
            },
            request(activity){
                if(confirm("¿Esta seguro que desea solicitar este monto (" + new Intl.NumberFormat().format(this.totalByActivity(activity)) + ")?")){
                    Axios.post("/api/Budget/Approved/request/" + activity.id, {}, {
                        headers: {
                            Accept: 'application/json',
                            Authorization: 'Bearer ' + localStorage.autenticate_token
                        }
                    }).then(response => {
                        this.$emit("success", {
                            title: "La operación se completo con éxito",
                            message: response.data.message,
                            type: "success"
                        })
                        this.close()
                    }).catch(error => {
                        this.$emit("error", {
                            title: "La operación no se pudo completar",
                            message: error.response.data.message,
                            type: "danger"
                        })
                        this.close()
                    })
                }
            },
            totalByActivity(activity){
                let total = 0;

                activity.resources.map(item => {
                    total += item.quantity * item.value;
                })

                return total;
            },
            requestSupplies(activity){
                this.close();
                console.log(this.$route.fullPath);
                setTimeout(() => {
                    this.$router.push({ path: `/solicitarInsumos/${activity.id}` })
                }, 500)
            }
        },
        watch: {
            show(value) {
                jQuery(this.$el).modal(value ? "show" : "hide");
            },
        }
    }
</script>
