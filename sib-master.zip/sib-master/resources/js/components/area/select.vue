<template>
    <div class="select-user">
        <p class="form-control px-1 m-0" @click="show = !show">
            {{ value.name }}
            <span class="float-right material-icons">
                keyboard_arrow_down
            </span>
        </p>
        <ul class="select-list" :class="{show: show}">
            <li>
                <input type="text" class="form-control" autocomplete="off" placeholder="Buscar..." v-model="find">
            </li>
            <template v-for="(area, key) in filterAreas">
                <li>
                    <button type="button" class="btn text-left w-100" @click="setValue(area)">{{ area.name.toLowerCase() }}</button>
                </li>
            </template>
            <li v-if="areas.length == 0">
                Sin resultados
            </li>
        </ul>
    </div>
</template>

<script>
import Axios from 'axios';

export default {
    name: "selectArea",
    data() {
        return {
            areas: [],
            select: 0,
            find: "",
            show: false
        }
    },
    props: {
        value: {
            default(){
                name: ""
            }
        }
    },
    methods: {
        getAreas(){
            let now = new Date();
            let cache = localStorage.getItem('areasList');
            if(cache === undefined || cache === null){
                Axios.get("/api/areas/json", {
                    headers: {
                        Accept: 'application/json',
                        Authorization: 'Bearer ' + localStorage.autenticate_token
                    }
                }).then(response => {
                    this.areas = response.data;
                    localStorage.setItem('areasList', JSON.stringify({
                        areas: response.data,
                        expire: now.getTime() + 15000
                    }));
                }).catch(error => {
                    console.log(error);
                    this.$emit("error");
                })
            }else{
                cache = JSON.parse(cache);
                if(now.getTime() > cache.expire){
                    console.log("lo voy a quitar", cache.expire, now.getTime())
                    localStorage.removeItem('areasList');
                    this.getAreas();
                }else{
                    this.areas = cache.areas;
                }
            }
        },
        setValue(area){
            this.$emit("input", area);
        }
    },
    computed: {
        filterAreas(){
            return this.areas.filter(area => {
                return area.name.toLowerCase().indexOf(this.find.toLowerCase()) >= 0;
            });
        }
    },
    watch: {
        value(value){
            this.$emit("input", value);
            this.show = false;
        }
    },
    mounted() {
        this.getAreas();
    }
}
</script>

<style scoped>
    .select-user{
        position: relative;
        cursor: pointer;
    }
    .select-user p{
        overflow: hidden;
        font-size: 12px;
        white-space: nowrap;
        max-width: 120px;
    }
    ul{
        list-style: none;
        padding: 0px;
        position: absolute;
        width: 100%;
        border: 1px solid #dee2e6;
        border-top: 0px;
        opacity: 0;
        transition: all 1s;
        pointer-events: none;
        background-color: #fff;
        z-index: 10;
        height: 150px;
        overflow: auto;
    }
    ul.show{
        opacity: 1;
        pointer-events: all;
    }

    ul li button{
        font-size: 10px;
        text-transform: capitalize;
    }
</style>
