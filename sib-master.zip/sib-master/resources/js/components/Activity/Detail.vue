<template>
    <div class="modal fade" id="detailBudget" tabindex="-1" role="dialog">
        <div class="modal-dialog  modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header alert">
                    <h5 class="modal-title">Detalle actividad</h5>
                    <button type="button" class="close" @click="close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                    <div class="row mb-3"  v-if="Object.keys(activity).length > 0">
                        <div class="col-12 mt-4 py-3 border">
                            <div class="row">
                                <div class="col-9 mt-4">
                                    <h5>Actividad</h5>
                                </div>
                                <div class="col-4">
                                    <h6 class="font-weight-bold">Oficina</h6>
                                    <p>{{ activity.office.name }}</p>
                                </div>
                                <div class="col-4">
                                    <h6 class="font-weight-bold">Acción a ejecutar</h6>
                                    <p>{{ activity.action }}</p>
                                </div>
                                <div class="col-4">
                                    <h6 class="font-weight-bold">Descripción de actividad</h6>
                                    <p>{{ activity.description }}</p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-4">
                                    <h6 class="font-weight-bold">Responsable</h6>
                                    <p>{{ activity.responsable.name }}</p>
                                </div>
                                <div class="col-4">
                                    <h6 class="font-weight-bold">Ejecutor</h6>
                                    <p>{{ activity.executor.name }}</p>
                                </div>
                                <div class="col-2">
                                    <h6 class="font-weight-bold">Fecha inicio</h6>
                                    <p>{{ months[activity.start_date] }}</p>
                                </div>
                                <div class="col-2">
                                    <h6 class="font-weight-bold">Fecha fin</h6>
                                    <p>{{ months[activity.end_date] }}</p>
                                </div>
                            </div>

                            <div class="row mt-3">
                                <div class="col-6">
                                    <h5>Recursos</h5>
                                </div>

                                <div class="col-12">
                                    <div class="table-responsive">
                                        <table class="table table-hover">
                                            <thead>
                                            <tr>
                                                <th><p style="width: 150px">Descripción</p></th>
                                                <th><p style="width: 70px">Cant</p></th>
                                                <th><p style="width: 150px">Unidad</p></th>
                                                <th><p style="width: 150px">Valor Unidad</p></th>
                                                <th><p style="width: 150px">Valor total</p></th>
                                                <th><p style="width: 150px">Cuenta contable</p></th>
                                                <th><p style="width: 150px">Centro de costos</p></th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <template v-for="(resource, index) in activity.resources">
                                                <tr>
                                                    <td>
                                                        <p>{{ resource.description }}</p>
                                                    </td>
                                                    <td>
                                                        <p>{{ resource.quantity }}</p>
                                                    </td>
                                                    <td>
                                                        <p>{{ resource.unit }}</p>
                                                    </td>
                                                    <td>
                                                        <p>{{ resource.value }}</p>
                                                    </td>
                                                    <td>
                                                        <p class="text-center">{{resource.quantity * resource.value}}</p>
                                                    </td>
                                                    <td>
                                                        <p>{{ resource.account }}</p>
                                                    </td>
                                                    <td>
                                                        <p>{{ resource.center_cost ? resource.center_cost.name : "" }}</p>
                                                    </td>
                                                </tr>
                                            </template>
                                            </tbody>
                                        </table>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="modal-footer">
                    <div class="w-100">
                        <div class="row justify-content-end">
                            <div class="col-6">
                                <button type="button" class="btn btn-secondary w-100"  @click="close">Cerrar</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</template>

<script>
    import Axios from "axios";
    import jQuery from "jquery";
    export default {
        data(){
            return {
                months: [
                    "Enero",
                    "Febrero",
                    "Marzo",
                    "Abril",
                    "Mayo",
                    "Junio",
                    "Julio",
                    "Agosto",
                    "Septiembre",
                    "Octubre",
                    "Noviembre",
                    "Diciembre"
                ]
            }
        },
        props: {
            show: {
                type: Boolean,
                default: false
            },
            activity: {
                type: Object,
                default(){
                    return {}
                }
            },
        },
        methods: {
            close() {
                this.$emit('close');
            }
        },
        watch: {
            show(value) {
                jQuery(this.$el).modal(value ? "show" : "hide");
            },
        }
    }
</script>
