<template>
    <nav id="sidebar" :style="{ backgroundColor: background }" :class="{ hide: hide }">
        <div class="sidebar-header">
            <slot name="header"></slot>
            <button type="button" class="sidebar-toggle btn p-1" @click="toggle">
                <i class="material-icons" v-if="!hide">navigate_before</i>
                <i class="material-icons" v-else>navigate_next</i>
            </button>
        </div>
        <div class="sidebar-body">
            <slot name="body"></slot>
            <ul class="nav flex-column">
            <template v-for="item in menu">
                <template v-if="item.subs == undefined">
                    <li class="nav-item">
                        <template v-if="withRoute && item.simple == undefined">
                            <router-link class="nav-link" :to="item.href">
                                <i class="material-icons" v-if="item.icon != undefined">{{ item.icon }}</i> {{ item.title }}
                            </router-link>
                        </template>
                        <template v-else>
                            <a class="nav-link" :href="item.href">
                                <i class="material-icons" v-if="item.icon != undefined">{{ item.icon }}</i> {{ item.title }}
                            </a>
                        </template>
                    </li>
                </template>
                <template v-else>
                    <CollapseItem class="nav-item" class-link="nav-link">
                        <template slot="title">
                            <i class="material-icons" v-if="item.icon != undefined">{{ item.icon }}</i> {{ item.title }}
                        </template>
                        <template slot="collapseContent">
                            <ul class="nav flex-column">
                                <template v-for="sub in item.subs">
                                    <li class="nav-item">
                                        <template v-if="withRoute && sub.simple == undefined">
                                            <router-link class="nav-link" :to="sub.href">
                                                <i class="material-icons" v-if="sub.icon != undefined">{{ sub.icon }}</i> {{ sub.title }}
                                            </router-link>
                                        </template>
                                        <template v-else>
                                            <a class="nav-link simple" :href="(sub.simple == undefined ? '/#' : '') + sub.href">
                                                <i class="material-icons" v-if="sub.icon != undefined">{{ sub.icon }}</i> {{ sub.title }}
                                            </a>
                                        </template>
                                    </li>
                                </template>
                            </ul>
                        </template>
                    </CollapseItem>
                </template>

            </template>
            </ul>
        </div>
        <div class="sidebar-footer">
            <slot name="footer"></slot>
        </div>
    </nav>
</template>

<script>
import Vue from "vue";
import CollapseItem from './CollapseItem/Index';
export default {
    name: "Sidebar",
    data: () => {
        return {
            withRoute: false
        }
    },
    props: {
        background: {
            type: String,
            default: "#7386D5"
        },
        hide: {
            type: Boolean,
            default: false
        },
        menu: {
            default: () => {
                return []
            }
        }
    },
    components: {
      CollapseItem
    },
    methods: {
        toggle(){
           this.$emit('change-state', !this.hide);
        }
    },
    mounted() {
        this.withRoute = typeof Vue.options.components.RouterLink != "undefined";
    }
}
</script>

<style type="scss">
    #sidebar {
        min-width: 250px;
        max-width: 250px;
        height: auto;
        min-height: 100vh;
        color: #fff;
        transition: all 0.3s;
    }

    #sidebar.hide{
        min-width: 110px;
        max-width: 110px;
    }

    #sidebar .sidebar-header{
        padding: 20px;
        position: relative;
    }

    #sidebar .sidebar-header .sidebar-toggle {
        position: absolute;
        top: 5%;
        right: 2%;
        background-color: rgba(255, 255, 255, 0.4);
        border-radius: 0px;
        height: 32px;
        color: #fff;
    }

    #sidebar .sidebar-body {
        padding: 20px 0;
        border-bottom: 1px solid #d4cbd6;
        background-color: rgba(0, 0, 0, 0.2);
    }

    #sidebar .sidebar-body ul > li:hover{
        background-color: #fff;
    }
    #sidebar .sidebar-body ul > li:hover > a{
        color: #333;
    }

    #sidebar .sidebar-body ul > li > a > *{
        vertical-align: middle;
    }

    #sidebar .sidebar-body ul > li > a {
        color: #fff;
        padding: 10px;
        font-size: 1.1em;
    }

    #sidebar .sidebar-body ul > li > div {
        transition: 1s all;
        opacity: 0;
        height: 0px;
        overflow: hidden;
    }

    #sidebar .sidebar-body ul > li > div.show {
        opacity: 1;
        height: auto;
    }

    #sidebar .sidebar-body ul > li ul{
        padding-left: 20px;
    }

    #sidebar .sidebar-body ul > li ul > li {
        font-size: 1.1em;
    }

    #sidebar .sidebar-body ul > li:hover ul > li > a {
        color: #333;
    }

    #sidebar .sidebar-body ul > li ul > li:hover a {
        color: rgba(255, 1, 37, 0.5);
    }

</style>

