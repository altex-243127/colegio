<template>
    <li>
        <a :class="classLink" href="#" @click="collapse = !collapse">
            <span>
                <slot name="title"></slot>
            </span>
            <i class="material-icons">arrow_drop_down</i>
        </a>
        <div :class="{ show : !collapse}">
            <slot name="collapseContent"></slot>
        </div>
    </li>
</template>

<script>
export default {
    data(){
        return {
            collapse: true
        }
    },
    props: {
        classLink: {
            type: String,
            default: ""
        }
    }
}
</script>
