<template>
    <div class="modal fade" id="detailBudget" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header alert">
                    <h5 class="modal-title">{{ office.name }}</h5>
                    <button type="button" class="close" @click="close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                    <div class="row" v-if="message != ''">
                        <div class="col-12 alert-danger">
                            <p>{{ message }}</p>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-12 mb-4">
                            <label for="name">Nombre</label>
                            <input type="text" class="form-control" name="name" id="name" v-model="name">
                        </div>

                        <div class="col-12 mb-4">
                            <label>Area</label>
                            <select-area v-model="area"></select-area>
                        </div>

                    </div>

                </div>
                <div class="modal-footer">
                    <div class="w-100">
                        <div class="row justify-content-end">
                            <div class="col-6">
                                <button type="button" class="btn btn-secondary w-100"  @click="close">Cerrar</button>
                            </div>
                            <div class="col-6">
                                <button type="button" class="btn btn-red w-100"  @click="send">Editar</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</template>

<script>
    import Axios from "axios";
    import jQuery from "jquery";
    import selectArea from "../area/select";

    export default {
        data(){
            return {
                message: "",
                name: "",
                area: {}
            }
        },
        components: {
            selectArea
        },
        props: {
            show: {
                type: Boolean,
                default: false
            },
            office: {
                type: Object,
                default(){
                    return {}
                }
            }
        },
        methods: {
            close() {
                this.$emit('close');
            },
            validate(){
                this.message = "";
                if(this.name == ''){
                    this.message = "El campo nombre es obligatorio";
                    return false;
                }
                if(this.area.id == undefined || this.area.id == ''){
                    this.message = "El campo area es obligatorio";
                    return false;
                }
                return true;
            },
            send(){
                if(this.validate()){
                    let data = {
                        name: this.name,
                        area_id: this.area.id
                    };
                    Axios.put("/api/offices/" + this.office.id, data, {
                        headers: {
                            Accept: 'application/json',
                            Authorization: 'Bearer ' + localStorage.autenticate_token
                        }
                    }).then(response => {
                        this.$emit("success", response.data.message);
                        this.close();
                    }).catch(error => {
                        this.$emit("error", error.response.data.message);
                    })
                }
            }
        },
        watch: {
            show(value) {
                jQuery(this.$el).modal(value ? "show" : "hide");
            },
            office(value){
                this.name = value.name;
                this.area = value.area;
            }
        }
    }
</script>
