<template>
    <div class="row">
        <div class="col-12 mb-4">
            <label for="area">Área</label>
            <select id="area" class="form-control" v-model="selectArea">
                <option value=""></option>
                <option v-for="area in areas" :value="area.id">{{ area.name }}</option>
            </select>
        </div>
        <div class="col-12 mb-4">
            <label for="office">Oficina</label>
            <select id="office" class="form-control" v-model="selectOffice">
                <option value=""></option>
                <option v-for="office in officeFilter" :value="office.id">{{ office.name }}</option>
            </select>
        </div>
    </div>
</template>

<script>
    import Axios from 'axios';
    export default {
        data(){
            return {
                areas: [],
                offices: [],
                selectOffice: 0,
                selectArea: 0
            }
        },
        props: {
            area: {
                type: Number,
                default: 0
            },
            office: {
                type: Number,
                default: 0
            }
        },
        methods: {
            async getAreas(){
                await Axios.get("/api/areas/json", {
                        headers: {
                            Accept: 'application/json',
                            Authorization: 'Bearer ' + localStorage.autenticate_token
                        }
                    })
                    .then(response => {
                        this.areas = response.data;
                    })
                    .catch(error => {

                    })
            },
            async getOffices(){
                await Axios.get("/api/offices/json", {
                        headers: {
                            Accept: 'application/json',
                            Authorization: 'Bearer ' + localStorage.autenticate_token
                        }
                    })
                    .then(response => {
                        this.offices = response.data;
                    })
                    .catch(error => {

                    })
            }
        },
        watch: {
            selectArea(value){
                this.$emit("area", value);
            },
            selectOffice(value){
                this.$emit("office", value);
            },
            area(value){
                this.selectArea = value;
            },
            office(value){
                this.selectOffice = value;
            }
        },
        computed: {
            officeFilter(){
                let offices = this.offices;
                if(this.area != 0){
                    offices = offices.filter(item => {
                        return item.area_id == this.area;
                    });
                }
                return offices;
            }
        },
        mounted() {
            this.getAreas()
            this.getOffices()
        }
    }
</script>

<style scoped>
.select-user{
    position: relative;
    cursor: pointer;
}
ul{
    list-style: none;
    padding: 0px;
    position: absolute;
    width: 100%;
    border: 1px solid #dee2e6;
    border-top: 0px;
    opacity: 0;
    transition: all 1s;
    pointer-events: none;
    background-color: #fff;
    z-index: 10;
    max-height: 150px;
    overflow: auto;
}
ul.show{
    opacity: 1;
    pointer-events: all;
}
.select-user p {
    white-space: nowrap;
    overflow: hidden;
}
</style>
