<template>
    <div class="modal fade" data-keyboard="false" data-backdrop="static">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Añadir factor</h5>
                    <button type="button" class="close" @click="close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row" v-if="message.value != ''">
                        <div class="col">
                            <p class="p-2" :class="'alert-' + message.type" v-html="message.value"></p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12 col-md-7">
                            <label>Nombre del factor</label>
                            <CustomInput placeholder="Nombre del factor"
                                         :required="true"
                                         v-model="name.value"
                                         :is-valid="name.isValid"
                                         :message="name.message"
                                         type="text"></CustomInput>
                        </div>
                        <div class="col-12 col-md-5">
                            <label>Ponderación</label>
                            <CustomInput placeholder="Ponderación"
                                         :required="true"
                                         v-model="weighing.value"
                                         :is-valid="weighing.isValid"
                                         :message="weighing.message"
                                         type="number"></CustomInput>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary w-25" @click="close">Cerrar</button>
                    <button type="button" class="btn btn-red w-25" @click="edit">Editar</button>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
import jQuery from "jquery";
import Axios from "axios";
import Factor from "../../models/Factor";
import CustomInput from "../custom-input";

export default {
    name: "EditFactor",
    data(){
        return {
            name: {
                value: "",
                isValid: null,
                validate(){
                    return this.value != ""
                },
                message: "El nombre del factor es obligatorio"
            },
            weighing: {
                value: "",
                isValid: null,
                validate: () => {
                    return this.weighing.value != "" && this.weighing.value > 0 && this.weighing.value <= (this.maxWeighing + this.factor.weighing)
                },
                message: "Este campo no debe estar vacio ni ser menor a cero o mayor a " + this.maxWeighing
            },
            message: {
                type: "success",
                value: ""
            }
        }
    },
    props: {
        show: {
            type: Boolean,
            default: false
        },
        factor: {
            type: Object,
            default(){
                return new Factor();
            }
        },
        maxWeighing: {
            type: Number,
            default: 100
        }
    },
    components: {
        CustomInput
    },
    methods: {
        close() {
            this.$emit("close");
        },
        validate() {
            this.name.isValid = this.name.validate();
            this.weighing.isValid = this.weighing.validate();
            return this.name.isValid && this.weighing.isValid;
        },
        edit() {
            if (!this.validate()) {
                return;
            }
            this.$emit("awaiting");
            Axios.put("/api/CompetitivenessMatrix/factors/" + this.factor.id, {
                name: this.name.value,
                weighing: this.weighing.value
            }, {
                headers: {
                    Accept: 'application/json',
                    Authorization: 'Bearer ' + localStorage.autenticate_token
                }
            }).then(response => {
                this.$set(this.message, "type", "success");
                this.$set(this.message, "value", response.data.message);
                setTimeout(() => {
                    this.$emit("edit-factor");
                    this.close();
                    this.reset();
                }, 500)
                this.$emit("resume")
            }).catch(error => {
                this.$set(this.message, "type", "danger");
                if (error.response.status == 406) {
                    this.$set(this, "message", error.response.data.message.join("<br>"));
                } else {
                    this.$set(this, "message", "No fue posible");
                }
                this.$emit("resume")
            })
        },
        reset(){
            this.$set(this.name, "value", "");
            this.$set(this.weighing, "value", "");
            this.$set(this.message, "value", "");
        },
        setWeighingMessage(){
            let currentWeighing = 0;
            if(this.factor != null){
                currentWeighing = this.factor.weighing;
            }
            this.weighing.message = "Este campo no debe estar vacio ni ser menor a cero o mayor a " + (this.maxWeighing + currentWeighing)
        }
    },
    watch: {
        show(value){
            if(value){
                jQuery(this.$el).modal("show");
            }else{
                jQuery(this.$el).modal("hide");
            }
        },
        factor(value){
            this.name.value = value.name;
            this.weighing.value = value.weighing;
            this.setWeighingMessage();
        },
        maxWeighing(value){
            this.setWeighingMessage();
        }
    },
    mounted() {
        if(this.show)
            jQuery(this.$el).modal("show");
        if(this.factor != null){
            this.name.value = this.factor.name;
            this.weighing.value = this.factor.weighing;
        }
    }
}
</script>
