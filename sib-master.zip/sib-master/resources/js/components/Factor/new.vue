<template>
    <div class="modal fade" data-keyboard="false" data-backdrop="static">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Añadir factor</h5>
                    <button type="button" class="close" @click="close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row" v-if="message.value != ''">
                        <div class="col">
                            <p class="p-2" :class="'alert-' + message.type" v-html="message.value"></p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12 col-md-7">
                            <label for="factor">Nombre del factor</label>
                            <CustomInput id="factor"
                                         placeholder="Nombre del factor"
                                         :required="true"
                                         v-model="name.value"
                                         :is-valid="name.isValid"
                                         :message="name.message"
                                         type="text"></CustomInput>
                        </div>
                        <div class="col-12 col-md-5">
                            <label for="weighing">Ponderación</label>
                            <CustomInput id="weighing"
                                         placeholder="Ponderación"
                                         :required="true"
                                         v-model="weighing.value"
                                         :is-valid="weighing.isValid"
                                         :message="weighing.message"
                                         type="number"></CustomInput>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <h5>Subfactores</h5>
                        </div>
                        <div class="col text-right">
                            <button class="btn btn-success py-0" type="button" @click="addSub">
                                <i class="material-icons align-middle">add</i> Agregar
                            </button>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-5">Nombre</div>
                        <div class="col-5">Dofa</div>
                    </div>

                    <div class="row my-2" v-for="(factor, key) in factors">
                        <div class="col-5">
                            <input type="text" placeholder="Nombre" class="form-control" @change="setFactorName(key, $event)"  :value="factor.name">
                        </div>
                        <div class="col-5">
                            <select class="form-control" v-model="factor.dofa">
                                <option value=""></option>
                                <option value="strength">Fortaleza</option>
                                <option value="weakness">Debilidad</option>
                            </select>
                        </div>

                        <div class="col-2">
                            <button type="button" class="btn btn-danger" title="Eliminar subfactor" @click="removeSub(key)">
                                <i class="material-icons align-middle font-size-19">delete</i>
                            </button>
                        </div>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary w-25" @click="close">Cerrar</button>
                    <button type="button" class="btn btn-red w-25" @click="save">Añadir</button>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import jQuery from "jquery";
import Axios from "axios";
import CustomInput from "../custom-input";

export default {
    data(){
        return {
            name: {
                value: "",
                isValid: null,
                validate(){
                    return this.value != ""
                },
                message: "El nombre del factor es obligatorio"
            },
            weighing: {
                value: "",
                isValid: null,
                validate: () => {
                    return this.weighing.value != "" && this.weighing.value > 0 && this.weighing.value <= this.maxWeighing
                },
                message: "Este campo no debe estar vacio ni ser menor a cero o mayor a " + this.maxWeighing
            },
            factors: [],
            message: {
                type: "success",
                value: ""
            }
        }
    },
    props: {
        show: {
            type: Boolean,
            default: false
        },
        maxWeighing: {
            type: Number,
            default: 100
        }
    },
    components: {
        CustomInput
    },
    methods: {
        close(){
            this.$emit("close");
        },
        validate(){
            this.name.isValid = this.name.validate();
            this.weighing.isValid = this.weighing.validate();
            let factorsError = 0;
            for(let index in this.factors){
                if(this.factors[index].name == "" || this.factors[index].dofa == ""){
                    factorsError += 1;
                }
            }
            return this.name.isValid && this.weighing.isValid && (factorsError == 0);
        },
        save(){
            if(!this.validate()){
                return;
            }
            this.$emit("awaiting");
            Axios.post("/api/CompetitivenessMatrix/factors", {
                name: this.name.value,
                weighing: this.weighing.value,
                factors: this.factors
            }, {
                headers: {
                    Accept: 'application/json',
                    Authorization: 'Bearer ' + localStorage.autenticate_token
                }
            }).then(response => {
                this.$set(this.message, "type", "success");
                this.$set(this.message, "value", response.data.message);
                setTimeout(() => {
                    this.$emit("new-factor");
                    this.close();
                    this.reset();
                }, 500)
                this.$emit("resume");
            }).catch(error => {
                this.$set(this.message, "type", "danger");
                if(error.response.status == 406){
                    this.$set(this, "message", error.response.data.message.join("<br>"));
                }else{
                    this.$set(this, "message", "No fue posible");
                }
                this.reset();
                this.$emit("resume");
            })
        },
        addSub(){
            let errors = this.factors.filter(item => {
                return item.name == "" || item.dofa == 0;
            })
            if(errors.length > 0){
                this.message = "Debe llenar los campos nombre y dofa"
                return false;
            }
            this.factors.push({
                name: "",
                dofa: ""
            });
        },
        removeSub(index){
            this.factors = this.factors.filter((item, key) => {
                return index != key;
            })
        },
        setFactorName(key, e){
            this.$set(this.factors[key], "name", e.target.value)
        },
        reset(){
            this.$set(this.name, "value", "");
            this.$set(this.weighing, "value", "");
            this.factors = [];
            this.$set(this.message, "value", "");
        }
    },
    watch: {
        show(value){
            if(value){
                jQuery(this.$el).modal("show");
            }else{
                jQuery(this.$el).modal("hide");
            }
        },
        maxWeighing(value){
            this.weighing.message = "Este campo no debe estar vacio ni ser menor a cero o mayor a " + value
        }
    },
    mounted() {
        if(this.show)
            jQuery(this.$el).modal("show");
    }
}
</script>
