<template>
    <div class="modal fade" data-keyboard="false" data-backdrop="static">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Detalles del factor {{ factor.name }}</h5>
                    <button type="button" class="close" @click="close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col">
                            <table class="table table-bordered">
                                <thead class="bg-info text-white">
                                <tr>
                                    <th>Nombre</th>
                                    <th>DOFA</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr v-for="subFactor in factor.subFactors">
                                    <td>{{ subFactor.name }}</td>
                                    <td>{{ subFactor.dofa }}</td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary w-25" @click="close">Cerrar</button>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import jQuery from "jquery";
    import Axios from "axios";

    export default {
        name: "DetailFactor",
        props: {
            show: {
                type: Boolean,
                default: false
            },
            factor: {
                type: Object,
                default(){
                    return {};
                }
            }
        },
        methods: {
            close() {
                this.$emit("close");
            }
        },
        watch: {
            show(value){
                if(value){
                    jQuery(this.$el).modal("show");
                }else{
                    jQuery(this.$el).modal("hide");
                }
            }
        },
        mounted() {
            if(this.show)
                jQuery(this.$el).modal("show");
        }
    }
</script>
