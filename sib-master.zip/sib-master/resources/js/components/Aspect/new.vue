<template>
    <div class="modal fade" data-keyboard="false" data-backdrop="static">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Añadir aspecto a mejorar</h5>
                    <button type="button" class="close" @click="close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row" v-if="message.value.length > 0">
                        <div class="col">
                            <p class="p-2" :class="'alert-' + message.type" v-for="value in message.value">
                                {{ value }}
                            </p>
                        </div>
                    </div>
                    <div class="row py-2">
                        <div class="col-12">
                            <label>Factor</label>
                            <select class="form-control" v-model="factor">
                                <template v-for="$factor in factors">
                                    <option :value="$factor.id">{{ $factor.name }}</option>
                                </template>
                            </select>
                        </div>
                    </div>
                    <div class="row py-2">
                        <div class="col-12">
                            <label>Aspecto a mejorar</label>
                            <input type="text" class="form-control" v-model="aspect">
                        </div>
                    </div>
                    <div class="row py-2">
                        <div class="col-12">
                            <label>Impacto</label>
                            <div class="row m-0">
                                <div class="form-check col">
                                    <input class="form-check-input" id="impact1" type="radio" :value="1" v-model="impact">
                                    <label class="form-check-label" for="impact1">
                                        Positivo
                                    </label>
                                </div>
                                <div class="form-check col">
                                    <input class="form-check-input" id="impact2" type="radio" :value="0" v-model="impact">
                                    <label class="form-check-label" for="impact2">
                                        Negativo
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row py-2">
                        <div class="col-12">
                            <label>Intensidad de impacto</label>
                            <div class="row m-0">
                                <div class="form-check col">
                                    <input class="form-check-input" id="intensity1" type="radio" :value="1" v-model="intensity">
                                    <label class="form-check-label" for="intensity1">
                                        Bajo
                                    </label>
                                </div>
                                <div class="form-check col">
                                    <input class="form-check-input" id="intensity2" type="radio" :value="2" v-model="intensity">
                                    <label class="form-check-label" for="intensity2">
                                        Medio
                                    </label>
                                </div>
                                <div class="form-check col">
                                    <input class="form-check-input" id="intensity3" type="radio" :value="3" v-model="intensity">
                                    <label class="form-check-label" for="intensity3">
                                        Alto
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary w-25" @click="close">Cerrar</button>
                    <button type="button" class="btn btn-red w-25" @click="save">Añadir</button>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import jQuery from "jquery";
import Axios from "axios";

export default {
    data(){
        return {
            factor: 0,
            aspect: "",
            impact: 1,
            intensity: 1,
            message: {
                type: "success",
                value: []
            }
        }
    },
    props: {
        show: {
            type: Boolean,
            default: false
        },
        factors: {
            type: Array,
            default: []
        }
    },
    computed: {
        dofa(){
            return this.impact == 1 ? "opportunity" : "threat";
        }
    },
    methods: {
        close() {
            this.message.value = "";
            this.$emit("close");
        },
        validated(){
            let errors = 0;
            this.message.value = [];
            if(this.factor == 0){
                this.message.value.push("El campo factor es obligatorio");
                errors += 1;
            }
            if(this.dofa == 0){
                this.message.value.push("El campo DOFA es obligatorio");
                errors += 1;
            }
            if(this.aspect == 0){
                this.message.value.push("El campo aspecto a mejorar es obligatorio");
                errors += 1;
            }
            if(errors > 0){
                this.message.type = "danger";
                return false;
            }
            return true;
        },
        save(){
            if(!this.validated()){
                return;
            }
            this.$emit("awaiting");
            Axios.post("/api/Pestel/aspect", {
                factor_id: this.factor,
                name: this.aspect,
                dofa: this.dofa,
                impact: this.impact,
                intensity: this.intensity,
            }, {
                headers: {
                    Accept: 'application/json',
                    Authorization: 'Bearer ' + localStorage.autenticate_token
                }
            }).then(response => {
                this.$set(this.message, "type", "success");
                this.message.value.push(response.data.message);
                setTimeout(() => {
                    this.$emit("new-aspect");
                    this.close();
                    this.reset();
                }, 500)
                this.$emit("resume")
            }).catch(error => {
                this.$set(this.message, "type", "danger");
                if(error.response.status == 406){
                    for(let i in error.response.data.message){
                        this.message.value.push(error.response.data.message[i])
                    }
                }else{
                    this.message.value.push("No fue posible");
                }
                this.$emit("resume")
            })
        },
        reset(){
            this.factor = 0;
            this.aspect = "";
            this.dofa = 0;
            this.impact = 0;
            this.intensity = 1;
        }
    },
    watch: {
        show(value) {
            if (value) {
                jQuery(this.$el).modal("show");
            } else {
                jQuery(this.$el).modal("hide");
            }
        },
    },
    mounted() {
        if(this.show)
            jQuery(this.$el).modal("show");
    }
}
</script>
