<template>
    <div id="notifications" class="text-red" :class="{active: active}" @click="active = !active">
        <i class="material-icons">
            notifications
        </i>
        <span class="number" v-if="total > 0">{{ total }}</span>
        <div class="notifications">
            <table class="table table-hover">
                <template v-for="notification in notifications">
                    <tr>
                        <td>{{ notification.text }}</td>
                    </tr>
                </template>
            </table>
            <p class="text-center">
                <a href="#">Ver todas las notificaciones</a>
            </p>
        </div>
    </div>
</template>

<script>
import Axios from 'axios';

export default {
    data(){
        return {
            total: 0,
            notifications: [],
            active: false
        }
    },
    methods: {
        getNotifications(){
            Axios.get("/api/notifications", {
                headers: {
                    Accept: 'application/json',
                    Authorization: 'Bearer ' + localStorage.autenticate_token
                },
            }).then(response => {
                this.total = response.data.total;
                this.notifications = response.data.notifications;
                setTimeout(this.getNotifications, 10000);
            }).catch(error => {

            })
        }
    },
    mounted() {
        this.getNotifications();
    }
}
</script>

<style>
    #notifications{
        cursor: pointer;
        position:relative;
    }
    #notifications .number {
        position: absolute;
        color: #fff;
        background-color: #ff0125;
        width: 15px;
        height: 15px;
        line-height: 16px;
        text-align: center;
        font-size: 10px;
        border-radius: 50%;
        right: -25%;
        top: -10%;
    }

    #notifications .notifications {
        position: absolute;
        background-color: #fff;
        color: #333;
        width: 200px;
        z-index: 10;
        border: 1px solid #ededed;
        left: -150%;
        transition: all 1s;
        opacity: 0;
        pointer-events: none;
    }

    #notifications.active .notifications {
        opacity: 1;
        pointer-events: all;
    }
    #notifications.active .notifications tr:hover {
        background-color: #dae0e5;
    }
</style>
