<template>
    <div class="table-responsive">
        <table class="table table-bordered table-hover">
            <thead>
            <tr>
                <th>{{ label1 }}</th>
                <th>{{ label2 }}</th>
                <th>Tema estretegico</th>
                <th>Estrategia</th>
                <th v-if="!finalized"></th>
            </tr>
            </thead>
            <tbody>
            <template v-for="item in data">
                <cell :title1="item[key1].name"
                      :title2="item[key2].name"
                      :strategies="strategies"
                      :categories="categories"
                      :item="item"
                      :modelParts="key1 + '-' + key2"
                      @showAlert="showAlert($event)"
                      :finalized="finalized"></cell>
            </template>
            <tr v-if="data.length == 0">
                <td colspan="5" class="text-center">
                    Sin datos
                </td>
            </tr>
            </tbody>
        </table>
    </div>
</template>

<script>
import Axios from "axios";

import cell from "./cell";

export default {
    props: {
        label1: {
            type: String,
            default: ""
        },
        label2: {
            type: String,
            default: ""
        },
        key1: {
            type: String,
            default: ""
        },
        key2: {
            type: String,
            default: ""
        },
        data: {
            type: Array,
            default(){
                return []
            }
        },
        categories: {
            type: Array,
            default(){
                return []
            }
        },
        strategies: {
            type: Array,
            default(){
                return []
            }
        },
        finalized: {
            type: Boolean,
            default: false
        }
    },
    components: {
        cell
    },
    methods: {
        showAlert(data){
            this.$emit("showAlert", data);
        }
    }
}
</script>
