<template>
    <tr>
        <td>
            <p style="width: 200px">{{ title1 }}</p>
        </td>
        <td>
            <p style="width: 200px">{{ title2 }}</p>
        </td>
        <td>
            <select class="form-control" style="width: 200px" v-model="category" v-if="!finalized">
                <template v-for="$category in categories">
                    <option :value="$category.id">{{ $category.name }}</option>
                </template>
            </select>
            <p v-else>{{ getCategoryName(category) }}</p>
        </td>
        <td>
            <select class="form-control" style="width: 200px" v-model="strategy" v-if="!finalized">
                <option value=""></option>
                <template v-for="$strategy in strategies">
                    <option :value="$strategy.id">{{ $strategy.name }}</option>
                </template>
                <option value="other">Otro</option>
            </select>
            <p v-else>{{ getStrategyName(strategy) }}</p>

            <div class="input-group my-3" v-if="other">
                <input type="text" class="form-control" placeholder="Otro" v-model="otherText">
            </div>
        </td>
        <td v-if="!finalized">
            <button type="button" class="btn btn-success" @click="send(item.id)">
                Guardar
            </button>
        </td>
    </tr>
</template>

<script>
    import Axios from 'axios';
    export default {
        data(){
            return {
                category: 0,
                other: false,
                otherText: "",
                strategy: "",
            }
        },
        props: {
            item: {
                type: Object,
                default(){
                    return {}
                }
            },
            categories: {
                type: Array,
                default(){
                    return []
                }
            },
            strategies: {
                type: Array,
                default(){
                    return []
                }
            },
            title1: {
                default: ""
            },
            title2: {
                default: ""
            },
            modelParts: {
                default: ""
            },
            finalized: {
                type:Boolean,
                default: false
            }
        },
        watch: {
            strategy(value){
                if(value == "other"){
                    this.other = true;
                }
            },
            item(value){
                console.log("w", value);
                if(this.item.strategy_summary !== null){
                    this.$set(this, "category", this.item.strategy_summary.category_id);
                    this.$set(this, "strategy", this.item.strategy_summary.strategy_id);
                }
            }
        },
        methods: {
            validate(){
                let message = "";
                if(this.strategy == 0){
                    message += "El campo estrategia es obligatorio<br>";
                }else if(this.strategy == "other"){
                    if(this.otherText == ''){
                        message += "El campo otro es obligatorio<br>";
                    }
                }
                if(this.category == 0){
                    message += "El campo categoria es obligatorio";
                }

                if(message != ''){
                    this.$emit("showAlert", {
                        title: "Tema estrategico",
                        message: message,
                        type: "danger",
                    });
                    return false;
                }

                return true;
            },
            send(){
                if(this.validate()){
                    Axios.post("/api/StrategySummary", {
                        strategy: this.strategy == "other" ? this.otherText : this.strategy,
                        category_id: this.category,
                        modelParts: this.modelParts,
                        model_id: this.item.id
                    }, {
                        headers: {
                            Accept: 'application/json',
                            Authorization: 'Bearer ' + localStorage.autenticate_token
                        }
                    })
                        .then(response => {

                            this.other = false;
                            this.$emit("showAlert", {
                                title: "Tema estrategico",
                                message: response.data.message,
                                type: "success",
                            });
                        }).catch(error => {
                        this.$emit("showAlert", {
                            title: "Tema estrategico",
                            message: error.response.data.message,
                            type: "danger",
                        });
                    })
                }

            },
            getStrategyName(id){
                for(let index in this.strategies){
                    if(this.strategies[index].id == id){
                        return this.strategies[index].name;
                    }
                }
            },
            getCategoryName(id){
                for(let index in this.categories){
                    if(this.categories[index].id == id){
                        return this.categories[index].name;
                    }
                }
            }
        },
        mounted() {
            console.log(this.item)
            if(this.item.strategy_summary !== null){
                this.category = this.item.strategy_summary.category_id;
                this.strategy = this.item.strategy_summary.strategy_id;
            }
        }
    }
</script>
