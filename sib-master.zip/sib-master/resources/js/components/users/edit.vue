<template>
    <div class="modal fade" id="detailBudget" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header alert">
                    <h5 class="modal-title">{{ user.name }}</h5>
                    <button type="button" class="close" @click="close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                    <div class="row" v-if="message != ''">
                        <div class="col-12 alert-danger">
                            <p>{{ message }}</p>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-12 mb-4">
                            <label for="name">Nombre</label>
                            <input type="text" class="form-control" name="name" id="name" v-model="name">
                        </div>
                        <div class="col-12 mb-4">
                            <label for="email">Email</label>
                            <input type="text" class="form-control" name="name" id="email" v-model="email">
                        </div>
                        <div class="col-12">
                            <select-office :area="area"
                                           :office="office"
                                           @area="area = $event"
                                           @office="office = $event"></select-office>
                        </div>

                        <div class="col-12 mb-4 pl-5">
                            <input type="checkbox" class="form-check-input" id="changePassword" v-model="changePassword">
                            <label class="form-check-label" for="changePassword">Cambiar contraseña</label>
                        </div>

                        <div class="col-12 mb-4" v-if="changePassword">
                            <div class="row">
                                <div class="col-6">
                                    <label for="password">Nueva Contraseña</label>
                                    <div class="input-group">
                                        <input :type="showPassword ? 'text' : 'password'" class="form-control" id="password" v-model="password">
                                        <div class="input-group-append">
                                            <button type="button"
                                                    class="btn btn-secondary material-icons"
                                                    @click="showPassword = !showPassword">{{ showPassword ? "visibility_off" : "visibility"}}</button>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <label for="confirmPassword">Confirmación contraseña</label>
                                    <div class="input-group">
                                        <input :type="showConfirmPassword ? 'text' : 'password'" class="form-control" id="confirmPassword" v-model="confirmPassword">
                                        <div class="input-group-append">
                                            <button type="button"
                                                    class="btn btn-secondary material-icons"
                                                    @click="showConfirmPassword = !showConfirmPassword">{{ showConfirmPassword ? "visibility_off" : "visibility"}}</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="col-12 mb-4 pl-5">
                            <input type="checkbox" class="form-check-input" id="changePermissions" v-model="changePermissions">
                            <label class="form-check-label" for="changePermissions">Cambiar permisos</label>
                        </div>

                        <div class="col-12 mb-4" v-if="changePermissions">
                            <user-permissions :user="user.id" v-model="permissions"></user-permissions>
                        </div>

                    </div>

                </div>
                <div class="modal-footer">
                    <div class="w-100">
                        <div class="row justify-content-end">
                            <div class="col-6">
                                <button type="button" class="btn btn-secondary w-100"  @click="close">Cerrar</button>
                            </div>
                            <div class="col-6">
                                <button type="button" class="btn btn-red w-100"  @click="send">Editar</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</template>

<script>
    import Axios from "axios";
    import jQuery from "jquery";

    import selectOffice from "../Office/selectWithArea";
    import userPermissions from "./userPermissions";
    export default {
        data(){
            return {
                message: "",
                name: "",
                email: "",
                area: 0,
                office: 0,
                password: "",
                confirmPassword: "",
                changePassword: false,
                showPassword: false,
                showConfirmPassword: false,
                changePermissions: false,
                permissions: {}
            }
        },
        components: {
            selectOffice,
            userPermissions
        },
        props: {
            show: {
                type: Boolean,
                default: false
            },
            user: {
                type: Object,
                default(){
                    return {}
                }
            }
        },
        methods: {
            close() {
                this.$emit('close');
            },
            validate(){
                this.message = "";
                if(this.name == ''){
                    this.message = "El campo nombre es obligatorio";
                    return false;
                }
                if(this.email == ""){
                    this.message = "El campo email es obligatorio";
                    return false;
                }
                if(this.office == 0){
                    this.message = "El campo oficina es obligatorio";
                    return false;
                }
                if(this.changePassword){
                    if(this.password == ''){
                        this.message = "El campo contraseña es obligatorio"
                        return false;
                    }
                    if(this.confirmPassword == ''){
                        this.message = "El campo confirma contraseña es obligatorio"
                        return false;
                    }
                    if(this.password != this.confirmPassword){
                        this.message = "El campo contraseña y confirmacion de contraseña no son iguales";
                        return false;
                    }
                }

                return true;
            },
            send(){
                if(this.validate()){
                    let data = {
                        name: this.name,
                        email: this.email,
                        office_id: this.office,
                        changePassword: this.changePassword,
                        password: this.password
                    };
                    if(this.changePermissions){
                        data['permissions'] = this.permissions;
                    }
                    Axios.put("/api/users/" + this.user.id, data, {
                        headers: {
                            Accept: 'application/json',
                            Authorization: 'Bearer ' + localStorage.autenticate_token
                        }
                    }).then(response => {
                        this.$emit("success", response.data.message);
                        this.close();
                    }).catch(error => {
                        this.$emit("error", error.response.data.message);
                    })
                }
            }
        },
        watch: {
            show(value) {
                jQuery(this.$el).modal(value ? "show" : "hide");
            },
            user(value){
                this.name = value.name;
                this.email = value.email;
                this.area = parseInt(value.office == undefined ? "" : value.office.area_id);
                this.office = parseInt(value.office == undefined ? "" : value.office.id);
                this.password = "";
                this.confirmPassword = "";
                this.changePassword = false;
                this.showPassword = false;
                this.showConfirmPassword = false;
                this.permissions = {};
            }
        }
    }
</script>
