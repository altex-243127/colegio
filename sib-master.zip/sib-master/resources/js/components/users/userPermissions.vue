<template>
    <div class="row" v-if="!null">
        <div class="col-6" v-for="module in modules">
            <label>
                <input type="checkbox" @change="setPermissionByModule($event, module.actions)"> {{ module.name }}
            </label>
            <div class="list-group">
                <label class="list-group-item list-group-item-action" v-for="action in module.actions">
                    <input type="checkbox" :checked="permissions[action.id]" @change="setPermission($event, action.id)"> {{action.name}}
                </label>
            </div>
        </div>
    </div>
</template>
<script>
    import axios from 'axios';
    export default {
        data(){
            return {
               modules: [],
               permissions: {},
            }
        },
        props: {
            user: {
                type: Number,
                default: null
            }
        },
        methods: {
            getPermissionsUser(){
                axios.get("/api/permissionsUser/" + this.user, {
                    headers: {
                        Accept: 'application/json',
                        Authorization: 'Bearer ' + localStorage.autenticate_token
                    }
                })
                    .then(response => {
                        let permissions = {}
                        for(let index in response.data){
                            permissions[response.data[index]["action_id"]] = true;
                        }
                        this.$set(this, "permissions", permissions);
                    }).catch(error => {
                    console.log(error.response)
                })
            },
            getModulesAndActions(){
                axios.get("/api/modulesWithActions", {
                    headers: {
                        Accept: 'application/json',
                        Authorization: 'Bearer ' + localStorage.autenticate_token
                    }
                })
                    .then(response => {
                        this.modules = response.data;
                    }).catch(error => {
                        console.log(error.response)
                })
            },
            setPermission(event, action){
                this.$set(this.permissions, action, event.target.checked);
            },
            setPermissionByModule(event, actions){
                actions.map(item => {
                    this.$set(this.permissions, item.id, event.target.checked);
                })
            }
        },
        watch: {
            user(value){
                this.getPermissionsUser();
            },
            permissions(value){
                this.$emit("input", value);
            }
        },
        mounted() {
            this.getModulesAndActions();
            this.getPermissionsUser();
        }
    }
</script>
