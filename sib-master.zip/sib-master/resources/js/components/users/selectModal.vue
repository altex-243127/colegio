<template>
    <div class="modal fade" data-keyboard="false" data-backdrop="static">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Seleccionar usuario</h5>
                    <button type="button" class="close" @click="close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-12">
                            <label>Usuario</label>
                            <select-user v-model="user"></select-user>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary w-25" @click="close">Cerrar</button>
                    <button type="button" class="btn btn-red w-25" @click="select">Seleccionar</button>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import selectUser from "./select";

    export default {
        data(){
            return {
                user: {}
            }
        },
        components: {
            selectUser
        },
        methods: {
            close() {
                this.$emit("close");
            },
            select(){
                this.$emit("select", this.user);
            }
        }
    }
</script>
