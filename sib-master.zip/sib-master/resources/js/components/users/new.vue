<template>
    <div class="modal fade" id="detailBudget" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header alert">
                    <h5 class="modal-title">Nuevo usuario</h5>
                    <button type="button" class="close" @click="close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                    <div class="row" v-if="message != ''">
                        <div class="col-12 alert-danger">
                            <p>{{ message }}</p>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-12 mb-4">
                            <label for="name">Nombre</label>
                            <input type="text" class="form-control" name="name" id="name" v-model="name">
                        </div>
                        <div class="col-12 mb-4">
                            <label for="email">Email</label>
                            <input type="text" class="form-control" name="name" id="email" v-model="email">
                        </div>
                        <div class="col-12">
                            <select-office :area="area"
                                           :office="office"
                                           @area="area = $event"
                                           @office="office = $event"></select-office>
                        </div>


                        <div class="col-12 mb-4">
                            <div class="row">
                                <div class="col-6">
                                    <label for="password">Contraseña</label>
                                    <div class="input-group">
                                        <input :type="showPassword ? 'text' : 'password'" class="form-control" id="password" v-model="password">
                                        <div class="input-group-append">
                                            <button type="button"
                                                    class="btn btn-secondary material-icons"
                                                    @click="showPassword = !showPassword">{{ showPassword ? "visibility_off" : "visibility"}}</button>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <label for="confirmPassword">Confirmación contraseña</label>
                                    <div class="input-group">
                                        <input :type="showConfirmPassword ? 'text' : 'password'" class="form-control" id="confirmPassword" v-model="confirmPassword">
                                        <div class="input-group-append">
                                            <button type="button"
                                                    class="btn btn-secondary material-icons"
                                                    @click="showConfirmPassword = !showConfirmPassword">{{ showConfirmPassword ? "visibility_off" : "visibility"}}</button>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>

                        <div class="col-12 mb-4">
                            <h5>Permisos</h5>
                            <user-permissions :user="0" v-model="permissions"></user-permissions>
                        </div>

                    </div>

                </div>
                <div class="modal-footer">
                    <div class="w-100">
                        <div class="row justify-content-end">
                            <div class="col-6">
                                <button type="button" class="btn btn-secondary w-100"  @click="close">Cerrar</button>
                            </div>
                            <div class="col-6">
                                <button type="button" class="btn btn-red w-100"  @click="send">Crear usuario</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</template>

<script>
    import Axios from "axios";
    import jQuery from "jquery";

    import selectOffice from "../Office/selectWithArea";
    import userPermissions from "./userPermissions";
    export default {
        data(){
            return {
                message: "",
                name: "",
                email: "",
                area: 0,
                office: 0,
                password: "",
                confirmPassword: "",
                showPassword: false,
                showConfirmPassword: false,
                changePermissions: false,
                permissions: {}
            }
        },
        components: {
            selectOffice,
            userPermissions
        },
        props: {
            show: {
                type: Boolean,
                default: false
            }
        },
        methods: {
            close() {
                this.$emit('close');
            },
            validate(){
                this.message = "";
                if(this.name == ''){
                    this.message = "El campo nombre es obligatorio";
                    return false;
                }
                if(this.email == ""){
                    this.message = "El campo email es obligatorio";
                    return false;
                }
                if(this.office == 0){
                    this.message = "El campo oficina es obligatorio";
                    return false;
                }
                if(this.password == ''){
                    this.message = "El campo contraseña es obligatorio"
                    return false;
                }
                if(this.confirmPassword == ''){
                    this.message = "El campo confirma contraseña es obligatorio"
                    return false;
                }
                if(this.password != this.confirmPassword){
                    this.message = "El campo contraseña y confirmacion de contraseña no son iguales";
                    return false;
                }

                return true;
            },
            send(){
                if(this.validate()){
                    let data = {
                        name: this.name,
                        email: this.email,
                        office_id: this.office,
                        password: this.password,
                        permissions: this.permissions
                    }

                    Axios.post("/api/users", data, {
                        headers: {
                            Accept: 'application/json',
                            Authorization: 'Bearer ' + localStorage.autenticate_token
                        }
                    }).then(response => {
                        this.$emit("success", response.data.message);
                        this.close();
                    }).catch(error => {
                        this.$emit("error", error.response.data.message);
                    })
                }
            }
        },
        watch: {
            show(value) {
                jQuery(this.$el).modal(value ? "show" : "hide");
            }
        }
    }
</script>
