<template>
    <div class="w-100 mb-3">
        <div class="input-group">
            <input :type="type"
                   class="form-control"
                   :placeholder="placeholder"
                   :value="value"
                   :required="required"
                   :class="inputErrorClass"
                   v-on:input="updateValue($event.target.value)">
        </div>
        <span class="text-danger px-2" v-if="isValid === false">
            {{ message }}
        </span>
    </div>

</template>

<script>
    export default {
        props: {
            type: {
                type: String,
                default: "text"
            },
            placeholder: {
                type: String,
                default: ""
            },
            value: {
                type: [String, Number],
                default: ""
            },
            required: {
                type: Boolean,
                default: false
            },
            isValid: {
                type: Boolean,
                default: false
            },
            message: {
                type: String,
                default: ""
            }
        },
        computed: {
            inputErrorClass(){
                if(this.isValid === false){
                    return 'border-danger';
                }
            }
        },
        methods : {
            updateValue(value){
                this.$emit('input', value)
            }
        }
    }
</script>
