<template>
    <div id="pageLoad" :class="{ show : state != 1 }">
        <div class="shadow"></div>
        <div class="content">
            <div class="load text-center" v-if="state == 0">
                <div class="img position-relative rounded-circle" style="background-image: url('/logo.png')">
                    <div class="mask" :style="{ opacity : opacity }"></div>
                </div>
                <h4 class="text-center py-3">Cargando</h4>
            </div>
            <div class="failed text-center bg-white border rounded p-3" v-if="state == 2">
                <h3>Ocurrio un error a la hora de cargar la pagina</h3>
                <p class="text-center">
                    <button class="btn btn-red" @click="goBack">Volver</button>
                    <button class="btn btn-success" @click="onRefresh">Reintentar</button>
                </p>
            </div>
            <div class="failed text-center bg-white border rounded p-3" v-if="state == 3">
                <h3>No se encuentra autorizado para ver este modulo</h3>
                <p class="text-center">
                    <button class="btn btn-red" @click="goBack">Volver</button>
                </p>
            </div>
            <div class="failed text-center bg-white border rounded p-3" v-if="state == 4">
                <h3>Primero se debe finalizar <span v-if="depends.length <= 1">el modulo</span><span v-else>los modulos</span></h3>
                <ul>
                    <li class="text-left m-0" v-for="depend in depends">
                        <router-link :to="getRouteByName(depend).path">
                            {{ depend }}
                        </router-link>
                    </li>
                </ul>
                <p class="text-center">
                    <button class="btn btn-red" @click="goBack">Volver</button>
                </p>
            </div>
        </div>
    </div>
</template>
<script>
// 0: loading, 1: complete, 2: failed, 3: not authorized, 4: dependencies not finalized

export default {
    data(){
        return {
            opacity: 1
        }
    },
    props: {
        state: {
            type: Number,
            default: 0
        },
        depends: {
            type: Array,
            default(){
                []
            }
        }
    },
    methods: {
        animation(state){
            if(state != 0){
                return;
            }
            if(this.opacity == 1){
                this.opacity = 0;
            }else{
                this.opacity = 1;
            }
            setTimeout(this.animation, 1000);
        },
        onRefresh(){
            this.$emit("refresh")
            this.$emit("pageChanges", {
                state: 0
            })
        },
        goBack(){
            this.$router.go(-1);
        },
        getRouteByName(name){
            const routes = this.$router.options.routes;
            for(let route in routes){
                if(routes[route].name == name){
                    return routes[route];
                }
            }
        }
    },
    watch: {
        state(value){
            console.log("load", value);
            this.animation(value)
        }
    },
    mounted() {
        this.animation(this.state);
    }
}
</script>
<style scoped>
    #pageLoad {
        position: fixed;
        width: 100%;
        height: 100%;
        top: 0%;
        left: 0%;
        opacity: 0;
        pointer-events: none;
        transition: 1s all;
        z-index: 5000;
    }
    #pageLoad.show {
        opacity: 1;
        pointer-events: all;
    }
    #pageLoad .shadow {
        background-color: #ffffff;
        position: absolute;
        top: 0%;
        left: 0%;
        width: 100%;
        height: 100%;
        opacity: 0.6;
    }
    #pageLoad .content {
        position: absolute;
        top: 25%;
        left: 25%;
        width: 50%;
        height: 50%;
    }
    #pageLoad .load {
        height: 100%;
    }

    #pageLoad .load .img {
        width: 200px;
        height: 200px;
        display: block;
        margin: auto;
        background-position: center;
        background-size: contain;
        background-repeat: no-repeat;
        overflow: hidden;
    }
    .mask {
        position: absolute;
        width: 100%;
        height: 100%;
        bottom: 0%;
        background-color: rgba(255, 255, 255, 0.8);
        transition: 1s all;
    }

</style>
