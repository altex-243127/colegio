<template>
    <div class="modal fade" data-keyboard="false" data-backdrop="static">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Enviar solicitudes de revisión</h5>
                    <button type="button" class="close" @click="close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col">
                            <template v-for="user in users">

                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">
                                            <input type="checkbox" :id="'check_user_' + user.id" :value="user.id" @change="selectUser">
                                        </div>
                                    </div>
                                    <div class="input-group-append" style="width:90%">
                                    <label :for="'check_user_' + user.id" class="input-group-text w-100 bg-white">
                                        {{ user.name }} &lt;{{ user.email }}&gt;
                                    </label>
                                    </div>
                                </div>

                            </template>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary w-25" @click="close">Cerrar</button>
                    <button type="button" class="btn btn-red w-25" @click="send">Enviar</button>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import jQuery from "jquery";
import Axios from "axios";

export default {
    data(){
        return {
            selectUsers: []
        }
    },
    props: {
        show: {
            type: Boolean,
            default: false
        },
        users: {
            type: Array,
            default(){
                return []
            }
        }
    },
    methods: {
        close() {
            this.$emit("close");
        },
        selectUser(e){
            const el = e.target;
            if(el.checked){
                this.selectUsers.push(el.value);
            }else{
                let newArray = this.selectUsers.filter(item => {
                    return item != el.value;
                })
                this.selectUsers = newArray;
            }
        },
        send(){
            this.$emit("awaiting");
            Axios.post("/api/Dofa/usersRequest", {
                users: this.selectUsers
            }, {
                headers: {
                    Accept: 'application/json',
                    Authorization: 'Bearer ' + localStorage.autenticate_token
                }
            })
            .then(response => {
                this.close();
                this.$emit("showAlert", {
                    title: "Respuesta exitosa",
                    message: response.data.message,
                    type: "success"
                })
                this.$emit("resume")
            })
            .catch(error => {
                this.close();
                this.$emit("showAlert", {
                    title: "Hubo un problema",
                    message: "No fue posible enviar las solicitudes",
                    type: "danger"
                })
                this.$emit("resume")
            })
        }
    },
    watch: {
        show(value) {
            if (value) {
                jQuery(this.$el).modal("show");
            } else {
                jQuery(this.$el).modal("hide");
            }
        }
    },
    mounted() {
        if(this.show)
            jQuery(this.$el).modal("show");
    }
}
</script>
