<template>
    <tbody>
        <template v-for="(objective, objectiveIndex) in perspective.objectives">
            <template v-for="(strategy, key, index) in strategies[perspective.name][objective.id]">
                <row :strategy="strategy"
                     :balanced-scorecard="strategy.balanced_scorecards[0] == undefined ? {} : strategy.balanced_scorecards[0]"
                     :key="strategy.id + '-' + objectiveIndex + '-' + perspective.id + '-' + index"
                     :objective="objective"
                     :frequencies="frequencies"
                     :finalized="finalized"
                     :showAdd="strategy.balanced_scorecards.length == 1"
                     @add="addScorecard(objective, objectiveIndex, strategy.id)"
                     @success="success($event)">
                    <template v-slot:start>
                        <template v-if="index == 0">
                            <td class="align-middle perspective" :rowspan="getRowSpan(strategies[perspective.name][objective.id])">{{ perspective.name }}</td>
                            <td class="align-middle objective" :rowspan="getRowSpan(strategies[perspective.name][objective.id])">{{ objective.objective }} {{objectiveIndex}}</td>
                        </template>
                        <td class="align-middle" :rowspan="strategy.balanced_scorecards.length == 0 ? 1 : strategy.balanced_scorecards.length">
                            <div class="border p-2 mb-2">
                                {{ strategy.strategy.name }}
                            </div>
                        </td>
                    </template>
                </row>
                <template v-for="(balancedScorecard, index) in strategy.balanced_scorecards" v-if="index>0">
                    <row :strategy="strategy"
                         :balanced-scorecard="balancedScorecard"
                         :key="strategy.id + '-' + objectiveIndex + '-' + perspective.id + '-' + index"
                         :objective="objective"
                         :frequencies="frequencies"
                         :showAdd="strategy.balanced_scorecards.length == index+1"
                         :finalized="finalized"
                         @add="addScorecard(objective, objectiveIndex, strategy.id)"
                         @success="success($event)">
                    </row>
                </template>
            </template>
        </template>
    </tbody>
</template>
<script>
import row from "./row";
export default {
    components: {
        row
    },
    data(){
        return {
            newBalancedScorecard: {}
        }
    },
    props: {
        perspective: {
            type: Object,
            default(){
                return {}
            }
        },
        frequencies: {
            type: Array,
            default(){
                return []
            }
        },
        finalized: {
            type: Boolean,
            default: false
        }
    },
    watch: {
    },
    methods: {
        getRowSpan(strategy){
            let span = 0;

            Object.entries(strategy).forEach(([key, value]) => {
                span += value.balanced_scorecards.length == 0 ? 1 : value.balanced_scorecards.length;
            })
            return span;
        },
        success(message){
            this.$emit("success", message);
        },
        addScorecard(objective, index, id){
            this.perspective.objectives[index].category.strategic_issues.map((item, strategyIndex) => {
                console.log(item.id, id, index);
                if(item.id == id){
                    this.$set(this.perspective.objectives[index].category.strategic_issues[strategyIndex].balanced_scorecards, this.perspective.objectives[index].category.strategic_issues[strategyIndex].balanced_scorecards.length, {})
                }
            });
        },
        strategiesByObjective(objective){
            let strategies = {};
            for(let index in objective.category.strategic_issues){
                strategies[objective.category.strategic_issues[index].strategy_id] = objective.category.strategic_issues[index];
                if(strategies[objective.category.strategic_issues[index].strategy_id].balanced_scorecards.length == 0){
                    strategies[objective.category.strategic_issues[index].strategy_id].balanced_scorecards.push({});
                }
            }
            return strategies;
        }
    },
    computed: {
        strategies(){
            let strategies = {};
            for(let index in this.perspective.objectives){
                if(strategies[this.perspective.name] == undefined){
                    strategies[this.perspective.name] = {};
                }
                strategies[this.perspective.name][this.perspective.objectives[index].id] = this.strategiesByObjective(this.perspective.objectives[index])

            }
            return strategies;
        }
    }
}
</script>
