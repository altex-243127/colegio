<template>
    <tbody>
    <tr>
        <td class="align-middle">
            <div class="border p-2 mb-2" >
                {{ strategy }}
            </div>
        </td>
        <td class="align-middle">
            <input type="text" class="form-control" v-model="name" v-if="!finalized">
            <span v-else>{{ name }}</span>
        </td>
        <td class="align-middle">
            <textarea rows="2" class="form-control" v-model="formula" v-if="!finalized"></textarea>
            <span v-else>{{ formula }}</span>
        </td>
        <td class="align-middle">
            <input type="number" class="form-control" v-model="desired_goal" v-if="!finalized">
            <span v-else>{{ desired_goal }}</span>
        </td>
        <td class="align-middle">
            <input type="number" class="form-control" v-model="acceptable_goal" v-if="!finalized">
            <span v-else>{{ name }}</span>
        </td>
        <td class="align-middle">
            <input type="number" class="form-control" v-model="minimum_goal" v-if="!finalized">
            <span v-else>{{ minimum_goal }}</span>
        </td>
        <td class="align-middle">
            <select class="form-control" v-model="measurement_frequency" v-if="!finalized">
                <template v-for="frequency in frequencies">
                    <option :value="frequency.id">{{ frequency.name }}</option>
                </template>
            </select>
            <span v-else>{{ measurement_frequency }}</span>
        </td>
        <td class="align-middle">
            <select class="form-control" v-model="evaluation_frequency" v-if="!finalized">
                <template v-for="frequency in frequencies">
                    <option :value="frequency.id">{{ frequency.name }}</option>
                </template>
            </select>
            <span v-else>{{ evaluation_frequency }}</span>
        </td>
        <td class="align-middle">
            <input type="text" class="form-control" v-model="measurement_source"  v-if="!finalized">
            <span v-else>{{ measurement_source }}</span>
        </td>
        <td class="align-middle">
            <userSelect v-model="responsible_measurement" v-if="!finalized"></userSelect>
            <span v-else>{{ responsible_measurement.name }}</span>
        </td>
        <td class="align-middle">
            <userSelect v-model="head_analysis" v-if="!finalized"></userSelect>
            <span v-else> {{ head_analysis.name }}</span>
        </td>
        <td class="align-middle">
            <areaSelect v-model="area" v-if="!finalized"></areaSelect>
            <span v-else>{{ area.name }}</span>
        </td>
        <td class="align-middle" v-if="!finalized">
            <button type="button" class="btn btn-red" @click="send" v-if="newElement">
                Guardar
            </button>
            <button type="button" class="btn btn-red" @click="edit" v-else>
                Editar
            </button>
        </td>
    </tr>
    <template  v-for="(strategy, key) in strategies">
        <row-recursive :key="100+key"
             :objective="objective"
             :frequencies="frequencies"
             :finalized="finalized"
             :first="false"
             @success="success($event)"
             @error="error($event)">
        </row-recursive>
    </template>
    </tbody>

</template>
<script>
import Axios from 'axios';

import userSelect from "../../components/users/select";
import areaSelect from "../../components/area/select";
import rowRecursive from "./row"

export default {
    name: "row",
    data(){
        return {
            name: "",
            formula: "",
            desired_goal: 0,
            acceptable_goal: 0,
            minimum_goal: 0,
            measurement_frequency: 0,
            evaluation_frequency: 0,
            measurement_source: "",
            responsible_measurement: {},
            head_analysis: {},
            area: 0,
            balanced: 0,
            newElement: true
        }
    },
    props: {
        strategy: {
            type: String,
            default: ""
        },
        objective: {
            type: Object,
            default(){
                return {}
            }
        },
        frequencies: {
            type: Array,
            default(){
                return []
            }
        },
        finalized: {
            type: Boolean,
            default: false
        }
    },
    components: {
        userSelect,
        areaSelect,
        rowRecursive
    },
    methods: {
        send(){
            Axios.post("/api/BalancedScorecard", {
                objective_id: this.objective.id,
                name: this.name,
                formula: this.formula,
                desired_goal: this.desired_goal,
                acceptable_goal: this.acceptable_goal,
                minimum_goal: this.minimum_goal,
                measurement_frequency_id: this.measurement_frequency,
                evaluation_frequency_id: this.evaluation_frequency,
                measurement_source: this.measurement_source,
                responsible_measurement_id: this.responsible_measurement.id,
                head_analysis_id: this.head_analysis.id,
                area_id: this.area.id
            }, {
                headers: {
                    Accept: 'application/json',
                    Authorization: 'Bearer ' + localStorage.autenticate_token
                }
            }).then(response => {
                this.newElement = false;
                this.$emit("success", response.data.message);
            }).catch(error => {
                this.$emit("error", error.response.data.message);
            })
        },
        edit(){
            Axios.put("/api/BalancedScorecard/" + this.balanced, {
                objective_id: this.objective.id,
                name: this.name,
                formula: this.formula,
                desired_goal: this.desired_goal,
                acceptable_goal: this.acceptable_goal,
                minimum_goal: this.minimum_goal,
                measurement_frequency_id: this.measurement_frequency,
                evaluation_frequency_id: this.evaluation_frequency,
                measurement_source: this.measurement_source,
                responsible_measurement_id: this.responsible_measurement.id,
                head_analysis_id: this.head_analysis.id,
                area_id: this.area.id
            }, {
                headers: {
                    Accept: 'application/json',
                    Authorization: 'Bearer ' + localStorage.autenticate_token
                }
            }).then(response => {
                this.$emit("success", response.data.message);
            }).catch(error => {
                this.$emit("error", error.response.data.message);
            })
        },
        setInitData(){
            for(let index in this.objective.balanced_scorecard){
                this.balanced = this.objective.balanced_scorecard[index].balanced_scorecard.id;
                this.name = this.objective.balanced_scorecard[index].balanced_scorecard.name;
                this.formula = this.objective.balanced_scorecard[index].balanced_scorecard.formula;
                this.desired_goal = this.objective.balanced_scorecard[index].balanced_scorecard.desired_goal;
                this.acceptable_goal = this.objective.balanced_scorecard[index].balanced_scorecard.acceptable_goal;
                this.minimum_goal = this.objective.balanced_scorecard[index].balanced_scorecard.minimum_goal;
                this.measurement_frequency = this.objective.balanced_scorecard[index].balanced_scorecard.measurement_frequency_id;
                this.evaluation_frequency = this.objective.balanced_scorecard[index].balanced_scorecard.evaluation_frequency_id;
                this.measurement_source = this.objective.balanced_scorecard[index].balanced_scorecard.measurement_source;
                this.responsible_measurement = this.objective.balanced_scorecard[index].balanced_scorecard.responsible_measurement;
                this.head_analysis = this.objective.balanced_scorecard[index].balanced_scorecard.head_analysis;
                this.area = this.objective.balanced_scorecard[index].balanced_scorecard.area;
                this.newElement = false;
            }

        }
    },
    watch: {
        objective(){
            this.setInitData();
        }
    },
    mounted() {
        this.setInitData();
    }
}
</script>
