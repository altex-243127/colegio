<template>
    <div class="modal fade" data-keyboard="false" data-backdrop="static">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Editar colegio</h5>
                    <button type="button" class="close" @click="close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row" v-if="message.value != ''">
                        <div class="col">
                            <p class="p-2" :class="'alert-' + message.type" v-html="message.value"></p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <label for="school">Nombre del colegio</label>
                            <CustomInput id="school"
                                         placeholder="Nombre del colegio"
                                         :required="true"
                                         v-model="name.value"
                                         :is-valid="name.isValid"
                                         :message="name.message"
                                         type="text"></CustomInput>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary w-25" @click="close">Cerrar</button>
                    <button type="button" class="btn btn-red w-25" @click="edit">Editar</button>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import jQuery from "jquery";
    import Axios from "axios";
    import CustomInput from "../custom-input";
    import School from "../../models/School";

    export default {
        data(){
            return {
                name: {
                    value: "",
                    isValid: null,
                    validate(){
                        return this.value != ""
                    },
                    message: "El nombre del colegio es obligatorio"
                },
                message: {
                    type: "success",
                    value: ""
                }
            }
        },
        props: {
            show: {
                type: Boolean,
                default: false
            },
            school: {
                type: School,
                default(){
                    return new School()
                }
            }
        },
        components: {
            CustomInput
        },
        methods: {
            reset(){
                this.name.value = "";
                this.message.value = "";
            },
            close(){
                this.$emit("close");
            },
            validate(){
                this.name.isValid = this.name.validate();
                return this.name.isValid;
            },
            edit(){
                this.$emit("awaiting");
                Axios.put("/api/CompetitivenessMatrix/school/" + this.school.id, {
                    name: this.name.value
                }, {
                    headers: {
                        Accept: 'application/json',
                        Authorization: 'Bearer ' + localStorage.autenticate_token
                    }
                }).then(response => {
                    this.$set(this.message, "type", "success");
                    this.$set(this.message, "value", response.data.message);
                    setTimeout(() => {
                        this.reset();
                        this.$emit("edit-school");
                        this.close();
                    }, 1000)
                    this.$emit("resume");
                }).catch(error => {
                    this.$set(this.message, "type", "danger");
                    if(error.response.status == 406){
                        this.$set(this.message, "value", error.response.data.message.join("<br>"));
                    }else{
                        this.$set(this.message, "value", "No fue posible");
                    }
                    this.$emit("resume");
                })
            }
        },
        watch: {
            show(value){
                if(value){
                    jQuery(this.$el).modal("show");
                }else{
                    jQuery(this.$el).modal("hide");
                }
            },
            school(value){
                this.name.value = value.name;
            }
        },
        mounted() {
            if(this.show)
                jQuery(this.$el).modal("show");
        }
    }
</script>
