<template>
    <div class="table-responsive">
        <table class="table table-hover table-bordered">
            <tr>
                <th>
                    <div class="title-table-dofa" style="width: 250px">
                        <span class="first">{{ title1 }}</span>
                        <hr>
                        <span class="last">{{ title2 }}</span>
                    </div>
                </th>
                <template v-for="data in data1">
                    <th class="align-middle">
                        <p>
                            {{ data.name }}
                        </p>
                    </th>
                </template>
            </tr>
            <template v-for="data in data2">
                <tr>
                    <th>{{ data.name }}</th>
                    <template v-for="item in data1">
                        <td class="text-center" :class="getColor(item.id, data.id)">
                            <span>{{ getScore(item.id, data.id) }}</span>
                        </td>
                    </template>
                </tr>
            </template>
        </table>
    </div>
</template>

<script>
export default {
    props: {
        title1: {
            type: String,
            default: ""
        },
        title2: {
            type: String,
            default: ""
        },
        data1: {
            type: Array,
            default(){
                return []
            }
        },
        data2: {
            type: Array,
            default(){
                return []
            }
        },
        key1: {
            type: String,
            default: ""
        },
        key2: {
            type: String,
            default: ""
        },
        dataScore: {
            type: Object,
            default(){
                return {}
            }
        }
    },
    methods: {
        getScore(id1, id2){
            const data = this.dataScore[id1 + "_" + id2];
            return data === undefined ? "" : new Intl.NumberFormat("es-CO", {maximumSignificantDigits: 3}).format(data.total);
        },
        getColor(id1, id2){
            const data = this.dataScore[id1 + "_" + id2];
            if(data === undefined){
                return "";
            }else{
                return data.total >= 2.5 ? "alert-success" : data.total > 2 ? "alert-warning" : "alert-danger";
            }
        }
    }
}
</script>
