<template>
    <div class="table-responsive">
        <div class="row" v-if="message.value != ''">
            <div class="col">
                <p class="p-3" :class="'alert-' + message.type">{{ message.value }}</p>
            </div>
        </div>
        <table class="table table-hover table-bordered">
            <tr>
                <th>
                    <div class="title-table-dofa" style="width: 250px">
                        <span class="first">{{ title1 }}</span>
                        <hr>
                        <span class="last">{{ title2 }}</span>
                    </div>
                </th>
                <template v-for="data in data1">
                    <th class="align-middle">
                        <p>
                            {{ data.name }}
                        </p>
                    </th>
                </template>
            </tr>
            <template v-for="data in data2">
                <tr>
                    <th>{{ data.name }}</th>
                    <template v-for="item in data1">
                        <td class="text-center">
                            <select v-if="!finished" class="form-control" @change="setScore($event, item, data)">
                                <option value=""></option>
                                <option v-for="(option, key) in options" :value="key+1">{{option}}</option>
                            </select>
                            <span v-else>
                                {{ options[getScore(item.id, data.id)-1] }}
                            </span>
                        </td>
                    </template>
                </tr>
            </template>
        </table>
        <div class="row my-3" v-if="!finished">
            <div class="col">
                <button class="btn btn-red" type="button" @click="sendScore">Enviar calificación</button>
                <button class="btn btn-red d-none" type="button" @click="scoreRand">Calificacion aleatoria</button>
            </div>
        </div>
    </div>
</template>

<script>
import Axios from 'axios';

import Button from '../Alert/Button';

export default {
    data(){
        return {
            scores: {},
            confirmSend: false,
            message: {
                value: "",
                type: "success"
            },
            options: [
                "No ralacionado",
                "Tiene algo de relación",
                "Fuertemente relacionado"
            ]
        }
    },
    props: {
        title1: {
            type: String,
            default: ""
        },
        title2: {
            type: String,
            default: ""
        },
        data1: {
            type: Array,
            default(){
                return []
            }
        },
        data2: {
            type: Array,
            default(){
                return []
            }
        },
        key1: {
            type: String,
            default: ""
        },
        key2: {
            type: String,
            default: ""
        },
        dataScore: {
            type: Array,
            default(){
                return []
            }
        },
        finished: {
            type: Boolean,
            default: false
        }
    },
    methods: {
        getScore(id1, id2){
            for(let index in this.dataScore){
                if(this.dataScore[index][this.key1 + "_id"] == id1 && this.dataScore[index][this.key2 + "_id"] == id2){
                    return this.dataScore[index].score;
                }
            }
        },
        getScoreId(id1, id2){
            for(let index in this.dataScore){
                if(this.dataScore[index][this.key1 + "_id"] == id1 && this.dataScore[index][this.key2 + "_id"] == id2){
                    return this.dataScore[index].id;
                }
            }
        },
        setScore(e, data1, data2){
            this.scores[data1.id][data2.id] = e.target.value;
        },
        scoreRand(){
            for(let index in this.scores){
                for(let i in this.scores[index]){
                    if(this.scores[index][i] == 0){
                        this.scores[index][i] = 3;
                    }
                }
            }
        },
        validate(){
            this.message.value = "";
            let errors = 0;
            for(let index in this.scores){
                for(let i in this.scores[index]){
                    if(this.scores[index][i] == 0){
                        errors += 1;
                    }
                }
            }
            return errors == 0;
        },
        sendScore(){
            if(this.validate()){
                if(this.confirmSend){
                    Axios.post("/api/DofaScoreUser", {
                        key1: this.key1,
                        key2: this.key2,
                        scores: this.scores
                    }, {
                        headers: {
                            Accept: 'application/json',
                            Authorization: 'Bearer ' + localStorage.autenticate_token
                        }
                    }).then(response => {
                        this.$emit("reload");
                        this.$emit("show-message", {
                            title: "Calificación enviada con éxito",
                            message: response.data.message,
                            type: "success"

                        });
                    }).catch(error => {
                        this.message.value = error.response.data.message;
                        this.message.type = "danger";
                    })
                }else{
                    let button = new Button();
                    button.setText("Confirmar");
                    button.setDisable(false);
                    button.setOnClick(() => {
                        this.confirmSend = true;
                        this.sendScore();
                    });
                    this.$emit("show-message", {
                        title: "Confirmación",
                        message: "¿Esta seguro de enviar esta calificación? Recuerde que no podra cambiarla",
                        type: "info",
                        button: button
                    });
                }
            }else{
                this.message.value = "Debe calificar todos los aspectos";
                this.message.type = "danger";
            }
        },
        capitalize(text){
            return text.charAt(0).toUpperCase() + text.slice(1)
        }
    },
    mounted() {
        for(let index in this.data1){
            for(let i in this.data2){
                if(this.scores[this.data1[index].id] === undefined){
                    this.scores[this.data1[index].id] = {};
                }
                this.scores[this.data1[index].id][this.data2[i].id] = 0;
            }
        }
    }
}
</script>
