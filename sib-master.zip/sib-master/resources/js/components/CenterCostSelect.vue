<template>
    <div class="select-user">
        <p class="form-control px-1 m-0" @click="show = !show">
            <span v-if="value != null">{{ value.name }}</span>
            <span class="float-right material-icons">
                keyboard_arrow_down
            </span>
        </p>
        <ul class="select-list" :class="{show: show}">
            <li>
                <input type="text" class="form-control" autocomplete="off" placeholder="Buscar..." v-model="find">
            </li>
            <template v-for="(centerCost, key) in centersCost">
                <li>
                    <button type="button" class="btn text-left w-100" @click="setValue(centerCost)">{{ centerCost.name }}</button>
                </li>
            </template>
            <li v-if="centersCost.length == 0">
                Sin resultados
            </li>
        </ul>
    </div>
</template>

<script>
import Axios from 'axios';

export default {
    name: "selectCenterCost",
    data(){
        return {
            centersCost: [],
            select: 0,
            find: "",
            show: false
        }
    },
    props: {
        value : {
            default(){
                name: ""
            }
        }
    },
    methods: {
        getCenterCost(){
            Axios.get("/api/centerCost?query=" + this.find, {
                headers: {
                    Accept: 'application/json',
                    Authorization: 'Bearer ' + localStorage.autenticate_token
                }
            }).then(response => {
                this.centersCost = response.data;
            }).catch(error => {
                console.log(error);
                this.$emit("error");
            })
        },
        setValue(area){
            this.$emit("input", area);
        }
    },
    watch: {
        find(value){
            if(value.length > 3){
                this.getCenterCost();
            }
        },
        value(value){
            this.$emit("input", value);
            this.show = false;
        }
    },
    mounted() {
        this.getCenterCost();
    }
}
</script>

<style scoped>
    .select-user{
        position: relative;
        cursor: pointer;
    }
    ul{
        list-style: none;
        padding: 0px;
        position: absolute;
        width: 100%;
        border: 1px solid #dee2e6;
        border-top: 0px;
        opacity: 0;
        transition: all 1s;
        pointer-events: none;
        background-color: #fff;
        z-index: 10;
    }
    ul.show{
        opacity: 1;
        pointer-events: all;
    }
</style>
