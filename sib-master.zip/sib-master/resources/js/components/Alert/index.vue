<template>
    <div class="modal fade" id="alert" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header alert" :class="modalType">
                    <h5 class="modal-title">{{ title }}</h5>
                    <button type="button" class="close" @click="close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body" v-html="message"></div>
                <div class="modal-footer">
                    <button type="button"
                            class="btn"
                            :class="button2.type"
                            @click="button2.onClick()"
                            v-show="button2.visible"
                            v-if="!button2.disable">{{ button2.text }}</button>
                    <button type="button"
                            class="btn"
                            :class="button1.type"
                            @click="button1.onClick()"
                            v-show="button1.visible"
                            v-if="!button1.disable">{{ button1.text }}</button>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
import jQuery from 'jquery'
import Button from './Button'

export default {
    name: "Alert",
    props: {
        title: {
            type: String,
            default: ""
        },
        message: {
            type: String,
            default: ""
        },
        type: {
            type: String,
            default: "success"
        },
        show: {
            type: Boolean,
            default: false
        },
        button1: {
            type: Object,
            default(){
                let button = new Button();
                button.setText("Aceptar");
                button.setOnClick(() => {
                    this.$emit('send');
                });
                return button;
            }
        },
        button2: {
            type: Object,
            default(){
                let button = new Button();
                button.setText("Cancelar");
                button.setOnClick(() => {
                    this.close();
                });
                return button;
            }
        }
    },
    watch: {
        show(value){
            jQuery(this.$el).modal(value ? "show" : "hide");
        }
    },
    methods: {
        close(){
            this.$emit('close');
        }
    },
    computed: {
        modalType(){
            return 'alert-' + this.type
        }
    }
}
</script>
