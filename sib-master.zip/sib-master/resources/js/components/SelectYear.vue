<template>
    <div class="modal fade" id="selectYear" tabindex="-1" role="dialog" data-backdrop="static" data-keyboard="false">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header alert">
                    <h5 class="modal-title">Seleccione el año en el que desea trabajar</h5>
                </div>
                <div class="modal-body">
                    <select name="year" id="year" class="form-control" v-model="year">
                        <option value=""></option>
                        <option v-for="year in years" :value="year.year">{{ year.year }}</option>
                    </select>
                </div>
                <div class="modal-footer">
                    <button type="button"
                            class="btn btn-success"
                            @click="setYear">Seleccionar</button>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import Axios from 'axios';
    import jQuery from "jquery";
    export default {
        data(){
            return {
                years: [],
                year: ""
            }
        },
        props: {
            open: {
                type: Boolean,
                default: false
            }
        },
        methods: {
            getYears(){
                Axios.get("/api/years")
                    .then(response => {
                        this.years = response.data;
                    })
                    .catch(error => {
                        console.log(error.response.message)
                    })
            },
            setYear(){
                console.log("set year")
                Axios.post("/api/setYear", {
                    year: this.year
                },{
                    headers: {
                        Accept: 'application/json',
                        Authorization: 'Bearer ' + localStorage.autenticate_token
                    }
                })
                .then(response => {
                    localStorage.setItem("year", this.year)
                    this.$emit("setYear")
                    jQuery(this.$el).modal("hide");
                })
                .catch(error => {
                    console.log(error.response.message)
                })
            }
        },
        watch: {
            year(value){
                console.log("wyear")
                this.$emit("input", value);
            },
            $route (to, from){
                console.log(localStorage.year, localStorage.user)
                if(localStorage.year == undefined && localStorage.user){
                    this.$emit("open")
                }
            },
            open(value){
                jQuery(this.$el).modal(value ? "show" : "hide")
            }
        },
        mounted() {
            this.getYears();
        }
    }
</script>
