import Vue from 'vue'
import jQuery from 'jquery'
import Index from './IndexPhp'

new Vue({
    el: '#app',
    components: { Index }
})
