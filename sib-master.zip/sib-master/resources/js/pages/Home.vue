<template>
    <div class="container" id="dashboard">
        <div class="row my-4">
            <div class="col-12">
                <h2>Dashboard Area {{ user == null ? "" : user.office.area.name }}</h2>
            </div>
        </div>
        <div class="row">
            <div class="col-12 col-md-6 col-lg-4 order-1 order-lg-0">
                <div class="card" style="height: 230px;">
                    <div class="card-body">
                        <i class="grafico material-icons">attach_money</i>
                        <span class="relative_value text-right" :data-value="presupuestoAprobado">0</span>
                        <h4 class="text-right">Presupuesto aprobado <br> &emsp;</h4>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-6 col-lg-4 mt-4 mt-lg-0 order-2 order-lg-1">
                <div class="card" style="height: 230px;">
                    <div class="card-body">
                        <i class="grafico material-icons">attach_money</i>
                        <span class="relative_value text-right" :data-value="presupuestoAprobadoMesActual">0</span>
                        <h4 class="text-right">Presupuesto aprobado para este mes</h4>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-6 col-lg-4 order-0 order-lg-2">
                <div class="card" style="height: 230px;">
                    <div class="card-body" v-if="this.user">
                        <i class="grafico material-icons">person</i>
                        <avatar class="w-50 m-auto" :src="'/avatar/' + this.user.id"></avatar>
                        <h4 class="text-right">{{ user.name }}</h4>
                    </div>
                </div>
            </div>
        </div>
        <div class="row py-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="text-right">Presupuesto aprobado por mes</h4>
                        <div class="chart-container" style="position: relative; height:200px; width:100%">
                            <canvas id="porMes" width="400" height="400"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
import axios from 'axios';
import jQuery from "jquery";
import avatar from "../components/Avatar"
import Chart from "chart.js/dist/chart";
    export default {
        data(){
            return {
                user: null,
                presupuestoAprobado: 0,
                presupuestoAprobadoMesActual: 0,
                presupuestoPorMes : []
            }
        },
        components: {
            avatar
        },
        methods: {
            graficaPorMes(){
                const ctx = document.getElementById('porMes').getContext('2d');
                const myChart = new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
                        datasets: [{
                            label: '$ por mes',
                            data: this.presupuestoPorMes,
                            borderWidth: 1,
                            backgroundColor: [
                                'rgba(255, 99, 132, 0.2)',
                                'rgba(54, 162, 235, 0.2)',
                                'rgba(255, 206, 86, 0.2)',
                                'rgba(75, 192, 192, 0.2)',
                                'rgba(153, 102, 255, 0.2)',
                                'rgba(255, 159, 64, 0.2)',
                                'rgba(255, 99, 132, 0.2)',
                                'rgba(54, 162, 235, 0.2)',
                                'rgba(255, 206, 86, 0.2)',
                                'rgba(75, 192, 192, 0.2)',
                                'rgba(153, 102, 255, 0.2)',
                                'rgba(255, 159, 64, 0.2)'
                            ],
                            borderColor: [
                                'rgba(255, 99, 132, 1)',
                                'rgba(54, 162, 235, 1)',
                                'rgba(255, 206, 86, 1)',
                                'rgba(75, 192, 192, 1)',
                                'rgba(153, 102, 255, 1)',
                                'rgba(255, 159, 64, 1)',
                                'rgba(255, 99, 132, 1)',
                                'rgba(54, 162, 235, 1)',
                                'rgba(255, 206, 86, 1)',
                                'rgba(75, 192, 192, 1)',
                                'rgba(153, 102, 255, 1)',
                                'rgba(255, 159, 64, 1)'
                            ]
                        }]
                    },
                    options: {
                        maintainAspectRatio: false,
                    }
                });

                ctx.height = 300;

            }
        },
        async mounted() {
            this.$emit("onData", {
                key: 'showMenu',
                value: true
            })
            this.user = JSON.parse(localStorage.user);
            await axios.post("/api/presupuestoAprobado", {})
            .then(response => {
                this.presupuestoAprobado = response.data.total;
            })

            await axios.post("/api/presupuestoAprobadoPorMes", {})
            .then(response => {
                this.presupuestoAprobadoMesActual = response.data.total;
            })

            await axios.post("/api/presupuestoAprobadoPorMes/all", {})
            .then(response => {
                this.presupuestoPorMes = response.data;
            })

            jQuery(".relative_value").each(function (){
                let value = jQuery(this).data("value");
                let last = value.toString().substr(value.toString().length - 2, 2);
                console.log(last)
                for(let i = parseInt(last); i <= value; i += 100){
                    let _this = jQuery(this)
                    setTimeout(() => {
                        _this.html(i)
                    }, 500)
                }
            })

            this.graficaPorMes();
        }
    }
</script>
