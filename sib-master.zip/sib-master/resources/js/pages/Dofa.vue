<template>
    <div>
        <Pages title="Dofa"
               :page="page"
               :get-page="getPage"
               :authorized="authorized">
            <template slot="body">
                <div class="row" v-if="!page.finalized">
                    <div class="col">
                        <router-link to="/dofaScore" class="btn btn-red" >
                            Calificar
                        </router-link>
                    </div>

                    <div class="col text-right" v-if="!onlyScore">
                        <button type="button" class="btn btn-red" @click="dofaRequestShow = true" >
                            Enviar solicitudes de revisión
                        </button>
                    </div>
                </div>
                <div class="row my-4">
                    <div class="col">
                        <DofaTable title1="Fortalezas"
                                   title2="Oportunidades"
                                   :data1="strengths"
                                   :data2="opportunities"
                                   key1="strength"
                                   key2="opportunity"
                                   :dataScore="strengthsOpportunities"></DofaTable>
                    </div>
                </div>
                <div class="row my-4">
                    <div class="col">
                        <DofaTable title1="Fortalezas"
                                   title2="Amenazas"
                                   :data1="strengths"
                                   :data2="threats"
                                   key1="strength"
                                   key2="threat"
                                   :dataScore="strengthsThreat"></DofaTable>
                    </div>
                </div>
                <div class="row my-4">
                    <div class="col">
                        <DofaTable title1="Debilidades"
                                   title2="Amenazas"
                                   :data1="weaknesses"
                                   :data2="threats"
                                   key1="weakness"
                                   key2="threat"
                                   :dataScore="weaknessesThreat"></DofaTable>
                    </div>
                </div>
                <div class="row my-4">
                    <div class="col">
                        <DofaTable title1="Debilidades"
                                   title2="Oportunidades"
                                   :data1="weaknesses"
                                   :data2="opportunities"
                                   key1="weakness"
                                   key2="opportunity"
                                   :dataScore="weaknessesOpportunities"></DofaTable>
                    </div>
                </div>
                <div class="row" v-if="!page.finalized && !onlyScore">
                    <div class="col">
                        <button class="btn btn-success w-100" @click="finishTask">
                            <i class="material-icons align-middle">check</i> Finalizar este proceso
                        </button>
                    </div>
                </div>
            </template>
        </Pages>
        <DofaRequest :show="dofaRequestShow"
                     :users="usersCanReview"
                     @showAlert="showAlert($event)"
                     @awaiting="awaiting"
                     @resume="resume"
                     @close="dofaRequestShow = false"></DofaRequest>

        <Alert :title="alert.title"
               :type="alert.type"
               :message="alert.message"
               :show="alert.show"
               :button1="alert.button1"
               @close="alert.show = false"></Alert>
    </div>
</template>
<script>
import Axios from 'axios';

// models
import PageModel from "./PageModel";

// components
import Pages from "../components/Pages";
import DofaRequest from "../components/DofaRequest";
import Button from "../components/Alert/Button";
import Alert from "../components/Alert";
import DofaTable from "../components/DofaTable"


let button1 = new Button();
button1.setDisable(true);

export default {
    name: "Dofa",
    mixins: [ PageModel ],
    data(){
        return {
            dofaRequestShow: false,
            usersCanReview: [],
            confirmFinish: false,
            //alert
            alert: {
                title: "",
                message: "",
                type: "success",
                show: false,
                button1: button1
            },
            //
            strengths: [],
            opportunities: [],
            threats: [],
            weaknesses: [],
            strengthsOpportunities: [],
            strengthsThreat: [],
            weaknessesOpportunities: [],
            weaknessesThreat: [],
            userQualify: [],
            onlyScore : false
        }
    },
    methods: {
        afterComplete(data){
            this.usersCanReview = data.usersCanReview;
            this.strengths = data.strengths;
            this.opportunities = data.opportunities;
            this.threats = data.threats;
            this.weaknesses = data.weaknesses;
            this.strengthsOpportunities = {};
            data.strengthsOpportunities.map(item => {
                this.strengthsOpportunities[item.strength_id + "_" + item.opportunity_id] = item;
            });
            this.strengthsThreat = {};
            data.strengthsThreat.map(item => {
                this.strengthsThreat[item.strength_id + "_" + item.threat_id] = item;
            });
            this.weaknessesOpportunities = {};
            data.weaknessesOpportunities.map(item => {
                this.weaknessesOpportunities[item.weakness_id + "_" + item.opportunity_id] = item;
            });
            this.weaknessesThreat = {};
            data.weaknessesThreat.map(item => {
                this.weaknessesThreat[item.weakness_id + "_" + item.threat_id] = item;
            });
            this.$set(this, "userQualify", data.userQualify);
            this.$set(this, "onlyScore", data.onlyScore);
        },
        showAlert(data){
            this.alert.title = data.title;
            this.alert.message = data.message;
            this.alert.type = data.type;
            if(data.button != undefined){
                this.alert.button1 = data.button;
            }else{
                this.alert.button1 = button1;
            }
            this.alert.show = true;
        },
        finishTask(){
            if(this.confirmFinish){
                Axios.post("/api/" + this.$options.name, {}, this.axiosConfig)
                    .then(response => {
                        this.alertAfterAction("Operación culminada con éxito", response.data.message, "success");
                        this.page.finalized = true;
                    }).catch(error => {
                        this.alertAfterAction("la operación no se pudo completar", error.response.data.message, "danger");
                    })
            }else{
                let btn = new Button();
                btn.setText("Finalizar");
                btn.setOnClick(() => {
                    this.confirmFinish = true;
                    this.finishTask();
                })

                this.showAlert({
                    title: "¿Esta seguro?",
                    message: "¿Desea terminar este proceso?",
                    type: "info",
                    button: btn
                })
            }
        },
        alertAfterAction(title, message, type){
            this.$set(this.alert, "title", title);
            this.$set(this.alert, "message", message);
            this.$set(this.alert, "type", type);
            this.$set(this.alert, "show", true);
            let button1 = new Button();
            button1.setDisable(true);
            button1.setText("Aceptar");
            this.$set(this.alert, "button1", button1);
        },
    },
    components: {
        Pages,
        DofaRequest,
        DofaTable,
        Alert
    }
}
</script>

<style>
    .title-table-dofa hr{
        transform: rotate(16deg);
    }
    .title-table-dofa span.first{
        display: block;
        text-align: right;
        padding-right: 15%;
    }
    .title-table-dofa span.last{
        display: block;
        text-align: left;
        padding-left: 15%;
    }
</style>
