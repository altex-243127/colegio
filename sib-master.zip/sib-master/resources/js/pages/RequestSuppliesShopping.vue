<template>
    <div>
        <Pages title="Solicitudes de insumos"
               :page="page"
               :get-page="getPage"
               :authorized="authorized">
            <template slot="body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Descripción</th>
                                <th>Unidad</th>
                                <th>Cantidad</th>
                                <th>Categoria</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <template v-for="requestSupply in requestSupplies">
                                <tr>
                                    <td>{{ requestSupply.resource.description }}</td>
                                    <td>{{ requestSupply.resource.unit }}</td>
                                    <td>{{ requestSupply.resource.quantity }}</td>
                                    <td>
                                        <select-find :selected="requestSupply.category == undefined ? {id: 0, text :'Sin categoria'} : {id: requestSupply.category.id, text : requestSupply.category.name}"
                                                     ajax="/api/categoriesShoppingJson"
                                                     ajax-create="/api/categoriesShopping/create"
                                                     :ajax-update="'/api/categoriesShopping/update/' + requestSupply.id"
                                                     @update="updateCategory(requestSupply, $event)"
                                        ></select-find>
                                    </td>
                                    <td>
                                        <template v-if="requestSupply.category_id != null">
                                            <button class="btn btn-primary" type="button" @click="createQuote(requestSupply)">Generar cotización</button>
                                        </template>
                                    </td>
                                </tr>
                            </template>
                        </tbody>
                    </table>
                </div>
            </template>
        </Pages>

        <Alert :title="alert.title"
               :type="alert.type"
               :message="alert.message"
               :show="alert.show"
               :button1="alert.button1"
               @close="alert.show = false"></Alert>

    </div>
</template>
<script>
    import Axios from "axios";

    // models
    import PageModel from "./PageModel";

    // components
    import Pages from "../components/Pages";
    import edit from "../components/area/edit";
    import newArea from "../components/area/new";
    import selectFind from "../components/select-find";

    export default {
        name: "requestSuppliesShopping",
        data(){
            return {
                requestSupplies : []
            }
        },
        mixins: [ PageModel ],
        components: {
            Pages,
            edit,
            newArea,
            selectFind
        },
        methods: {
            afterComplete(data){
                console.log(data)
                this.requestSupplies = data.requestSupplies;
            },
            updateCategory(supply, selected){
                console.log(supply, selected)
                this.requestSupplies.map((item, index) => {
                    if(item.id == supply.id){
                        this.$set(this.requestSupplies[index], "category_id", selected.id)
                        this.$set(this.requestSupplies[index], "category", selected)
                    }
                })
            },
            createQuote(supply){
                Axios.post("/api/quote/create/" + supply.id)
                .then(response => {
                    this.getPage()
                });
            }
        }
    }
</script>
