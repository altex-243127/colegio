<template>
    <div>
        <div class="full bg-red-special">
            <div class="d-none d-md-block bg-white bg-line"></div>
            <div class="container py-5">
                <div class="row justify-content-md-between">
                    <div class="col-12 col-md-4 text-center pt-md-5">
                        <img src="/logo.png" alt="" class="w-75 pt-md-5">
                        <h5 class="text-white text-center mt-3">Sistema de información Bartolina V1.0.0.0</h5>
                    </div>
                    <div class="col-12 col-md-4 pt-md-5">
                        <div class="row py-md-5">
                            <div class="col-12">
                                <h2 class="text-white mt-3 text-center text-md-dark">Inicio de sesión</h2>
                            </div>
                            <div class="col-12">
                                <custom-input type="email"
                                              :required="true"
                                              placeholder="Email"
                                              :isValid="email.isValid"
                                              :message="email.validate_message"
                                              v-model="email.value"/>
                            </div>
                            <div class="col-12 mt-3">
                                <custom-input type="password"
                                              :required="true"
                                              placeholder="Contraseña"
                                              :isValid="password.isValid"
                                              :message="password.validate_message"
                                              v-model="password.value"/>
                            </div>
                            <div class="col-12 mt-3">
                                <button class="btn btn-dark-blue w-100" type="button" @click="onLogin">
                                    Ingresar
                                </button>
                            </div>
                            <div class="col-12 mt-3">
                                <a href="/login/google" class="btn btn-primary w-100"><i class="fa fa-google"></i> Ingresar con google</a>
                            </div>
                            <div class="col-12 mt-3">
                                <hr class="border-light">
                            </div>
                            <div class="col-12 mt-1 text-center">
                                <a href="" class="text-white text-md-dark">¿Ha olvidado su contraseña?</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row justify-content-md-between">
                    <div class="col-12 col-md-4">
                        <p class="text-center text-white">
                            FUNDACIÓN COLEGIO MAYOR DE SAN BARTOLOMÉ <br>
                            Carrera 77a N° 9 - 96 <br>
                            Tel. 444 2530 <br>
                            Bogotá D.C. - Colombia
                        </p>
                    </div>
                </div>
            </div>
        </div>
        <Alert title="Inicio de sesión"
               :message="alert.message"
               :type="alert.type"
               :show="alert.show"
               :button1="alert.button1"
               :button2="alert.button2"
               @close="alert.show = false"></Alert>

        <PageLoad :state="page.state"></PageLoad>

    </div>
</template>
<script>
import Axios from 'axios'
import customInput from '../components/custom-input'
import Alert from '../components/Alert'
import AlertButton from '../components/Alert/Button'
import PageLoad from "../components/PageLoad"
import SelectYear from "../components/SelectYear";

export default {
    data(){
        return {
            email: {
                value: "",
                isValid: null,
                validate(){
                    return this.value != '';
                },
                validate_message: "El campo email es obligatorio",
            },
            password:  {
                value: "",
                isValid: null,
                validate(){
                    return this.value != '';
                },
                validate_message: "El campo contraseña es obligatorio"
            },
            year: "",
            yearMessage: "",
            remember: false,
            alert: {
                show: false,
                message: '',
                type: 'danger',
                button1: {},
                button2: {},
            },
            page: {
                state: 1
            },
        }
    },
    components: {
        customInput,
        Alert,
        PageLoad,
        SelectYear
    },
    methods: {
        validate(){
            this.email.isValid = this.email.validate();
            this.password.isValid = this.password.validate();
            return this.email.isValid && this.password.isValid;
        },
        onLogin(){
            if(this.validate()){
                this.page.state = 0;
                Axios.post('/api/login', {
                    email: this.email.value,
                    password: this.password.value,
                    remember: this.remember
                }).then(response => {
                    console.log(response)
                    if(response.data.token !== undefined){
                        this.login(response.data.token, JSON.stringify(response.data.user))
                    }else{
                        this.alert.message = "No fue posible iniciar sesión intentelo mas tarde"
                        this.alert.show = true;
                    }
                    this.page.state = 1;
                }).catch(error => {
                    let message = "";
                    if(error.response.status == 401){
                        message = error.response.data.message
                    }else{
                        message = "No fue posible iniciar sesión intentelo mas tarde"
                    }
                    this.page.state = 1;
                    this.showAlertError(message);
                })
            }

        },
        button1(){
            let button = new AlertButton();
            button.setText("Cerrar");
            button.setOnClick(() => {
                this.alert.show = false;
            });
            return button;
        },
        button2(){
            let button = new AlertButton();
            button.setVisible(false);
            return button;
        },
        responseGoogle(){
            if(localStorage.googleState == "success"){
                this.login(localStorage.googleToken, localStorage.googleUser);
            }else if(localStorage.googleState == "failed"){
                this.showAlertError(localStorage.googleMessage);
            }
            localStorage.removeItem("googleState");
            localStorage.removeItem("googleMessage");
            localStorage.removeItem("googleUser");
            localStorage.removeItem("googleToken");
        },
        showAlertError(message){
            this.alert.message = message;
            this.alert.show = true;
        },
        login(token, user){
            localStorage.autenticate_token = token;
            localStorage.user = user;
            this.$router.push("/home");
        }
    },
    mounted() {
        this.alert.button1 = this.button1();
        this.alert.button2 = this.button2();
        this.$emit("onData", {
            key: 'showMenu',
            value: false
        })
        if(localStorage.googleState !== undefined){
            this.responseGoogle();
        }
    }

}
</script>
