<template>
    <div>
        <Pages title="Resumen de estrategias"
               :page="page"
               :get-page="getPage"
               :authorized="authorized">
            <template slot="body">
                <div class="row">
                    <div class="col">
                        <h5 class="title">Fortalezas / Oportunidades</h5>
                        <StrategyTable label1="Fortaleza"
                                       label2="Oportunidad"
                                       key1="strength"
                                       key2="opportunity"
                                       :data="strengthsOpportunities"
                                       v-model="strengthsOpportunitiesState"
                                       :categories="categories"
                                       :strategies="strategies"
                                       :finalized="page.finalized"
                                       @showAlert="showAlert($event)"></StrategyTable>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <h5 class="title">Fortalezas / Amenazas</h5>
                        <StrategyTable label1="Fortaleza"
                                       label2="Amenaza"
                                       key1="strength"
                                       key2="threat"
                                       :data="strengthsThreat"
                                       v-model="strengthsThreatState"
                                       :categories="categories"
                                       :strategies="strategies"
                                       :finalized="page.finalized"
                                       @showAlert="showAlert($event)"></StrategyTable>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <h5 class="title">Debilidades / Oportunidades</h5>
                        <StrategyTable label1="Debilidad"
                                       label2="Oportunidad"
                                       key1="weakness"
                                       key2="opportunity"
                                       :data="weaknessesOpportunities"
                                       v-model="weaknessesOpportunitiesState"
                                       :categories="categories"
                                       :strategies="strategies"
                                       :finalized="page.finalized"
                                       @showAlert="showAlert($event)"></StrategyTable>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <h5 class="title">Debilidades / Amanezas</h5>
                        <StrategyTable label1="Debilidad"
                                       label2="Amenaza"
                                       key1="weakness"
                                       key2="threat"
                                       :data="weaknessesThreat"
                                       :categories="categories"
                                       :strategies="strategies"
                                       :finalized="page.finalized"
                                       v-model="weaknessesThreatState"
                                       @showAlert="showAlert($event)"></StrategyTable>
                    </div>
                </div>

                <div class="row my-4" v-if="!page.finalized">
                    <div class="col">
                        <button class="btn btn-success w-100" @click="finishTask" :disabled="!canFinalized">
                            <i class="material-icons align-middle">check</i> Finalizar este proceso
                        </button>
                    </div>
                </div>

            </template>

        </Pages>

        <Alert :title="alert.title"
               :type="alert.type"
               :message="alert.message"
               :show="alert.show"
               :button1="alert.button1"
               @close="alert.show = false"></Alert>

    </div>
</template>
<script>
import Axios from "axios";

// models
import PageModel from "./PageModel";

// components
import Pages from "../components/Pages";
import StrategyTable from "../components/StrategicIssues/table"
import Alert from "../components/Alert"
import Button from "../components/Alert/Button"

let button1 = new Button();
button1.setDisable(true);

export default {
    name: "StrategySummary",
    mixins: [ PageModel ],
    components: {
        Pages,
        Alert,
        StrategyTable
    },
    data(){
        return {
            categories: [],
            strategies: [],
            strengthsOpportunities: [],
            strengthsOpportunitiesState: false,
            strengthsThreat: [],
            strengthsThreatState: false,
            weaknessesThreat: [],
            weaknessesThreatState: false,
            weaknessesOpportunities: [],
            weaknessesOpportunitiesState: false,
            //alert
            alert: {
                title: "",
                message: "",
                type: "success",
                show: false,
                button1: button1
            },
            confirmFinish: false
        }
    },
    methods: {
        afterComplete(data){
            this.categories = data.categories;
            this.strategies = data.strategies;
            this.strengthsOpportunities = data.strengthsOpportunities;
            this.strengthsThreat = data.strengthsThreat;
            this.weaknessesThreat = data.weaknessesThreat;
            this.weaknessesOpportunities = data.weaknessesOpportunities;
        },
        showAlert(data){
            this.alert.title = data.title;
            this.alert.message = data.message;
            this.alert.type = data.type;
            if(data.button != undefined){
                this.alert.button1 = data.button;
            }else{
                this.alert.button1 = button1;
            }
            this.alert.show = true;

            if(data.type == "success"){
                this.getPage();
                console.log("reload");
            }
        },
        finishTask(){
            if(this.confirmFinish){
                Axios.post("/api/" + this.$options.name + '/finish', {}, this.axiosConfig)
                    .then(response => {
                        this.alertAfterAction("Operación culminada con éxito", response.data.message, "success");
                        this.page.finalized = true;
                    }).catch(error => {
                    this.alertAfterAction("la operación no se pudo completar", error.response.data.message, "danger");
                })
            }else{
                let btn = new Button();
                btn.setText("Finalizar");
                btn.setOnClick(() => {
                    this.confirmFinish = true;
                    this.finishTask();
                })

                this.showAlert({
                    title: "¿Esta seguro?",
                    message: "¿Desea terminar este proceso?",
                    type: "info",
                    button: btn
                })
            }
        },
        alertAfterAction(title, message, type){
            this.$set(this.alert, "title", title);
            this.$set(this.alert, "message", message);
            this.$set(this.alert, "type", type);
            this.$set(this.alert, "show", true);
            let button1 = new Button();
            button1.setDisable(true);
            button1.setText("Aceptar");
            this.$set(this.alert, "button1", button1);
        }
    },
    computed: {
        canFinalized(){

            return this.strengthsOpportunities.filter(item => {
                return item.strategy_summary === null;
            }).length == 0 && this.strengthsThreat.filter(item => {
                return item.strategy_summary === null;
            }).length == 0 && this.weaknessesOpportunities.filter(item => {
                return item.strategy_summary === null;
            }).length == 0 && this.weaknessesThreat.filter(item => {
                return item.strategy_summary === null;
            }).length == 0;
        }
    }
}
</script>
