<template>
    <div>
        <Pages title="Solicitud Presupuesto"
               :page="page"
               :get-page="getPage"
               :authorized="authorized">
            <template slot="body">
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                        <tr>
                            <th>Objetivo</th>
                            <th>Estrategia</th>
                            <th></th>
                        </tr>
                        </thead>
                        <tbody>
                        <template v-for="budget in budgets">
                            <tr>
                                <td>{{ budget.objective.objective }}</td>
                                <td>{{ budget.strategy.name }}</td>
                                <td class="text-center">
                                    <button class="btn btn-red" type="button" @click="showAddResources(budget)">
                                        Actividades
                                    </button>
                                </td>
                            </tr>
                        </template>
                        </tbody>
                    </table>
                </div>

                <div class="row my-3" v-if="!page.finalized && canFinish">
                    <div class="col-12">
                        <button class="btn btn-success w-100" @click="finishTask">
                            <i class="material-icons align-middle">check</i> Finalizar este proceso
                        </button>
                    </div>
                </div>

            </template>
        </Pages>

        <Alert :title="alert.title"
               :type="alert.type"
               :message="alert.message"
               :show="alert.show"
               :button1="alert.button1"
               @close="alert.show = false"></Alert>

        <Add :show="showAdd"
             :budget="budgetToAdd"
             @close="showAdd = false"
             :finalized="page.finalized"
             @success="showSuccess($event)"
             @error="showError($event)"></Add>

    </div>
</template>
<script>
    import Axios from "axios";

    // models
    import PageModel from "./PageModel";

    // components
    import Pages from "../components/Pages";
    import Add from "../components/Budget/AddResources";

    export default {
        name: "Budget",
        mixins: [ PageModel ],
        data(){
            return {
                budgets: [],
                showAdd: false,
                canFinish: false,
                budgetToAdd: {}
            }
        },
        components: {
            Pages,
            Add
        },
        methods: {
            afterComplete(data){
                this.budgets = data.budget;
                this.canFinish = data.canFinish;
            },
            showAddResources(budget){
                this.showAdd = true;
                this.budgetToAdd = budget;
            },
            showError(message){
                this.showAlert({
                    title: "La operación no se pudo completar",
                    message: message,
                    type: "danger"
                })
            },
            showSuccess(message){
                this.showAlert({
                    title: "Operacion completada con exito",
                    message: message,
                    type: "success"
                });
                this.getPage();
            }
        }
    }
</script>
