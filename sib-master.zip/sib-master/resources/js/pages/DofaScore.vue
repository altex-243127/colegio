<template>
    <div>
        <Pages title="Dofa (Calificar)"
               :page="page"
               :get-page="getPage"
               :authorized="authorized">
            <template slot="body">
                <div class="row my-4">
                    <div class="col">
                        <DofaTable title1="Fortalezas"
                                   title2="Oportunidades"
                                   :data1="strengths"
                                   :data2="opportunities"
                                   @show-message="showAlert($event)"
                                   @reload="reload"
                                   :data-score="strengthsOpportunities"
                                   :finished="userQualify.StrengthOpportunity == 1"
                                   key1="strength"
                                   key2="opportunity"></DofaTable>
                    </div>
                </div>
                <div class="row my-4">
                    <div class="col">
                        <DofaTable title1="Fortalezas"
                                   title2="Amenazas"
                                   :data1="strengths"
                                   :data2="threats"
                                   @show-message="showAlert($event)"
                                   @reload="reload"
                                   :data-score="strengthsThreats"
                                   :finished="userQualify.StrengthThreat == 1"
                                   key1="strength"
                                   key2="threat"></DofaTable>
                    </div>
                </div>
                <div class="row my-4">
                    <div class="col">
                        <DofaTable title1="Debilidades"
                                   title2="Amenazas"
                                   :data1="weaknesses"
                                   :data2="threats"
                                   @show-message="showAlert($event)"
                                   @reload="reload"
                                   :data-score="weaknessesThreats"
                                   :finished="userQualify.WeaknessThreat == 1"
                                   key1="weakness"
                                   key2="threat"></DofaTable>
                    </div>
                </div>
                <div class="row my-4">
                    <div class="col">
                        <DofaTable title1="Debilidades"
                                   title2="Oportunidades"
                                   :data1="weaknesses"
                                   :data2="opportunities"
                                   @show-message="showAlert($event)"
                                   @reload="reload"
                                   :data-score="weaknessesOpportunities"
                                   :finished="userQualify.WeaknessOpportunity == 1"
                                   key1="weakness"
                                   key2="opportunity"></DofaTable>
                    </div>
                </div>
            </template>
        </Pages>

        <Alert :title="alert.title"
               :type="alert.type"
               :message="alert.message"
               :show="alert.show"
               :button1="alert.button1"
               @close="alert.show = false"></Alert>
    </div>
</template>
<script>
import Axios from "axios";

// models
import PageModel from "./PageModel";

// components
import Pages from "../components/Pages";
import Button from "../components/Alert/Button";
import Alert from "../components/Alert";
import DofaTable from "../components/DofaTable/edit"

let button1 = new Button();
button1.setDisable(true);

export default {
    name: "DofaScore",
    mixins: [ PageModel ],
    data(){
        return {
            //alert
            alert: {
                title: "",
                message: "",
                type: "success",
                show: false,
                button1: button1
            },
            //
            strengths: [],
            opportunities: [],
            threats: [],
            weaknesses: [],
            strengthsOpportunities: [],
            strengthsThreats: [],
            weaknessesOpportunities: [],
            weaknessesThreats: [],
            userQualify: {}
        }
    },
    methods: {
        afterComplete(data){
            this.$set(this, "strengths", data.strengths);
            this.opportunities = data.opportunities;
            this.threats = data.threats;
            this.weaknesses = data.weaknesses;
            this.strengthsOpportunities = data.strengthsOpportunities;
            this.strengthsThreats = data.strengthsThreats;
            this.weaknessesOpportunities = data.weaknessesOpportunities;
            this.weaknessesThreats = data.weaknessesThreats;
            this.$set(this, "userQualify", data.userQualify);
        },
        showAlert(data){
            this.alert.title = data.title;
            this.alert.message = data.message;
            this.alert.type = data.type;
            if(data.button != undefined){
                this.alert.button1 = data.button;
            }else{
                this.alert.button1 = button1;
            }
            this.alert.show = true;
        },
        capitalize(text){
            return text.charAt(0).toUpperCase() + text.slice(1)
        },
        reload(){
            this.getPage();
        }
    },
    components: {
        Pages,
        DofaTable,
        Alert
    }
}
</script>

<style>
    .title-table-dofa hr{
        transform: rotate(16deg);
    }
    .title-table-dofa span.first{
        display: block;
        text-align: right;
        padding-right: 15%;
    }
    .title-table-dofa span.last{
        display: block;
        text-align: left;
        padding-left: 15%;
    }
</style>
