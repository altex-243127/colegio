<template>
    <div>
        <Pages title="Matriz"
               :page="page"
               :get-page="getPage"
               :authorized="authorized">
            <template slot="head">
                <div class="row justify-content-end px-3">
                    <div class="col-4">
                        <div class="card">
                            <div class="card-body py-0">
                                <table class="table m-0">
                                    <tbody>
                                    <tr>
                                        <th class="border-0">Muy fuerte</th>
                                        <td class="border-0">4</td>
                                    </tr>
                                    <tr>
                                        <th>Fuerte</th>
                                        <td>3</td>
                                    </tr>
                                    <tr>
                                        <th>Aceptable</th>
                                        <td>2</td>
                                    </tr>
                                    <tr>
                                        <th>Débil</th>
                                        <td>1</td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </template>
            <template slot="body">

                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                        <tr>
                            <th rowspan="2">
                                <p style="width: 250px">Factores calve de éxito</p>
                            </th>
                            <th rowspan="2">Ponderación</th>
                            <template v-for="school in schools">
                                <th colspan="2" class="text-center position-relative py-1" :class="{ 'alert-success' : schoolBest.id == school.id}">
                                    <span class="w-100 d-block">{{ school.name }}</span>
                                    <span v-if="!page.finalized">
                                        <button type="button" class="btn btn-primary btn-icon-sm p-1" title="Editar" @click="editSchool(school)">
                                            <i class="material-icons font-size-16 align-middle">
                                                create
                                            </i>
                                        </button>
                                        <button type="button" class="btn btn-red btn-icon-sm p-1" title="Eliminar" @click="deleteSchool(school)">
                                            <i class="material-icons font-size-16 align-middle">
                                                delete
                                            </i>
                                        </button>
                                    </span>
                                </th>
                            </template>
                            <th rowspan="2" v-if="!page.finalized">
                                <p style="width: 200px">
                                    <button class="btn btn-red w-100" @click="showNewSchool = true">
                                        <i class="material-icons align-middle">add</i> Añadir Colegio
                                    </button>
                                </p>
                            </th>
                        </tr>
                        <tr>
                            <template v-for="school in schools">
                                <th :class="{ 'alert-success' : schoolBest.id == school.id}">Clasif</th>
                                <th :class="{ 'alert-success' : schoolBest.id == school.id}">Result</th>
                            </template>
                        </tr>
                        </thead>
                        <tbody>
                        <tr v-for="factor in factors">
                            <td>
                                <span>
                                    {{ factor.name }}
                                </span>
                                <span class="float-right" v-if="!page.finalized">
                                    <button type="button" class="btn btn-success btn-icon-sm p-1 text-white" title="Listado de subfactores" @click="detailFactor(factor)">
                                        <i class="material-icons font-size-16 align-middle">
                                            reorder
                                        </i>
                                    </button>
                                    <button type="button" class="btn btn-primary btn-icon-sm p-1" title="Editar" @click="editFactor(factor)">
                                        <i class="material-icons font-size-16 align-middle">
                                            create
                                        </i>
                                    </button>
                                    <button type="button" class="btn btn-red btn-icon-sm p-1" title="Eliminar" @click="deleteFactor(factor)">
                                        <i class="material-icons font-size-16 align-middle">
                                            delete
                                        </i>
                                    </button>
                                </span>
                            </td>
                            <td class="text-center">
                                {{ factor.weighing }}%
                            </td>
                            <template v-for="school in schools">
                                <td :class="{ 'alert-success' : schoolBest.id == school.id}">
                                    <input v-if="!page.finalized" type="text"
                                           :value="getScoreByFactor(school, factor)"
                                           class="form-control font-size-11 p-1 text-center"
                                           @change="saveScore($event, school, factor)">
                                    <p class="text-center" v-else>{{ getScoreByFactor(school, factor) }}</p>
                                </td>
                                <td class="text-center" :class="{ 'alert-success' : schoolBest.id == school.id}">
                                    {{ printResult(school, factor) }}
                                </td>
                            </template>
                            <td v-if="!page.finalized"></td>
                        </tr>
                        <tr>
                            <th class="text-right">
                                Total:
                            </th>
                            <td class="text-center">
                                {{ totalWeighing }}%
                            </td>
                            <template v-for="school in schools">
                                <td :class="{ 'alert-success' : schoolBest.id == school.id}"></td>
                                <td class="text-center" :class="{ 'alert-success' : schoolBest.id == school.id}">
                                    {{ getResultBySchool(school) }}
                                </td>
                            </template>
                            <td></td>
                        </tr>
                        <tr v-if="!page.finalized">
                            <td>
                                <button class="btn btn-red w-100 mb-2" @click="showNewFactor = true"  v-if="totalWeighing < 100">
                                    <i class="material-icons align-middle">add</i> Añadir factor
                                </button>
                                <button class="btn btn-success w-100" :disabled="totalWeighing < 100 || !allAssignedRatings" @click="finishTask">
                                    <i class="material-icons align-middle">check</i> Finalizar este proceso
                                </button>
                            </td>
                            <td :colspan="(schools.length*2) + 2"></td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </template>
        </Pages>
        <NewFactor :show="showNewFactor"
                   @close="showNewFactor = false"
                   @new-factor="getFactors"
                   @awaiting="awaiting"
                   @resume="resume"
                   :max-weighing="100 - totalWeighing"></NewFactor>
        <EditFactor :show="showEditFactor"
                    :factor="factorToEdit"
                    @awaiting="awaiting"
                    @resume="resume"
                    @close="showEditFactor = false"
                    @edit-factor="getFactors"
                    :max-weighing="100 - totalWeighing"></EditFactor>
        <DetailFactor :show="showDetailFactor"
                      :factor="factorToDetail"
                      @close="showDetailFactor = false"></DetailFactor>
        <NewSchool :show="showNewSchool"
                   @close="showNewSchool = false"
                   @awaiting="awaiting"
                   @resume="resume"
                   @new-school="getSchools"></NewSchool>
        <EditSchool :show="showEditSchool"
                    :school="schoolToEdit"
                    @close="showEditSchool = false"
                    @awaiting="awaiting"
                    @resume="resume"
                    @edit-school="getSchools"></EditSchool>
        <Alert :title="alert.title"
               :type="alert.type"
               :message="alert.message"
               :show="alert.show"
               :button1="alert.button1"
               @close="alert.show = false"></Alert>
    </div>
</template>

<script>
import Axios from "axios";

// models
import PageModel from "./PageModel";
import Factor from "../models/Factor";
import School from "../models/School";
import Button from "../components/Alert/Button"

// components
import NewFactor from "../components/Factor/new";
import EditFactor from "../components/Factor/edit";
import DetailFactor from "../components/Factor/detail";
import NewSchool from "../components/School/new";
import EditSchool from "../components/School/edit";
import Alert from "../components/Alert";

export default {
    name: "CompetitivenessMatrix",
    mixins: [ PageModel ],
    data(){
        return {
            // factors
            factors: [],
            showNewFactor: false,
            showEditFactor: false,
            factorToEdit: null,
            confirmDeleteFactor: false,
            factorToDetail: {},
            showDetailFactor: false,
            // schools
            schools: [],
            showNewSchool: false,
            showEditSchool: false,
            schoolToEdit: null,
            schoolBest: {
                id: null,
                result: 0
            },
            confirmDeleteSchool: false,
            //finish task
            confirmFinishTask: false,
            //alert
            alert: {
                title: "",
                message: "",
                type: "success",
                show: false,
                button1: undefined
            }
        }
    },
    components: {
        NewFactor,
        EditFactor,
        DetailFactor,
        NewSchool,
        EditSchool,
        Alert
    },
    computed: {
        totalWeighing(){
            let total = 0;
            this.factors.map(factor => {
                total += factor.weighing;
            })
            return total;
        },
        allAssignedRatings(){
            let missing = this.schools.filter(item => {
                return item.factors_score.length != this.factors.length;
            });
            return missing.length == 0;
        }
    },
    methods: {
        afterComplete(){
            this.getDataPage();
        },
        async getDataPage(){
            await this.getFactors();
            await this.getSchools();
        },
        async getFactors(){
            this.awaiting();
            this.factors = [];
            await Axios.get("/api/" + this.$options.name + "/factors", this.axiosConfig)
                .then(response => {
                    console.log(response.data)
                    for(let index in response.data){
                        let subFactors = [];
                        for(let i in response.data[index].strengths){
                            subFactors.push({
                                name: response.data[index].strengths[i].name,
                                dofa: "Fortaleza"
                            })
                        }
                        for(let i in response.data[index].weaknesses){
                            subFactors.push({
                                name: response.data[index].weaknesses[i].name,
                                dofa: "Debilidad"
                            })
                        }
                        let factor = new Factor(response.data[index].id, response.data[index].name, response.data[index].weighing, subFactors);
                        this.factors.push(factor);
                        this.resume();
                    }
                }).catch(error => {
                    this.errorGetPage(error);
                })
        },
        async getSchools(){
            this.awaiting();
            this.schools = [];
            await Axios.get("/api/" + this.$options.name + "/school", this.axiosConfig)
                    .then(response => {
                        for(let index in response.data){
                            let school = new School(response.data[index].id, response.data[index].name, response.data[index].factors_score);
                            this.schools.push(school);
                        }
                        this.resume();
                    }).catch(error => {
                        this.errorGetPage(error);
                    })
        },
        async deleteFactor(factor){
            if(this.confirmDeleteFactor){
                this.awaiting();
                await Axios.delete("/api/" + this.$options.name + "/factors/" + factor.id, this.axiosConfig)
                    .then(response => {
                        this.alertAfterAction("Operación culminada con éxito", response.data.message, "success");
                        this.getFactors();
                        this.getSchools();
                        this.resume();
                    }).catch(error => {
                        this.alertAfterAction("la operación no se pudo completar", error.response.data.message, "danger");
                        this.resume();
                    })
                this.confirmDeleteFactor = false;
            }else{
                this.confirmAction("¿Esta seguro?", "¿Esta seguro de eliminar este factor?", () => {
                    this.confirmDeleteFactor = true;
                    this.deleteFactor(factor);
                });
            }
        },
        async deleteSchool(school){
            if(this.confirmDeleteSchool){
                this.awaiting();
                await Axios.delete("/api/" + this.$options.name + "/school/" + school.id, this.axiosConfig)
                    .then(response => {
                        this.alertAfterAction("Operación culminada con éxito", response.data.message, "success");
                        this.getSchools();
                        this.resume();
                    }).catch(error => {
                        this.alertAfterAction("la operación no se pudo completar", error.response.data.message, "danger");
                        this.resume();
                    })
                this.confirmDeleteSchool = false;
            }else{
                this.confirmAction("¿Esta seguro?", "¿Esta seguro de eliminar este colegio?", () => {
                    this.confirmDeleteSchool = true;
                    this.deleteSchool(school);
                });
            }
        },
        async finishTask(){
            if(this.confirmFinishTask){
                await Axios.post("/api/" + this.$options.name , {}, this.axiosConfig)
                    .then(response => {
                        this.alertAfterAction("Operación culminada con éxito", response.data.message, "success");
                        this.page.finalized = true;
                    }).catch(error => {
                        this.alertAfterAction("la operación no se pudo completar", error.response.data.message, "danger");
                    })
                this.confirmFinishTask = false;
            }else{
                this.confirmAction("¿Esta seguro?", "¿Esta seguro de finalizar el proceso?", () => {
                    this.confirmFinishTask = true;
                    this.finishTask();
                });
            }
        },
        alertAfterAction(title, message, type){
            this.$set(this.alert, "title", title);
            this.$set(this.alert, "message", message);
            this.$set(this.alert, "type", type);
            this.$set(this.alert, "show", true);
            let button1 = new Button();
            button1.setDisable(true);
            button1.setText("Aceptar");
            this.$set(this.alert, "button1", button1);
        },
        confirmAction(title, message, actionConfirm){
            this.$set(this.alert, "title", title);
            this.$set(this.alert, "message", message);
            this.$set(this.alert, "type", "success");
            this.$set(this.alert, "show", true);
            let button1 = new Button();
            button1.setText("Aceptar");
            button1.setOnClick(actionConfirm);
            this.$set(this.alert, "button1", button1);
        },
        editFactor(factor){
            this.factorToEdit = factor;
            this.showEditFactor = true;
        },
        detailFactor(factor){
            this.factorToDetail = factor;
            this.showDetailFactor = true;
        },
        editSchool(school){
            this.schoolToEdit = school;
            this.showEditSchool = true;
        },
        saveScore(e, school, factor){
            let method = "post";
            let url = "/api/" + this.$options.name + "/factorSchoolScore";
            const factorSchoolScore = this.getIdScoreByFactor(school, factor);
            if(factorSchoolScore != ""){
                method = "put";
                url += "/" + factorSchoolScore;
            }
            let score = e.target.value;
            let config = this.axiosConfig;
            config["url"] = url;
            config["method"] = method;
            config["data"] = {
                school_id: school.id,
                factor_id: factor.id,
                score: score
            };
            this.awaiting();
            Axios(config)
                .then(response => {
                    this.alertAfterAction("Operación culminada con éxito", response.data.message, "success");
                    this.getSchools();
                    this.resume()
                })
                .catch(error =>  {
                    this.alertAfterAction("la operación no se pudo completar", error.response.data.message, "danger");
                    this.resume();
                });
        },
        getScoreByFactor(school, factor){
            for(let index in school.factors_score){
                if(school.factors_score[index].factor_id == factor.id){
                    return school.factors_score[index].score;
                }
            }
            return "";
        },
        getIdScoreByFactor(school, factor){
            for(let index in school.factors_score){
                if(school.factors_score[index].factor_id == factor.id){
                    return school.factors_score[index].id;
                }
            }
            return "";
        },
        getResultBySchool(school){
            let result = 0;
            for(let index in school.factors_score){
                let factor = this.getFactorById(school.factors_score[index].factor_id);
                if(factor == undefined){
                    return;
                }
                result += school.factors_score[index].score * (factor.weighing / 100);
            }
            if(this.schoolBest.result < result){
                this.$set(this.schoolBest, "result", result);
                this.$set(this.schoolBest, "id", school.id);
            }
            return new Intl.NumberFormat().format(result);
        },
        getFactorById(id){
            for(let index in this.factors){
                if(this.factors[index].id == id){
                    return this.factors[index];
                }
            }
        },
        printResult(school, factor){
            let score = this.getScoreByFactor(school, factor);
            score = score == '' ? 0 : score;
            return new Intl.NumberFormat().format(score * (factor.weighing/100));
        }
    }
}
</script>
