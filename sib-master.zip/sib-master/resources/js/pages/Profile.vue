<template>
    <div class="container py-4">
        <div class="row">
            <div class="col-12">
                <h3 class="title">Perfil</h3>
            </div>
        </div>
        <div class="card">
            <div class="card-head pt-4">
                <div class="row justify-content-end">
                    <div class="col text-right pr-4">
                        <button type="button" class="btn btn-outline-danger" @click="edit = !edit">
                            <span v-if="!edit">
                                <i class="material-icons align-middle">create</i> <span class="align-middle">Editar perfil</span>
                            </span>
                            <span v-else>
                                <i class="material-icons align-middle">clear</i> <span class="align-middle">Cancelar edición</span>
                            </span>
                        </button>
                    </div>
                </div>
                <div class="row justify-content-center">
                    <div class="col-8 col-md-6 col-lg-4 text-center">
                        <Avatar
                            class="position-relative d-inline-block w-50"
                            :src="'/avatar/' + this.user.id"
                            alt="" >
                            <template slot="otherContent">
                                <label class="btn btn-primary rounded-circle m-0" id="editAvatar" for="newAvatar">
                                    <input type="file" id="newAvatar" class="d-none" @change="onChangeAvatar">
                                    <i class="material-icons align-middle">create</i>
                                </label>
                            </template>
                        </Avatar>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="row justify-content-center">
                    <div class="col-8 col-md-6 col-lg-4 text-center">
                        <div class="row">
                            <div class="col">
                                <h4 v-if="!edit">{{ name.value }}</h4>
                                <Custom-input v-else
                                              type="text"
                                              :required="true"
                                              placeholder="Nombre"
                                              :is-valid="name.isValid"
                                              :message="name.validate_message"
                                              v-model="name.value"></Custom-input>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col">
                                <h5 v-if="!edit">{{ email.value }}</h5>
                                <Custom-input v-else
                                              type="email"
                                              :required="true"
                                              placeholder="Email"
                                              :is-valid="email.isValid"
                                              :message="email.validate_message"
                                              v-model="email.value"></Custom-input>
                            </div>
                        </div>
                        <div class="row" v-if="edit">
                            <div class="col">
                                <button class="btn btn-outline-danger w-100" type="button" @click="onEdit">
                                    <i class="material-icons align-middle">save</i> <span class="align-middle">Editar</span>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <Alert title="Inicio de sesión"
               :message="alert.message"
               :type="alert.type"
               :show="alert.show"
               :button1="alert.button1"
               :button2="alert.button2"
               @close="alert.show = false"></Alert>

    </div>
</template>

<script>
import Axios from 'axios'
import Avatar from '../components/Avatar'
import Alert from '../components/Alert/index'
import CustomInput from '../components/custom-input'
import AlertButton from '../components/Alert/Button'
import middleware from "../middleware";

export default {
    name: "Profile",
    data(){
        return {
            user: "",
            name: {
                value: "",
                isValid: null,
                validate(){
                    return this.value != '';
                },
                validate_message: "El campo nombre es obligatorio",
            },
            email: {
                value: "",
                isValid: null,
                validate(){
                    return this.value != '';
                },
                validate_message: "El campo email es obligatorio",
            },
            edit: false,
            alert: {
                show: false,
                message: '',
                type: 'danger',
                button1: {},
                button2: {},
            }
        }
    },
    components: {
        Avatar,
        CustomInput,
        Alert
    },
    methods: {
        validate(){
            this.name.isValid = this.name.validate();
            this.email.isValid = this.email.validate();
            return this.email.isValid && this.name.isValid;
        },
        onEdit(){
            if(this.validate()){
                Axios.put("/api/user/update", {
                    name: this.name.value,
                    email: this.email.value
                },{
                    headers: {
                        Accept: 'application/json',
                        Authorization: 'Bearer ' + localStorage.autenticate_token
                    },
                }
                ).then(response => {
                    this.showMessageSuccess(response.data)
                    this.edit = false;
                }).catch(error => {
                    this.showMessageError(error.response);
                })
            }
        },
        onChangeAvatar(e){
            if (e.target.files && e.target.files[0]) {
                var reader = new FileReader();

                reader.onload = (e) => {
                    this.user.avatar = e.target.result;
                }

                reader.readAsDataURL(e.target.files[0]);

                this.updateAvatar(e.target.files[0]);
            }
        },
        showMessageSuccess(data){
            this.alert.type = "success";
            this.alert.show = true;
            this.alert.message = data.message;
            localStorage.user = JSON.stringify(data.user);
        },
        showMessageError(response){
            if(response.status == 401){
                middleware.http401(this.$router);
            }
            this.alert.type = "danger";
            this.alert.show = true;
            this.alert.message = response.data.message;
        },
        updateAvatar(avatar){
            let data = new FormData();
            data.append("avatar", avatar);
            Axios.post("/api/avatar", data, {
                headers: {
                    'Accept': 'application/json',
                    Authorization: 'Bearer ' + localStorage.autenticate_token
                }
            }).then(response => {
                this.showMessageSuccess(response.data)
            }).catch(error => {

            });
        },
        button1(){
            let button = new AlertButton();
            button.setText("Cerrar");
            button.setOnClick(() => {
                this.alert.show = false;
            });
            return button;
        },
        button2(){
            let button = new AlertButton();
            button.setVisible(false);
            return button;
        },
    },
    mounted() {
        this.user = JSON.parse(localStorage.user);
        this.name.value = this.user.name;
        this.email.value = this.user.email;
        this.alert.button1 = this.button1();
        this.alert.button2 = this.button2();
    }
}
</script>

<style scoped>
    .material-icons{
        font-size: 17px;
    }
    #editAvatar{
        position: absolute;
        bottom: 0%;
        right: 0%;
        width: 40px;
        height: 40px;
    }
</style>
