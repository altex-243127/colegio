<template>
    <div>
        <Pages title="Pestel"
               :page="page"
               :get-page="getPage"
               :authorized="authorized">
            <template slot="body">
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                        <tr>
                            <th>
                                <p>Factor</p>
                            </th>
                            <th>
                                <p style="width: 250px">
                                    Aspecto a evaluar
                                </p>
                            </th>
                            <th>
                                <p>Impacto</p>
                            </th>
                            <th>
                                <p>Intensidad del impacto</p>
                            </th>
                            <th>
                                <p>Resultado</p>
                            </th>
                            <th v-if="!page.finalized"></th>
                        </tr>
                        </thead>
                        <tbody>
                        <template v-for="(aspect, factor) in aspectsByFactor">
                            <tr>
                                <td :rowspan="aspect.length">{{ factor }}</td>
                                <td>{{ aspect[0].name }}</td>
                                <td>{{ impacts[aspect[0].impact] }}</td>
                                <td>{{ intensities[aspect[0].intensity] }}</td>
                                <td>{{ results[aspect[0].intensity*(aspect[0].impact == 0 ? -1 : 1)] }}</td>
                                <th v-if="!page.finalized">
                                    <p style="width: 60px">
                                        <button type="button" class="btn btn-primary btn-icon-sm p-1 text-white" title="Edicion" @click="editAspect(aspect[0])">
                                            <i class="material-icons font-size-16 align-middle">
                                                create
                                            </i>
                                        </button>
                                        <button type="button" class="btn btn-danger btn-icon-sm p-1 text-white" title="Eliminar" @click="deleteAspect(aspect[0])">
                                            <i class="material-icons font-size-16 align-middle">
                                                deleted
                                            </i>
                                        </button>
                                    </p>
                                </th>
                            </tr>
                            <template v-for="(data, index) in aspect" v-if="index > 0">
                                <tr>
                                    <td>{{ data.name }}</td>
                                    <td>{{ impacts[data.impact] }}</td>
                                    <td>{{ intensities[data.intensity] }}</td>
                                    <td>{{ results[data.intensity*(data.impact == 0 ? -1 : 1)] }}</td>
                                    <th v-if="!page.finalized">
                                        <p style="width: 60px">
                                            <button type="button" class="btn btn-primary btn-icon-sm p-1 text-white" title="Edicion" @click="editAspect(data)">
                                                <i class="material-icons font-size-16 align-middle">
                                                    create
                                                </i>
                                            </button>
                                            <button type="button" class="btn btn-danger btn-icon-sm p-1 text-white" title="Eliminar" @click="deleteAspect(data)">
                                                <i class="material-icons font-size-16 align-middle">
                                                    deleted
                                                </i>
                                            </button>
                                        </p>
                                    </th>
                                </tr>
                            </template>
                        </template>
                        </tbody>
                    </table>
                </div>
                <div class="row py-2" v-if="!page.finalized">
                    <div class="col">
                        <button class="btn btn-red w-100" type="button" @click="showNewAspect = true">
                            <i class="material-icons align-middle">
                                add
                            </i>
                            Nuevo aspecto a evaluar
                        </button>
                    </div>
                    <div class="col">
                        <button class="btn btn-success w-100" @click="finishTask">
                            <i class="material-icons align-middle">check</i> Finalizar este proceso
                        </button>
                    </div>
                </div>
            </template>
        </Pages>
        <NewAspect :show="showNewAspect"
                   @close="showNewAspect = false"
                   @awaiting="awaiting"
                   @resume="resume"
                   :factors="factors"
                   @new-aspect="getAspects"></NewAspect>
        <EditAspect :show="showEditAspect"
                   @close="showEditAspect = false"
                   :factors="factors"
                    :aspect-to-edit="aspectToEdit"
                    @awaiting="awaiting"
                    @resume="resume"
                   @edit-aspect="getAspects"></EditAspect>
        <Alert :title="alert.title"
               :type="alert.type"
               :message="alert.message"
               :show="alert.show"
               :button1="alert.button1"
               @close="alert.show = false"></Alert>
    </div>
</template>
<script>
import Axios from "axios";

// models
import PageModel from "./PageModel";

// components
import Pages from "../components/Pages";
import NewAspect from "../components/Aspect/new"
import EditAspect from "../components/Aspect/edit"
import Button from "../components/Alert/Button";
import Alert from "../components/Alert";

export default {
    name: "Pestel",
    mixins: [ PageModel ],
    data(){
        return {
            aspects: [],
            factors: [],
            impacts: [
                "Negativo",
                "Positivo"
            ],
            intensities: {
                1 : "Bajo",
                2 : "Medio",
                3 : "Alto"
            },
            results: {
                1 : "Menor oportunidad",
                2 : "Oportunidad",
                3 : "Mayor oportunidad",
                '-1' : "Menor amenaza",
                '-2' : "Amenaza",
                '-3' : "Mayor amenaza"
            },
            showNewAspect: false,
            showEditAspect: false,
            aspectToEdit: null,

            confirmDeleteAspect: false,
            //alert
            alert: {
                title: "",
                message: "",
                type: "success",
                show: false,
                button1: undefined
            },
            //
            confirmFinishTask: false
        }
    },
    components: {
        Pages,
        NewAspect,
        EditAspect,
        Alert
    },
    methods: {
        afterComplete(data){
            this.factors = data.factors;
            this.getAspects();
        },
        async getAspects(){
            this.aspects = [];
            await Axios.get("/api/" + this.$options.name + "/aspect", this.axiosConfig)
                .then(response => {
                    this.aspects = response.data;
                }).catch(error => {
                    this.errorGetPage(error);
                })
        },
        getFactorById(id){
            for(let index in this.factors){
                if(this.factors[index].id == id){
                    return this.factors[index];
                }
            }
        },
        editAspect(aspect){
            this.showEditAspect = true;
            this.aspectToEdit = aspect;
        },
        async deleteAspect(aspect){
            if(this.confirmDeleteAspect){
                await Axios.delete("/api/" + this.$options.name + "/aspect/" + aspect.id, this.axiosConfig)
                    .then(response => {
                        this.alertAfterAction("Operación culminada con éxito", response.data.message, "success");
                        this.getAspects();
                    }).catch(error => {
                        this.alertAfterAction("la operación no se pudo completar", error.response.data.message, "danger");
                    })
                this.confirmDeleteAspect = false;
            }else{
                this.confirmAction("¿Esta seguro?", "¿Esta seguro de eliminar este aspecto?", () => {
                    this.confirmDeleteAspect = true;
                    this.deleteAspect(aspect);
                });
            }
        },
        alertAfterAction(title, message, type){
            this.$set(this.alert, "title", title);
            this.$set(this.alert, "message", message);
            this.$set(this.alert, "type", type);
            this.$set(this.alert, "show", true);
            let button1 = new Button();
            button1.setDisable(true);
            button1.setText("Aceptar");
            this.$set(this.alert, "button1", button1);
        },
        confirmAction(title, message, actionConfirm){
            this.$set(this.alert, "title", title);
            this.$set(this.alert, "message", message);
            this.$set(this.alert, "type", "success");
            this.$set(this.alert, "show", true);
            let button1 = new Button();
            button1.setText("Aceptar");
            button1.setOnClick(actionConfirm);
            this.$set(this.alert, "button1", button1);
        },
        async finishTask(){
            if(this.confirmFinishTask){
                await Axios.post("/api/" + this.$options.name , {}, this.axiosConfig)
                    .then(response => {
                        this.alertAfterAction("Operación culminada con éxito", response.data.message, "success");
                        this.page.finalized = true;
                    }).catch(error => {
                        this.alertAfterAction("la operación no se pudo completar", error.response.data.message, "danger");
                    })
                this.confirmFinishTask = false;
            }else{
                this.confirmAction("¿Esta seguro de finalizar el proceso?", "Si finaliza el proceso no podra editar ni eliminar ningun registro", () => {
                    this.confirmFinishTask = true;
                    this.finishTask();
                });
            }
        }
    },
    computed: {
        aspectsByFactor(){
            let aspects = {};
            for(let index in this.aspects){
                if(aspects[this.getFactorById(this.aspects[index].factor_id).name] === undefined){
                    aspects[this.getFactorById(this.aspects[index].factor_id).name] = [];
                }
                aspects[this.getFactorById(this.aspects[index].factor_id).name].push(this.aspects[index]);
            }
            return aspects;
        }
    }
}
</script>
