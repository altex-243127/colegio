<template>
    <div>
        <Pages title="Grupos de interes"
               :page="page"
               :get-page="getPage"
               :authorized="authorized">
            <template slot="body">
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                        <tr>
                            <th>
                                <p style="width: 250px" class="m-0">Categoria</p>
                            </th>
                            <th>
                                <p style="width: 150px" class="m-0">Grupo de interes</p>
                            </th>
                            <th>
                                <p style="width: 150px" class="m-0">Grado de poder</p>
                            </th>
                            <th>
                                <p style="width: 150px" class="m-0">Grado de interes</p>
                            </th>
                            <th>
                                <p style="width: 150px" class="m-0">Necesidad</p>
                            </th>
                            <th>
                                <p style="width: 150px" class="m-0">Expectativa</p>
                            </th>
                            <th>
                                <p style="width: 150px" class="m-0">Riesgo/Oportunidad</p>
                            </th>
                            <th>
                                <p style="width: 150px" class="m-0">Area encargada</p>
                            </th>
                            <th>
                                <p style="width: 100px" class="m-0">Requerido</p>
                            </th>
                            <th></th>
                        </tr>
                        </thead>
                        <tbody>
                        <template v-for="group in groups">
                            <tr>
                                <td>{{ getNameCategory(group.category_id) }}</td>
                                <td>{{ group.name }}</td>
                                <td>{{ group.power == 0 ? "Bajo" : "Alto" }}</td>
                                <td>{{ group.interest == 0 ? "Bajo" : "Alto" }}</td>
                                <td>{{ getNameNeed(group.need_id) }}</td>
                                <td>{{ getNameExpectation(group.expectation_id) }}</td>
                                <td>{{ group.risk == 0 ? "Oportunidad" : "Riesgo" }}</td>
                                <td>{{ getNameArea(group.area_id) }}</td>
                                <td>{{ group.required == 1 ? "Si" : "No"}}</td>
                                <td>
                                    <button style="width:150px" class="btn btn-red" type="button" @click="showManagement(group.id)">
                                        <template v-if="onlyArea">Agregar gestión</template>
                                        <template v-else>Ver gestión</template>
                                    </button>
                                </td>
                            </tr>
                        </template>
                        </tbody>
                    </table>
                </div>

                <div class="row py-2" v-if="!page.finalized && !onlyArea">
                    <div class="col">
                        <button class="btn btn-red w-100" type="button" @click="showNewGroup = true">
                            <i class="material-icons align-middle">
                                add
                            </i>
                            Nuevo grupo de interes
                        </button>
                    </div>
                    <div class="col" >
                        <button class="btn btn-success w-100" @click="finishTask">
                            <i class="material-icons align-middle">check</i> Finalizar este proceso
                        </button>
                    </div>
                </div>
            </template>
        </Pages>
        <NewInterest :show="showNewGroup"
                     :categories="categories"
                     :expectations="expectations"
                     :areas="areas"
                     @close="showNewGroup = false"
                     @new-group="newGroup"
                     :needs="needs"></NewInterest>

        <Alert :title="alert.title"
               :type="alert.type"
               :message="alert.message"
               :show="alert.show"
               :button1="alert.button1"
               @close="alert.show = false"></Alert>

    </div>
</template>
<script>
    import Axios from "axios";

    // models
    import PageModel from "./PageModel";

    // components
    import Pages from "../components/Pages";
    import NewInterest from "../components/InterestGroups/new";
    import Button from "../components/Alert/Button";
    import jQuery from "jquery";

    export default {
        name: "InterestGroups",
        mixins: [ PageModel ],
        components: {
            Pages,
            NewInterest
        },
        data(){
            return {
                onlyArea: true,
                groups: [],
                categories: [],
                expectations: [],
                areas: [],
                needs: [],
                gestions: [],
                showNewGroup: false
            }
        },
        methods: {
            afterComplete(data){
                this.onlyArea = data.onlyArea;
                this.groups = data.groups;
                this.categories = data.categories;
                this.needs = data.needs;
                this.expectations = data.expectations;
                this.areas = data.areas;
                this.gestions = data.gestions;
            },
            getNameNeed(id){
                for(let index in this.needs){
                    if(this.needs[index].id == id){
                        return this.needs[index].name;
                    }
                }
            },
            getNameExpectation(id){
                for(let index in this.expectations){
                    if(this.expectations[index].id == id){
                        return this.expectations[index].name;
                    }
                }
            },
            getNameCategory(id){
                for(let index in this.categories){
                    if(this.categories[index].id == id){
                        return this.categories[index].name;
                    }
                }
            },
            getNameArea(id){
                for(let index in this.areas){
                    if(this.areas[index].id == id){
                        return this.areas[index].name;
                    }
                }
            },
            newGroup(){
                this.showAlert({
                    title: "Operacion completada con exito",
                    message: "Grupo de interes creado con exito",
                    type: "success"
                });
                this.getPage();
            },
            showManagement(id){
                let gestion = this.gestions.filter(item => {
                    return item.interest_groups_need_id == id;
                });

                if(this.onlyArea){

                    let gestionValue = "";
                    let gestionFile = "";
                    if(gestion.length > 0){
                        gestionValue = gestion[0].gestion;
                        gestionFile = gestion[0].file;
                    }

                    let html = "<div id='newGestion'><label>Gestión</label>" +
                        "<textarea id='gestionValue' class='form-control' placeholder='Gestión'>" + gestionValue + "</textarea>";
                    html += "<label>Archivo</label><br>";

                    html += "<div id='gestionFileBox'>";

                    if(gestionFile == ''){
                        html += "<label for='gestionFile' class='fileBox'><span>Adjuntar archivo</span><input id='gestionFile' type='file' accept='.jpg, .jpeg, .png, .pdf' /></label>";
                    }else{
                        html += "<iframe width='100%' height='200px' frameborder='0' src='/gestions/" + gestionFile + "'></iframe>";
                        html += "<i class='delete'>Borrar</i>"
                    }

                    html += "</div>";
                    html += "</div>";
                    let btn = new Button();
                    btn.setText("Enviar gestión")
                    btn.setOnClick(() => {
                        let gestionValue = document.getElementById("gestionValue")
                        let gestionFile = document.getElementById("gestionFile")
                        if(gestionValue.value == ""){
                            alert("El campo gestión es obligatorio");
                            return;
                        }
                        let form = new FormData();
                        form.append("gestion", gestionValue.value);
                        form.append("need_id", id);
                        if(gestionFile != undefined){
                            if(gestionFile.files.length > 0){
                                form.append("file", gestionFile.files[0]);
                            }
                        }
                        Axios.post("api/InterestGroups/addGestion", form)
                            .then(res => {
                                let response = JSON.parse(res.request.response);
                                alert(response.message);
                            })
                            .catch(error => {
                                let response = JSON.parse(error.request.response);
                                alert(response.message);
                            })
                    })
                    this.showAlert({
                        title: "Agregar gestión",
                        message: html,
                        type: "success",
                        button: btn
                    });
                    jQuery("body").on("change", "#gestionFile", function (){
                        let gestionFile = jQuery("#gestionFile");
                        let file = gestionFile[0].files[0].name;
                        jQuery("<i class='delete'>Borrar</i>").insertAfter(".fileBox");
                        jQuery(".fileBox span").html(file);
                    })
                    jQuery("body").on("click", "#gestionFileBox .delete", function (){
                        let gestionFile = jQuery("#gestionFileBox").html("<label for='gestionFile' class='fileBox'><span>Adjuntar archivo</span><input id='gestionFile' type='file' accept='.jpg, .jpeg, .png, .pdf' /></label>");
                        jQuery("#gestionFileBox .delete").remove();
                    })
                }else{

                    if(gestion.length == 0){

                        this.showAlert({
                            title: "Gestion parte ineteresada",
                            message: "Sin datos para mostrar",
                            type: "success"
                        });

                    }else{
                        let html = gestion[0].gestion;
                        if(gestion[0].file != ''){
                            html += "<iframe width='100%' height='600px' frameborder='0' src='/gestions/" + gestion[0].file + "'></iframe>"
                        }
                        this.showAlert({
                            title: "Gestion parte ineteresada",
                            message: html,
                            type: "success"
                        });
                    }
                }

            }
        }
    }
</script>
<style>
label.fileBox > input {
    display: none;
}
label.fileBox {
    display: flex;
    width: 100%;
    height: 200px;
    border: 1px solid #a9a9a9;
    justify-content: center;
    align-items: center;
    cursor: pointer;
    position: relative;
}
label.fileBox span {
    display: block;
    font-size: 20px;
    color: #2176bd;
    text-align: center;
}
div#gestionFileBox {
    position: relative;
}
#gestionFileBox .delete {
    position: absolute;
    right: 0%;
    bottom: 0%;
    padding: 5px 20px;
    background-color: #fd5e5e;
    color: #fff;
    width: 100%;
    text-align: center;
    cursor:pointer;
}
</style>
