<template>
    <div>
        <Pages title="Matriz de cobertura de los temas estrategicos"
               :page="page"
               :get-page="getPage"
               :authorized="authorized">
            <template slot="body">
                <div class="row my-4">
                    <div class="col">
                        <div class="table-responsive">
                            <table class="table table-hover table-bordered">
                                <tr>
                                    <th rowspan="2">
                                        <div class="title-table-dofa" style="width: 250px">
                                            <span class="first">&nbsp</span>
                                            <hr>
                                            <span class="last">Temas estrategicos</span>
                                        </div>
                                    </th>
                                    <th :colspan="strategicIssues.length" class="text-center alert-primary">Dofa</th>
                                    <th :colspan="interestGroups.length" class="text-center alert-primary">Grupos de interes</th>
                                    <th colspan="3" class="text-center alert-primary">Estrategia</th>
                                </tr>
                                <tr>
                                    <template v-for="data in strategicIssues">
                                        <th class="align-middle">
                                            <div style="width: 100px" @mouseenter="showTooltip" @mouseleave="hideTooltip">
                                                <p class="m-0">
                                                    {{ data.strategy.name }}
                                                </p>
                                                <div class="tooltip">
                                                    {{ data.strategy.name }}
                                                </div>
                                            </div>
                                        </th>
                                    </template>
                                    <template v-for="data in interestGroups">
                                        <th class="align-middle">
                                            <div style="width: 100px" @mouseenter="showTooltip" @mouseleave="hideTooltip">
                                                <p style="width: 100px" class="m-0">
                                                    {{ data.name }}
                                                </p>
                                                <div class="tooltip">
                                                    {{ data.name }}
                                                </div>
                                            </div>
                                        </th>
                                    </template>
                                    <th class="align-middle">
                                        <div style="width: 100px" @mouseenter="showTooltip" @mouseleave="hideTooltip">
                                            <p style="width: 100px" class="m-0">
                                                Misión
                                            </p>
                                            <div class="tooltip">
                                                Misión
                                            </div>
                                        </div>
                                    </th>
                                    <th class="align-middle">
                                        <div style="width: 100px" @mouseenter="showTooltip" @mouseleave="hideTooltip">
                                            <p style="width: 100px" class="m-0">
                                                Visión
                                            </p>
                                            <div class="tooltip">
                                                Visión
                                            </div>
                                        </div>
                                    </th>
                                    <th class="align-middle">
                                        <div style="width: 100px" @mouseenter="showTooltip" @mouseleave="hideTooltip">
                                            <p style="width: 100px" class="m-0">
                                                Politica de calidad
                                            </p>
                                            <div class="tooltip">
                                                Politica de calidad
                                            </div>
                                        </div>
                                    </th>
                                </tr>
                                <template v-for="category in strategicIssuesCategories">
                                    <tr>
                                        <th>{{ category.name }}</th>
                                        <template v-for="data in strategicIssues">
                                            <th class="align-middle">
                                                <select class="form-control" v-model="scores.strategicIssues[category.id][data.id]" @change="setScore($event, 'strategicIssues', category.id, data.id)">
                                                    <option value=""></option>
                                                    <option v-for="(option, key) in options" :value="key">({{key}}) {{option}}</option>
                                                </select>
                                            </th>
                                        </template>
                                        <template v-for="data in interestGroups">
                                            <th class="align-middle">
                                                <select class="form-control" v-model="scores.interestGroups[category.id][data.id]" @change="setScore($event, 'interestGroups', category.id, data.id)">
                                                    <option value=""></option>
                                                    <option v-for="(option, key) in options" :value="key">({{key}}) {{option}}</option>
                                                </select>
                                            </th>
                                        </template>
                                        <template v-for="data in strategies">
                                            <th class="align-middle">
                                                <select class="form-control" v-model="scores.strategies[category.id][data.id]" @change="setScore($event, 'strategies', category.id, data.id)">
                                                    <option value=""></option>
                                                    <option v-for="(option, key) in options" :value="key">({{key}}) {{option}}</option>
                                                </select>
                                            </th>
                                        </template>
                                    </tr>
                                </template>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="row" v-if="!page.finalized">
                    <div class="col">
                        <button class="btn btn-success w-100" @click="sendScores">
                            <i class="material-icons align-middle">check</i> Enviar calificación
                        </button>
                    </div>
                </div>
            </template>
        </Pages>

        <Alert :title="alert.title"
               :type="alert.type"
               :message="alert.message"
               :show="alert.show"
               :button1="alert.button1"
               @close="alert.show = false"></Alert>
    </div>
</template>
<script>
import Axios from 'axios';

// models
import PageModel from "./PageModel";

// components
import Pages from "../components/Pages";
import Button from "../components/Alert/Button"


export default {
    name: "StrategicIssuesMatrixScore",
    mixins: [ PageModel ],
    data(){
        return {
            strategicIssues: [],
            strategicIssuesCategories: [],
            interestGroups: [],
            strategies: [],
            options: {
                3: "Relación directa",
                1: "Baja Relación",
                0: "Sin Relación",
                "-1": "Baja relación Inversa",
                "-3": "Alta relación Inversa"
            },
            scores: {
                strategicIssues: {},
                interestGroups: {},
                strategies: {}
            },
            confirmSend: false
        }
    },
    methods: {
        afterComplete(data){
            this.strategicIssues = data.strategicIssues;
            this.strategicIssuesCategories = data.strategicIssuesCategories;
            this.interestGroups = data.interestGroups;
            this.strategies = data.strategies;
        },
        showTooltip(e){
            const children = e.target.children;
            for(let index in children){
                if(children[index].className != undefined){
                    if(children[index].className.indexOf("tooltip") >= 0){
                        children[index].classList.add("show");
                    }
                }
            }
        },
        hideTooltip(e){
            const children = e.target.children;
            for(let index in children){
                if(children[index].className != undefined){
                    if(children[index].className.indexOf("tooltip") >= 0){
                        children[index].classList.remove("show");
                    }
                }
            }
        },
        setScore(e, type, category, id){
            this.$set(this.scores[type][category], id, e.target.value)
        },
        scoresInit(){
            for(let index in this.strategicIssuesCategories){
                this.$set(this.scores.interestGroups, this.strategicIssuesCategories[index].id, {});

                for(let i in this.interestGroups){
                    this.$set(this.scores.interestGroups[this.strategicIssuesCategories[index].id], this.interestGroups[i].id, this.getUserScore(this.interestGroups[i], this.strategicIssuesCategories[index].id))
                }

                this.$set(this.scores.strategicIssues, this.strategicIssuesCategories[index].id, {});

                for(let i in this.strategicIssues){
                    this.$set(this.scores.strategicIssues[this.strategicIssuesCategories[index].id], this.strategicIssues[i].id, this.getUserScore(this.strategicIssues[i], this.strategicIssuesCategories[index].id))
                }

                this.$set(this.scores.strategies, this.strategicIssuesCategories[index].id, {});

                for(let i in this.strategies){
                    this.$set(this.scores.strategies[this.strategicIssuesCategories[index].id], this.strategies[i].id, this.getUserScore(this.strategies[i], this.strategicIssuesCategories[index].id))
                }
            }
        },
        getUserScore(object, category){
            for(let index in object.user_score){
                if(object.user_score[index].strategic_issues_category_id == category){
                    return object.user_score[index].score;
                }
            }
        },
        validate(){
            let errors = 0;

            for(let index in this.scores.strategicIssues){
                if(Object.keys(this.scores.strategicIssues[index]).length != this.strategicIssues.length){
                    errors += 1;
                }
            }
            for(let index in this.scores.interestGroups){
                if(Object.keys(this.scores.interestGroups[index]).length != this.interestGroups.length){
                    errors += 1;
                }
            }
            for(let index in this.scores.strategies){
                if(Object.keys(this.scores.strategies[index]).length != 3){
                    errors += 1;
                }
            }
            return errors == 0;
        },
        sendScores(){
            if(this.validate()){
                if(this.confirmSend){
                    Axios.post("/api/" + this.$options.name + "/score", {
                        scores: this.scores
                    }, {
                        headers: {
                            Accept: 'application/json',
                            Authorization: 'Bearer ' + localStorage.autenticate_token
                        }
                    }).then(response => {
                        this.$emit("reload");
                        this.showAlert({
                            title: "Calificación enviada con éxito",
                            message: response.data.message,
                            type: "success"
                        });
                    }).catch(error => {
                        this.showAlert({
                            title: "Error",
                            message: error.response.data.message,
                            type: "danger"
                        });
                    })
                }else{
                    let button = new Button();
                    button.setText("Confirmar");
                    button.setDisable(false);
                    button.setOnClick(() => {
                        this.confirmSend = true;
                        this.sendScores();
                    });
                    this.showAlert({
                        title: "Confirmación",
                        message: "¿Esta seguro de enviar esta calificación? Recuerde que no podra cambiarla",
                        type: "info",
                        button: button
                    });
                }
            }else{
                this.showAlert({
                    title: "Validación",
                    message: "Debe calificar todos los aspectos",
                    type: "danger"
                })
            }
        }
    },
    components: {
        Pages
    },
    watch: {
        strategicIssuesCategories(value){
            this.scoresInit();
        }
    },
    mounted() {
        this.scoresInit();
    }
}
</script>

<style>
    .title-table-dofa hr{
        transform: rotate(16deg);
    }
    .title-table-dofa span.first{
        display: block;
        text-align: right;
        padding-right: 15%;
    }
    .title-table-dofa span.last{
        display: block;
        text-align: left;
        padding-left: 15%;
    }
    th{
        position: relative;
    }
    th p{
        word-break: break-all;
        white-space: nowrap;
        overflow: hidden;
        cursor:pointer;
    }
    .tooltip {
        background-color: rgba(0, 0, 0, 0.5);
        color: #fff;
        width: 200px;
        padding: 5px;
        pointer-events: none;
    }
</style>
