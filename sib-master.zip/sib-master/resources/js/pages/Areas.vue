<template>
    <div>
        <Pages title="Areas"
               :page="page"
               :get-page="getPage"
               :authorized="authorized">
            <template slot="body">

                <div class="row mb-4">
                    <div class="col-12 text-right">
                        <button class="btn btn-red" type="button" @click="showNew = true">
                            Nueva area
                        </button>
                    </div>
                </div>

                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                        <tr>
                            <th>Nombre</th>
                            <th></th>
                        </tr>
                        </thead>
                        <tbody>
                            <tr v-for="area in areas">
                                <td>{{ area.name }}</td>
                                <td>
                                    <button class="btn btn-red" type="button" @click="editArea(area)">
                                        Editar
                                    </button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </template>
        </Pages>

        <edit :show="showEdit"
              :area="areaEdit"
              @success="success($event)"
              @error="showAlert({'title' : 'Mensaje del sistema', 'message' : $event, 'type': 'danger'})"
              @close="showEdit = false"></edit>

        <new-area :show="showNew"
              @success="success($event)"
              @error="showAlert({'title' : 'Mensaje del sistema', 'message' : $event, 'type': 'danger'})"
              @close="showNew = false"></new-area>

        <Alert :title="alert.title"
               :type="alert.type"
               :message="alert.message"
               :show="alert.show"
               :button1="alert.button1"
               @close="alert.show = false"></Alert>

    </div>
</template>
<script>
    import Axios from "axios";

    // models
    import PageModel from "./PageModel";

    // components
    import Pages from "../components/Pages";
    import edit from "../components/area/edit";
    import newArea from "../components/area/new";

    export default {
        name: "areas",
        data(){
            return {
                areas: [],
                showEdit: false,
                areaEdit: {},
                showNew: false
            }
        },
        mixins: [ PageModel ],
        components: {
            Pages,
            edit,
            newArea
        },
        methods: {
            afterComplete(data){
                this.areas = data.areas;
            },
            editArea(area){
                this.showEdit = true;
                this.areaEdit = area;
            },
            success(message){
                this.showAlert({'title' : 'Mensaje del sistema', 'message' : message, 'type': 'success'});
                this.getPage();
            }
        }
    }
</script>
