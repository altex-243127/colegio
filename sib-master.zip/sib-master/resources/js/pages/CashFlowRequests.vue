<template>
    <div>
        <Pages title="Solicitudes de flujo de caja"
               :page="page"
               :get-page="getPage"
               :authorized="authorized">
            <template slot="body">
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                        <tr>
                            <th>Área</th>
                            <th>Solicitud</th>
                            <th>Valor Solicitada</th>
                            <th>Estado</th>
                        </tr>
                        </thead>
                        <tbody>
                            <template v-for="request in requests">
                                <tr>
                                    <td>{{ request.activity.budget.area.name }}</td>
                                    <td>
                                        <button class="btn btn-red" type="button" @click="showDetailActivity(request.activity)">
                                            Ver solicitud
                                        </button>
                                    </td>
                                    <td>{{ new Intl.NumberFormat().format(getTotalRequest(request)) }}</td>
                                    <td>
                                        <button class="btn btn-success" type="button" @click="approve(request)">
                                            Aprobar
                                        </button>
                                        <button class="btn btn-danger" type="button" @click="refuse(request)">
                                            Rechazar
                                        </button>
                                    </td>
                                </tr>
                            </template>
                        </tbody>
                    </table>
                </div>
            </template>
        </Pages>

        <Alert :title="alert.title"
               :type="alert.type"
               :message="alert.message"
               :show="alert.show"
               :button1="alert.button1"
               @close="alert.show = false"></Alert>

        <Detail :show="detailShow" :activity="detailActivity" @close="detailShow = false"></Detail>

    </div>
</template>
<script>
    import Axios from "axios";

    // models
    import PageModel from "./PageModel";

    // components
    import Pages from "../components/Pages";
    import Detail from "../components/Activity/Detail";

    export default {
        name: "CashFlowRequests",
        mixins: [ PageModel ],
        components: {
            Pages,
            Detail
        },
        data(){
            return {
                requests: [],
                detailShow: false,
                detailActivity: {}
            }
        },
        methods: {
            afterComplete(data){
                this.requests = data.requests;
            },
            getTotalRequest(request){
                let total = 0;

                request.activity.resources.map(item => {
                    total += item.quantity * item.value;
                })

                return total;
            },
            showDetailActivity(activity){
                this.detailShow = true;
                this.detailActivity = activity;
            },
            approve(request){
                if(confirm("¿Esta seguro que desea aprobar este monto?")){
                    Axios.post("/api/CashFlowRequests/approve/" + request.id, {}, {
                        headers: {
                            Accept: 'application/json',
                            Authorization: 'Bearer ' + localStorage.autenticate_token
                        }
                    }).then(response => {
                        this.showAlert({
                            title: "La operación se completo con éxito",
                            message: response.data.message,
                            type: "success"
                        })
                        this.getPage();
                    }).catch(error => {
                        this.showAlert({
                            title: "La operación no se pudo completar",
                            message: error.response.data.message,
                            type: "danger"
                        })
                    })
                }
            },
            refuse(request){
                if(confirm("¿Esta seguro que desea rechazar este monto?")){
                    Axios.post("/api/CashFlowRequests/refuse/" + request.id, {}, {
                        headers: {
                            Accept: 'application/json',
                            Authorization: 'Bearer ' + localStorage.autenticate_token
                        }
                    }).then(response => {
                        this.showAlert({
                            title: "La operación se completo con éxito",
                            message: response.data.message,
                            type: "success"
                        })
                        this.getPage();
                    }).catch(error => {
                        this.showAlert({
                            title: "La operación no se pudo completar",
                            message: error.response.data.message,
                            type: "danger"
                        })
                    })
                }
            },
        }
    }
</script>
