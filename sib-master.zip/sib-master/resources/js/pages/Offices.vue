<template>
    <div>
        <Pages title="Oficinas"
               :page="page"
               :get-page="getPage"
               :authorized="authorized">
            <template slot="body">

                <div class="row mb-4">
                    <div class="col-12 text-right">
                        <button class="btn btn-red" type="button" @click="showNew = true">
                            Nueva oficina
                        </button>
                    </div>
                </div>

                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                        <tr>
                            <th>Nombre</th>
                            <th>Area</th>
                            <th></th>
                        </tr>
                        </thead>
                        <tbody>
                            <tr v-for="office in offices" v-if="office.area != null">
                                <td>{{ office.name }}</td>
                                <td>{{ office.area.name }}</td>
                                <td>
                                    <button class="btn btn-red" type="button" @click="editOffice(office)">
                                        Editar
                                    </button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </template>
        </Pages>

        <edit :show="showEdit"
              :office="officeEdit"
              @success="success($event)"
              @error="showAlert({'title' : 'Mensaje del sistema', 'message' : $event, 'type': 'danger'})"
              @close="showEdit = false"></edit>

        <new-office :show="showNew"
              @success="success($event)"
              @error="showAlert({'title' : 'Mensaje del sistema', 'message' : $event, 'type': 'danger'})"
              @close="showNew = false"></new-office>

        <Alert :title="alert.title"
               :type="alert.type"
               :message="alert.message"
               :show="alert.show"
               :button1="alert.button1"
               @close="alert.show = false"></Alert>

    </div>
</template>
<script>
    import Axios from "axios";

    // models
    import PageModel from "./PageModel";

    // components
    import Pages from "../components/Pages";
    import edit from "../components/Office/edit";
    import newOffice from "../components/Office/new";

    export default {
        name: "offices",
        data(){
            return {
                offices: [],
                showEdit: false,
                officeEdit: {},
                showNew: false
            }
        },
        mixins: [ PageModel ],
        components: {
            Pages,
            edit,
            newOffice
        },
        methods: {
            afterComplete(data){
                this.offices = data.offices;
            },
            editOffice(office){
                this.showEdit = true;
                this.officeEdit = office;
            },
            success(message){
                this.showAlert({'title' : 'Mensaje del sistema', 'message' : message, 'type': 'success'});
                this.getPage();
            }
        }
    }
</script>
