<template>
    <div>
        <Pages title="Asignacion de cuentas"
               :page="page"
               :get-page="getPage"
               :authorized="authorized">
            <template slot="body">
                <div class="table-responsive">
                    <template v-for="(areaBudgets, area) in budgetOrderByArea">
                        <button class="btn btn-primary w-100 mb-2" type="button" data-toggle="collapse" @click="collapse" :data-target="'#' + area">
                            {{ area.split('-')[0] }}
                        </button>
                        <div class="collapse" :id="area">
                            <table class="table table-bordered">
                                <thead>
                                <tr>
                                    <th>Area</th>
                                    <th>Objetivo</th>
                                    <th>Estrategia</th>
                                    <th></th>
                                </tr>
                                </thead>
                                <tbody>
                                <template v-for="budget in areaBudgets">
                                    <tr>
                                        <td>{{ budget.area.name }}</td>
                                        <td>{{ budget.objective.objective }}</td>
                                        <td>{{ budget.strategy.name }}</td>
                                        <td>
                                            <button class="btn btn-red" type="button" @click="showResources(budget)">
                                                Actividades
                                            </button>
                                        </td>
                                    </tr>
                                </template>
                                </tbody>
                            </table>
                        </div>
                    </template>
                </div>

                <div class="row my-3" v-if="!page.finalized">
                    <div class="col-12">
                        <button class="btn btn-success w-100" @click="finishTask">
                            <i class="material-icons align-middle">check</i> Finalizar este proceso
                        </button>
                    </div>
                </div>

            </template>
        </Pages>

        <Alert :title="alert.title"
               :type="alert.type"
               :message="alert.message"
               :show="alert.show"
               :button1="alert.button1"
               @close="alert.show = false"></Alert>

        <show :show="show"
             :budget="budget"
             @close="show = false"
             :finalized="page.finalized"
             @success="showSuccess($event)"
             @error="showError($event)"></show>

    </div>
</template>
<script>
    import Axios from "axios";
    import jQuery from "jquery";

    // models
    import PageModel from "./PageModel";

    // components
    import Pages from "../components/Pages";
    import show from "../components/Budget/ShowResources";

    export default {
        name: "SetAccounts",
        mixins: [ PageModel ],
        data(){
            return {
                budgets: [],
                show: false,
                budget: {}
            }
        },
        components: {
            Pages,
            show
        },
        methods: {
            afterComplete(data){
                this.budgets = data.budget;
            },
            showResources(budget){
                this.show = true;
                this.budget = budget;
            },
            showError(message){
                this.showAlert({
                    title: "La operación no se pudo completar",
                    message: message,
                    type: "danger"
                })
            },
            showSuccess(message){
                this.showAlert({
                    title: "Operacion completada con exito",
                    message: message,
                    type: "success"
                });
                this.getPage();
            },
            collapse(event){
                jQuery(event.target.dataset.target).collapse("toggle");
            }
        },
        computed: {
            budgetOrderByArea(){
                let order = {};
                this.budgets.map(item => {
                    if(item.activities.length > 0){
                        if(order[item.area.name + "-" + item.area.id] == undefined){
                            order[item.area.name + "-" + item.area.id] = []
                        }
                        order[item.area.name + "-" + item.area.id].push(item);
                    }
                })
                return order;
            }
        },
    }
</script>
