<template>
    <div>
        <Pages title="Años"
               :page="page"
               :get-page="getPage"
               :authorized="authorized">
            <template slot="body">
                <div class="row">
                    <div class="col-12 text-right">
                        <button type="button" class="btn btn-success" data-toggle="modal" data-target="#newYear">Crear Año</button>
                    </div>
                </div>
                <div class="row">
                    <div class="col-3" v-for="year in years">
                        <button type="button" class="btn btn-red w-100 my-2">
                            {{ year.year }}
                        </button>
                    </div>
                </div>
            </template>
        </Pages>

        <Alert :title="alert.title"
               :type="alert.type"
               :message="alert.message"
               :show="alert.show"
               :button1="alert.button1"
               @close="alert.show = false"></Alert>

        <div class="modal fade" id="newYear">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Nuevo año</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-12">
                                <div class="row" v-if="message.value != ''">
                                    <div class="col">
                                        <p class="p-2" :class="'alert-' + message.type" v-html="message.value"></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12">
                                <label for="year">Año</label>
                                <input type="number" class="form-control" placeholder="Año" id="year" v-model="year">
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                        <button type="button" class="btn btn-primary" data-dismiss="modal" @click="save">Guardar</button>
                    </div>
                </div>
            </div>
        </div>

    </div>
</template>
<script>
    import Axios from "axios";

    // models
    import PageModel from "./PageModel";

    // components
    import Pages from "../components/Pages";

    export default {
        name: "Years",
        mixins: [ PageModel ],
        data(){
            return {
                years: [],
                year: "",
                message: {
                    type: "success",
                    value: ""
                }
            }
        },
        components: {
            Pages
        },
        methods: {
            afterComplete(data){
                this.years = data.years;
            },
            save(){
                if(this.year == ''){
                    this.message.type = "danger";
                    this.message.value = "El campo año es obligatorio";
                    return;
                }
                this.awaiting()
                Axios.post("/api/Years", {
                    year: this.year
                }, this.axiosConfig)
                .then(response => {
                    this.showAlert({
                        title: "Mensaje del sistema",
                        message: response.data.message,
                        type: "success"
                    })
                    this.resume();
                    this.getPage();
                }).catch(error => {
                    this.showAlert({
                        title: "Mensaje del sistema",
                        message: response.data.message,
                        type: "danger"
                    })
                    this.resume();
                })
            }
        }
    }
</script>
