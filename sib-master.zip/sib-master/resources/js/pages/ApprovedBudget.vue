<template>
    <div>
        <Pages title="Presupuesto aprobado"
               :page="page"
               :get-page="getPage"
               :authorized="authorized">
            <template slot="body">
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                        <tr>
                            <th>Objetivo</th>
                            <th>Estrategia</th>
                            <th></th>
                        </tr>
                        </thead>
                        <tbody>
                        <template v-for="budget in budgets">
                            <tr>
                                <td>{{ budget.objective.objective }}</td>
                                <td>{{ budget.strategy.name }}</td>
                                <td>
                                    <button class="btn btn-red" type="button" v-if="budget.activities.length > 0" @click="showDetail(budget)">
                                        Actividades
                                    </button>
                                </td>
                            </tr>
                        </template>
                        </tbody>
                    </table>
                </div>
            </template>
        </Pages>

        <Alert :title="alert.title"
               :type="alert.type"
               :message="alert.message"
               :show="alert.show"
               :button1="alert.button1"
               @close="alert.show = false"></Alert>

        <detail-budget :show="show"
                       :budget="budgetDetail"
                       @success="requestSuccess($event)"
                       @error="showAlert($event)"
                       @close="closeBudgetDetail($event)"></detail-budget>

    </div>
</template>
<script>
    import Axios from "axios";
    import DetailBudget from "../components/Budget/Detail"

    // models
    import PageModel from "./PageModel";

    // components
    import Pages from "../components/Pages";

    export default {
        name: "Budget/Approved",
        mixins: [ PageModel ],
        components: {
            Pages,
            DetailBudget
        },
        data() {
            return {
                budgets: [],
                show: false,
                budgetDetail: {}
            }
        },
        methods: {
            afterComplete(data) {
                this.budgets = data.budget;
            },
            showDetail(budget){
                this.show = true;
                this.budgetDetail = budget;
            },
            requestSuccess(data){
                this.showAlert(data);
                this.getPage();
            },
            closeBudgetDetail(data){
                this.show = false;
                this.budgetDetail = {};
            }
        }
    }
</script>
