<template>
    <div>
        <Pages title="Usuarios"
               :page="page"
               :get-page="getPage"
               :authorized="authorized">
            <template slot="body">

                <div class="row mb-4">
                    <div class="col-12 text-right">
                        <button class="btn btn-red" type="button" @click="showNew = true">
                            Nuevo usuario
                        </button>
                    </div>
                </div>

                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                        <tr>
                            <th>Nombre</th>
                            <th>Email</th>
                            <th>Oficina</th>
                            <th>Área</th>
                            <th></th>
                        </tr>
                        </thead>
                        <tbody>
                            <tr v-for="user in users">
                                <td>{{ user.name }}</td>
                                <td>{{ user.email }}</td>
                                <td>{{ user.office == undefined ? "Si asignar" : user.office.name}}</td>
                                <td>{{ user.office == undefined ? "Si asignar" : user.office.area.name }}</td>
                                <td>
                                    <button class="btn btn-red" type="button" @click="editUser(user)">
                                        Editar
                                    </button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </template>
        </Pages>

        <edit :show="showEdit"
              :user="userEdit"
              @success="success($event)"
              @error="showAlert({'title' : 'Mensaje del sistema', 'message' : $event, 'type': 'danger'})"
              @close="showEdit = false"></edit>

        <new-user :show="showNew"
              @success="success($event)"
              @error="showAlert({'title' : 'Mensaje del sistema', 'message' : $event, 'type': 'danger'})"
              @close="showNew = false"></new-user>

        <Alert :title="alert.title"
               :type="alert.type"
               :message="alert.message"
               :show="alert.show"
               :button1="alert.button1"
               @close="alert.show = false"></Alert>

    </div>
</template>
<script>
    import Axios from "axios";

    // models
    import PageModel from "./PageModel";

    // components
    import Pages from "../components/Pages";
    import edit from "../components/users/edit";
    import newUser from "../components/users/new";

    export default {
        name: "users",
        data(){
            return {
                users: [],
                showEdit: false,
                userEdit: {},
                showNew: false
            }
        },
        mixins: [ PageModel ],
        components: {
            Pages,
            edit,
            newUser
        },
        methods: {
            afterComplete(data){
                this.users = data.users;
            },
            editUser(user){
                this.showEdit = true;
                this.userEdit = user;
            },
            success(message){
                this.showAlert({'title' : 'Mensaje del sistema', 'message' : message, 'type': 'success'});
                this.getPage();
            }
        }
    }
</script>
