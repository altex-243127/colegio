<template>
    <div>
        <Pages title="Solicitud de insumos"
               :page="page"
               :get-page="getPage"
               :authorized="authorized">
            <template slot="body">

                <div class="row mb-4">
                    <div class="col-12">
                        <h3>Actividad</h3>
                        <p>
                            <strong>Acción a ejecutar:</strong> {{ activity.action }}
                        </p>
                        <p>
                            <strong>Descripción:</strong> {{ activity.description }}
                        </p>
                    </div>
                </div>

                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                        <tr>
                            <th>Insumo</th>
                            <th>Unidad</th>
                            <th>Cantidad</th>
                        </tr>
                        </thead>
                        <tbody>
                            <tr v-for="resource in activity.resources">
                                <td>{{ resource.description }}</td>
                                <td>{{ resource.unit }}</td>
                                <td>{{ resource.quantity }}</td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <div class="row">
                    <div class="col-12 text-right">
                        <button type="button" class="btn btn-primary" @click="send">
                            Solicitar insumos
                        </button>
                    </div>
                </div>

            </template>
        </Pages>

        <edit :show="showEdit"
              :area="areaEdit"
              @success="success($event)"
              @error="showAlert({'title' : 'Mensaje del sistema', 'message' : $event, 'type': 'danger'})"
              @close="showEdit = false"></edit>

        <new-area :show="showNew"
              @success="success($event)"
              @error="showAlert({'title' : 'Mensaje del sistema', 'message' : $event, 'type': 'danger'})"
              @close="showNew = false"></new-area>

        <Alert :title="alert.title"
               :type="alert.type"
               :message="alert.message"
               :show="alert.show"
               :button1="alert.button1"
               @close="alert.show = false"></Alert>

    </div>
</template>
<script>
    import Axios from "axios";

    // models
    import PageModel from "./PageModel";

    // components
    import Pages from "../components/Pages";
    import edit from "../components/area/edit";
    import newArea from "../components/area/new";

    export default {
        name: "requestSupplies",
        data(){
            return {
                activity: [],
                showEdit: false,
                areaEdit: {},
                showNew: false
            }
        },
        mixins: [ PageModel ],
        components: {
            Pages,
            edit,
            newArea
        },
        methods: {
            getPage(){
                Axios.get("/api/requestSupplies/" + this.$route.params.activity, this.axiosConfig)
                    .then(response => {
                        this.$set(this.page, "state", response.data.finishedDependencies ? response.data.canSee ? this.PAGE_STATE.complete : this.PAGE_STATE.notAuthorized : this.PAGE_STATE.dependenciesNotFinalized);
                        this.$set(this.page, "finalized", response.data.finalized);
                        this.$set(this.page, "depends", response.data.depends);
                        if(this.page.state == this.PAGE_STATE.complete){
                            this.afterComplete(response.data);
                        }
                        console.log("pagemodel", this.page.state);
                    })
                    .catch(error => {
                        this.errorGetPage(error);
                    })
            },
            afterComplete(data){
                this.activity = data.activity;
            },
            editArea(area){
                this.showEdit = true;
                this.areaEdit = area;
            },
            success(message){
                this.showAlert({'title' : 'Mensaje del sistema', 'message' : message, 'type': 'success'});
                this.getPage();
            },
            send(){
                Axios.post("/api/requestSupplies/" + this.$route.params.activity, this.axiosConfig)
                .then(response => {
                    this.showAlert({'title' : 'Mensaje del sistema', 'message' : response.data.message, 'type': 'success'});
                })
                .catch(error => {

                })
            }
        }
    }
</script>
