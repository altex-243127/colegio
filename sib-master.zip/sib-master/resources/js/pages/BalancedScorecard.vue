<template>
    <div>
        <Pages title="Cuadro de mando integral"
               :page="page"
               :get-page="getPage"
               :authorized="authorized">
            <template slot="body">
                <div class="table-responsive" style="height: 60vh;">
                    <table class="table table-bordered">
                        <thead>
                        <tr>
                            <th rowspan="2">
                                <p>Perspectiva</p>
                            </th>
                            <th rowspan="2">
                                <p style="width: 200px">Objectivos estrategicos</p>
                            </th>
                            <th rowspan="2">
                                <p style="width: 200px">Iniciativas estrategias</p>
                            </th>
                            <th colspan="2">
                                <p>Indicadores estrategicos</p>
                            </th>
                            <th colspan="3" class="text-center">
                                <p>Metas</p>
                            </th>
                            <th rowspan="2">
                                <p>Frecuancia de medición</p>
                            </th>
                            <th rowspan="2">
                                <p>Frecuencia de evaluación</p>
                            </th>
                            <th rowspan="2">
                                <p>Fuente de medición</p>
                            </th>
                            <th rowspan="2">
                                <p>Responsable medición</p>
                            </th>
                            <th rowspan="2">
                                <p>Responsable analisis</p>
                            </th>
                            <th rowspan="2">
                                <p style="width:100px">UEE</p>
                            </th>
                            <th rowspan="2"  v-if="!page.finalized">
                                <p></p>
                            </th>
                        </tr>
                        <tr>
                            <th>
                                <p style="width:200px;">Nombre</p>
                            </th>
                            <th>
                                <p style="width:200px;">Formula</p>
                            </th>
                            <th>
                                <p>Deseada</p>
                            </th>
                            <th>
                                <p>Aceptable</p>
                            </th>
                            <th>
                                <p>Minimo</p>
                            </th>
                        </tr>
                        </thead>
                        <template v-for="perspective in perspectives" v-if="perspective.objectives.length > 0">
                            <cell :perspective="perspective"
                                  @error="showError($event)"
                                  @success="showSuccess($event)"
                                  :finalized="page.finalized"
                                  :frequencies="frequencies"></cell>
                        </template>
                    </table>
                </div>
                <div class="row my-3" v-if="!page.finalized">
                    <div class="col-12">
                        <button class="btn btn-success w-100" :disabled="!balancedScorecardReady" @click="finishTask">
                            <i class="material-icons align-middle">check</i> Finalizar este proceso
                        </button>
                    </div>
                </div>
            </template>
        </Pages>

        <Alert :title="alert.title"
               :type="alert.type"
               :message="alert.message"
               :show="alert.show"
               :button1="alert.button1"
               @close="alert.show = false"></Alert>

    </div>
</template>
<script>
    import Axios from "axios";

    // models
    import PageModel from "./PageModel";

    // components
    import Pages from "../components/Pages";
    import cell from "../components/BalancedScorecard/perspective";

    export default {
        name: "BalancedScorecard",
        mixins: [ PageModel ],
        components: {
            Pages,
            cell
        },
        data(){
            return {
                perspectives: [],
                frequencies: []
            }
        },
        methods: {
            afterComplete(data){
                this.perspectives = data.perspectives;
                this.frequencies = data.frequencies;
            },
            showError(message){
                this.showAlert({
                    title: "La operación no se pudo completar",
                    message: message,
                    type: "danger"
                })
            },
            showSuccess(message){
                this.showAlert({
                    title: "Operacion completada con exito",
                    message: message,
                    type: "success"
                });
                this.getUsers();
                this.getAreas();
                this.getPage();
            },
            getUsers(){
                let now = new Date();
                let cache = localStorage.getItem('usersList');
                if(cache === undefined || cache === null){
                    Axios.get("/api/users/find", {
                        headers: {
                            Accept: 'application/json',
                            Authorization: 'Bearer ' + localStorage.autenticate_token
                        }
                    }).then(response => {
                        localStorage.setItem('usersList', JSON.stringify({
                            users: response.data,
                            expire: now.getTime() + 150000
                        }));
                    }).catch(error => {
                        console.log(error);
                        this.$emit("error");
                    })
                }else{
                    cache = JSON.parse(cache);
                    if(now.getTime() > cache.expire){
                        console.log("Voy a a quitar userList");
                        localStorage.removeItem('usersList');
                        this.getUsers();
                    }
                }

            },
            getAreas(){
                let now = new Date();
                let cache = localStorage.getItem('areasList');
                console.log("areas in scorecard", cache, now.getTime())
                if(cache === undefined || cache === null){
                    Axios.get("/api/areas/json", {
                        headers: {
                            Accept: 'application/json',
                            Authorization: 'Bearer ' + localStorage.autenticate_token
                        }
                    }).then(response => {
                        console.log("scorecard", response.data);
                        localStorage.setItem('areasList', JSON.stringify({
                            areas: response.data,
                            expire: now.getTime() + 150000
                        }));
                    }).catch(error => {
                        console.log(error);
                        this.$emit("error");
                    })
                }else{
                    cache = JSON.parse(cache);
                    if(now.getTime() > cache.expire){
                        console.log("lo voy a quitar 3", now.getTime())
                        localStorage.removeItem('areasList');
                        this.getAreas();
                    }
                }
            },
        },
        computed: {
            balancedScorecardReady(){
                let notReady = 0;
                for(let index in this.perspectives){
                    for(let i in this.perspectives[index].objectives){
                        for(let y in this.perspectives[index].objectives[i].category.strategic_issues){
                            if(this.perspectives[index].objectives[i].category.strategic_issues[y].balanced_scorecards == null){
                                console.log(this.perspectives[index].objectives[i].category.strategic_issues[y]);
                                notReady += 1;
                            }
                        }
                    }
                }
                console.log("ready", notReady);
                return notReady == 0;
            }
        },
        mounted() {
            this.getUsers();
            this.getAreas();
        }
    }
</script>
