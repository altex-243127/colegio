<template>
    <div>
        <Pages title="Temas estrategicos"
               :page="page"
               :get-page="getPage"
               :authorized="authorized">
            <template slot="body">
                <div class="table-responsive">
                    <table class="table table-hover table-bordered">
                        <thead>
                        <tr>
                            <th>
                                <p>
                                    Tema estrategico
                                </p>
                            </th>
                            <th>
                                <p style="width: 300px">
                                    Estrategias
                                </p>
                            </th>
                            <th>
                                <p>
                                    Ponderación
                                </p>
                            </th>
                            <th>
                                <p style="width:150px">
                                    Perspectiva
                                </p>
                            </th>
                            <th>
                                <p style="width:250px">
                                    Objetivo estrategico
                                </p>
                            </th>
                            <th>
                                <p style="width:250px">
                                    Premisa politica de calidad
                                </p>
                            </th>
                            <th v-if="!page.finalized"></th>
                        </tr>
                        </thead>
                        <tbody>
                        <template v-for="category in categories" v-if="category.strategic_issues.length > 0">
                            <tr>
                                <td :rowspan="objectives[category.id].length" class="align-middle">{{ category.name }}</td>
                                <td :rowspan="objectives[category.id].length" class="align-middle">
                                    <template v-for="strategic in category.strategic_issues">
                                        <div class="border p-2 mb-2">
                                            {{ strategic.strategy.name }}
                                        </div>
                                    </template>
                                </td>
                                <td class="text-center align-middle" :rowspan="objectives[category.id].length">{{ category.weighing }}%</td>
                                <td class="align-middle">
                                    <select class="form-control" v-model="objectives[category.id][0].perspective"  v-if="!page.finalized">
                                        <option v-for="perspective in perspectives" :value="perspective.id">
                                            {{ perspective.name }}
                                        </option>
                                    </select>
                                    <p v-else>{{ getPerspectiveById(objectives[category.id][0].perspective) }}</p>
                                </td>
                                <td class="align-middle">
                                    <textarea rows="2" class="form-control" v-model="objectives[category.id][0].objective" v-if="!page.finalized"></textarea>
                                    <p v-else>{{ objectives[category.id][0].objective }}</p>
                                </td>
                                <td class="align-middle">
                                    <textarea rows="2" class="form-control" v-model="objectives[category.id][0].premise" v-if="!page.finalized"></textarea>
                                    <p v-else>{{ objectives[category.id][0].premise }}</p>
                                </td>
                                <td v-if="!page.finalized">
                                    <p style="width: 100px">
                                        <button type="button" class="btn btn-red w-100" @click="saveObjective(objectives[category.id][0], category)">
                                            Guardar
                                        </button>
                                        <button type="button" class="btn btn-success w-100 mt-1" @click="addObjective(category)" v-if="objectives[category.id].length == 1">
                                            Añadir
                                        </button>
                                    </p>
                                </td>
                            </tr>
                            <template v-for="(objective, key) in objectives[category.id]" v-if="key != 0">
                                <tr>
                                    <td class="align-middle">
                                        <select class="form-control" v-model="objectives[category.id][key].perspective"  v-if="!page.finalized">
                                            <option v-for="perspective in perspectives" :value="perspective.id">
                                                {{ perspective.name }}
                                            </option>
                                        </select>
                                        <p v-else>{{ getPerspectiveById(objectives[category.id][key].perspective) }}</p>
                                    </td>
                                    <td class="align-middle">
                                        <textarea rows="2" class="form-control" v-model="objectives[category.id][key].objective" v-if="!page.finalized"></textarea>
                                        <p v-else>{{ objectives[category.id][key].objective }}</p>
                                    </td>
                                    <td class="align-middle">
                                        <textarea rows="2" class="form-control" v-model="objectives[category.id][key].premise" v-if="!page.finalized"></textarea>
                                        <p v-else>{{ objectives[category.id][key].premise }}</p>
                                    </td>
                                    <td v-if="!page.finalized">
                                        <p style="width: 100px">
                                            <button type="button" class="btn btn-red w-100" @click="saveObjective(objectives[category.id][key], category)">
                                                Guardar
                                            </button>
                                            <button type="button" class="btn btn-success w-100 mt-1" @click="addObjective(category)" v-if="objectives[category.id].length == key+1">
                                                Añadir
                                            </button>
                                        </p>
                                    </td>
                                </tr>
                            </template>
                        </template>
                        </tbody>
                    </table>
                </div>

                <div class="row my-4" v-if="!page.finalized">
                    <div class="col">
                        <button class="btn btn-success w-100" @click="finishTask">
                            <i class="material-icons align-middle">check</i> Finalizar este proceso
                        </button>
                    </div>
                </div>

            </template>
        </Pages>

        <Alert :title="alert.title"
               :type="alert.type"
               :message="alert.message"
               :show="alert.show"
               :button1="alert.button1"
               @close="alert.show = false"></Alert>

    </div>
</template>
<script>
import Axios from "axios";

// models
import PageModel from "./PageModel";

// components
import Pages from "../components/Pages";

export default {
    name: "StrategicIssues",
    mixins: [ PageModel ],
    data(){
        return {
            categories: [],
            perspectives: [],
            objectives: []
        }
    },
    components: {
        Pages
    },
    methods: {
        afterComplete(data){
            this.categories = data.categories;
            this.perspectives = data.perspectives;
            for(let index in this.categories){
                this.$set(this.objectives, this.categories[index].id, []);
                if(this.categories[index].objectives.length > 0){
                    for(let i in this.categories[index].objectives){
                        this.objectives[this.categories[index].id].push({
                            "perspective" : this.categories[index].objectives[i].perspective_id,
                            "objective": this.categories[index].objectives[i].objective,
                            "premise": this.categories[index].objectives[i].premise,
                            "objective_id": this.categories[index].objectives[i].id
                        });
                    }
                }else{
                    this.objectives[this.categories[index].id].push({
                        "perspective" : 0,
                        "objective": "",
                        "premise": "",
                    });
                }
            }
        },
        validateObjectivesByCategory(category){
            let errors = this.objectives[category.id].filter(item => {
               return item.objective == '' || item.premise == '' || item.premise == 0;
            });
            return errors.length == 0;
        },
        getPerspectiveById(id){
            for(let index in this.perspectives){
                if(this.perspectives[index].id == id){
                    return this.perspectives[index].name;
                }
            }
        },
        addObjective(category){
            if(this.validateObjectivesByCategory(category)){
                this.objectives[category.id].push({
                    "perspective" : 0,
                    "objective": "",
                    "premise": "",
                });
            }else{
                this.showAlert({
                    title: "Validación",
                    message: "Debe rellenar todos los campos antes de añadir otro objetivo",
                    type: "danger"
                })
            }
        },
        saveObjective(objective, category){
            Axios.post("/api/" + this.$options.name + '/saveObjective',
                Object.assign(objective, { category: category.id })
                , this.axiosConfig)
                .then(response => {
                    this.showAlert({
                        title: "Operación culminada con éxito",
                        message: response.data.message,
                        type: "success"
                    });
                    this.page.finalized = true;
                    this.getPage();
                }).catch(error => {
                    this.showAlert({
                        title: "La operación no se pudo completar",
                        message: error.response.data.message,
                        type: "danger"
                    });
                })
        }
    }
}
</script>
