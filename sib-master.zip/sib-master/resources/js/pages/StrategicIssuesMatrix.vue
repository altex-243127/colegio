<template>
    <div>
        <Pages title="Matriz de cobertura de los temas estrategicos"
               :page="page"
               :get-page="getPage"
               :authorized="authorized">
            <template slot="body">
                <div class="row" v-if="!page.finalized">
                    <div class="col">
                        <router-link to="/strategicIssuesMatrixScore" class="btn btn-red" >
                            Calificar
                        </router-link>
                    </div>

                    <div class="col text-right" v-if="!onlyScore">
                        <button type="button" class="btn btn-red" @click="modalRequestShow = true">
                            Enviar solicitudes de revisión
                        </button>
                    </div>
                </div>
                <div class="row my-4">
                    <div class="col">
                        <div class="table-responsive">
                            <table class="table table-hover table-bordered">
                                <tr>
                                    <th rowspan="2">
                                        <div class="title-table-dofa" style="width: 250px">
                                            <span class="first">&nbsp</span>
                                            <hr>
                                            <span class="last">Temas estrategicos</span>
                                        </div>
                                    </th>
                                    <th :colspan="strategicIssues.length" class="text-center alert-primary">Dofa</th>
                                    <th :colspan="interestGroups.length" class="text-center alert-primary">Grupos de interes</th>
                                    <th colspan="3" class="text-center alert-primary">Estrategia</th>
                                    <th :rowspan="strategicIssuesCategories.length + 2"></th>
                                    <th class="alert-info align-bottom" rowspan="2">
                                        <div style="width: 100px" @mouseenter="showTooltip" @mouseleave="hideTooltip">
                                            <p class="m-0">
                                                Total positivo
                                            </p>
                                            <div class="tooltip">
                                                Total positivo
                                            </div>
                                        </div>
                                    </th>
                                    <th class="alert-warning align-bottom" rowspan="2">
                                        <div style="width: 100px" @mouseenter="showTooltip" @mouseleave="hideTooltip">
                                            <p class="m-0">
                                                Total negativo
                                            </p>
                                            <div class="tooltip">
                                                Total negativo
                                            </div>
                                        </div>
                                    </th>
                                    <th class="alert-success align-bottom" rowspan="2">
                                        <div style="width: 100px" @mouseenter="showTooltip" @mouseleave="hideTooltip">
                                            <p class="m-0">
                                                Elección
                                            </p>
                                            <div class="tooltip">
                                                Elección
                                            </div>
                                        </div>
                                    </th>
                                    <th class="alert-primary align-bottom" rowspan="2">
                                        <div style="width: 100px" @mouseenter="showTooltip" @mouseleave="hideTooltip">
                                            <p class="m-0">
                                                Ponderación
                                            </p>
                                            <div class="tooltip">
                                                Ponderación
                                            </div>
                                        </div>
                                    </th>
                                </tr>
                                <tr>
                                    <template v-for="data in strategicIssues">
                                        <th class="align-middle">
                                            <div style="width: 100px" @mouseenter="showTooltip" @mouseleave="hideTooltip">
                                                <p class="m-0">
                                                    {{ data.strategy.name }}
                                                </p>
                                                <div class="tooltip">
                                                    {{ data.strategy.name }}
                                                </div>
                                            </div>
                                        </th>
                                    </template>
                                    <template v-for="data in interestGroups">
                                        <th class="align-middle">
                                            <div style="width: 100px" @mouseenter="showTooltip" @mouseleave="hideTooltip">
                                                <p style="width: 100px" class="m-0">
                                                    {{ data.name }}
                                                </p>
                                                <div class="tooltip">
                                                    {{ data.name }}
                                                </div>
                                            </div>
                                        </th>
                                    </template>
                                    <th class="align-middle">
                                        <div style="width: 100px" @mouseenter="showTooltip" @mouseleave="hideTooltip">
                                            <p style="width: 100px" class="m-0">
                                                Misión
                                            </p>
                                            <div class="tooltip">
                                                Misión
                                            </div>
                                        </div>
                                    </th>
                                    <th class="align-middle">
                                        <div style="width: 100px" @mouseenter="showTooltip" @mouseleave="hideTooltip">
                                            <p style="width: 100px" class="m-0">
                                                Visión
                                            </p>
                                            <div class="tooltip">
                                                Visión
                                            </div>
                                        </div>
                                    </th>
                                    <th class="align-middle">
                                        <div style="width: 100px" @mouseenter="showTooltip" @mouseleave="hideTooltip">
                                            <p style="width: 100px" class="m-0">
                                                Politica de calidad
                                            </p>
                                            <div class="tooltip">
                                                Politica de calidad
                                            </div>
                                        </div>
                                    </th>
                                </tr>
                                <template v-for="category in strategicIssuesCategories">
                                    <tr>
                                        <th>{{ category.name }}</th>
                                        <template v-for="data in strategicIssues">
                                            <th class="align-middle text-center">
                                                {{ getScoreByCategory(data, category)}}
                                            </th>
                                        </template>
                                        <template v-for="data in interestGroups">
                                            <th class="align-middle text-center">
                                                {{ getScoreByCategory(data, category)}}
                                            </th>
                                        </template>
                                        <template v-for="data in strategies">
                                            <th class="align-middle text-center">
                                                {{ getScoreByCategory(data, category)}}
                                            </th>
                                        </template>
                                        <th class="text-center alert-info">
                                            {{ getTotalPositiveByRow(category) }}
                                        </th>
                                        <th class="text-center alert-warning">
                                            {{ getTotalNegativeByRow(category) }}
                                        </th>
                                        <th class="text-center alert-success">
                                            {{ getTotalByRow(category) }}
                                        </th>
                                        <th class="text-center alert-primary">
                                            {{ weights[category.id] }}
                                        </th>
                                    </tr>
                                </template>
                                <tr>
                                    <th :colspan="strategies.length + interestGroups.length + strategicIssues.length + 2"></th>
                                    <th class="text-center alert-info">
                                        {{ getTotalPositiveRows() }}
                                    </th>
                                    <th class="text-center alert-warning">
                                        {{ getTotalNegativeRows() }}
                                    </th>
                                    <th class="text-center alert-success">
                                        {{ getTotalRows() }}
                                    </th>
                                    <th rowspan="4" class="alert-primary"></th>
                                </tr>
                                <tr class="alert-info">
                                    <th>
                                        <div class="title-table-dofa" style="width: 250px">
                                            Total Positivos
                                        </div>
                                    </th>
                                    <template v-for="data in strategicIssues">
                                        <th class="align-middle text-center">
                                            {{ getTotalPositiveByCol(data) }}
                                        </th>
                                    </template>
                                    <template v-for="data in interestGroups">
                                        <th class="align-middle text-center">
                                            {{ getTotalPositiveByCol(data) }}
                                        </th>
                                    </template>
                                    <template v-for="data in strategies">
                                        <th class="align-middle text-center">
                                            {{ getTotalPositiveByCol(data) }}
                                        </th>
                                    </template>
                                    <th class="align-middle text-center">
                                        {{ getTotalPositiveCols() }}
                                    </th>
                                    <th rowspan="3" colspan="3" class="text-center align-middle">
                                        {{ setFormat((getTotalCols() * 100) / getTotalPositiveCols()) + "%" }}
                                    </th>
                                </tr>
                                <tr class="alert-warning">
                                    <th>
                                        <div class="title-table-dofa" style="width: 250px">
                                            Total Negativos
                                        </div>
                                    </th>
                                    <template v-for="data in strategicIssues">
                                        <th class="align-middle text-center">
                                            {{ getTotalNegativeByCol(data) }}
                                        </th>
                                    </template>
                                    <template v-for="data in interestGroups">
                                        <th class="align-middle text-center">
                                            {{ getTotalNegativeByCol(data) }}
                                        </th>
                                    </template>
                                    <template v-for="data in strategies">
                                        <th class="align-middle text-center">
                                            {{ getTotalNegativeByCol(data) }}
                                        </th>
                                    </template>

                                    <th class="align-middle text-center">
                                        {{ getTotalNegativeCols() }}
                                    </th>
                                </tr>
                                <tr class="alert-success">
                                    <th>
                                        <div class="title-table-dofa" style="width: 250px">
                                            Cobertura
                                        </div>
                                    </th>
                                    <template v-for="data in strategicIssues">
                                        <th class="align-middle text-center">
                                            {{ getTotalByCol(data) }}
                                        </th>
                                    </template>
                                    <template v-for="data in interestGroups">
                                        <th class="align-middle text-center">
                                            {{ getTotalByCol(data) }}
                                        </th>
                                    </template>
                                    <template v-for="data in strategies">
                                        <th class="align-middle text-center">
                                            {{ getTotalByCol(data) }}
                                        </th>
                                    </template>

                                    <th class="align-middle text-center">
                                        {{ getTotalCols() }}
                                    </th>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="row" v-if="!page.finalized && !onlyScore">
                    <div class="col">
                        <button class="btn btn-success w-100" @click="finishTask" :disabled="!allWeightsReady">
                            <i class="material-icons align-middle">check</i> Finalizar este proceso
                        </button>
                    </div>
                </div>
            </template>
        </Pages>

        <StrategicIssuesMatrixRequest :show="modalRequestShow"
                     :users="usersCanReview"
                     @showAlert="showAlert($event)"
                     @awaiting="awaiting"
                     @resume="resume"
                     @close="modalRequestShow = false"></StrategicIssuesMatrixRequest>

        <Alert :title="alert.title"
               :type="alert.type"
               :message="alert.message"
               :show="alert.show"
               :button1="alert.button1"
               @close="alert.show = false"></Alert>
    </div>
</template>
<script>
import Axios from 'axios';

// models
import PageModel from "./PageModel";

// components
import Pages from "../components/Pages";
import Button from "../components/Alert/Button"
import StrategicIssuesMatrixRequest from "../components/StrategicIssuesMatrixRequest/index";

export default {
    name: "StrategicIssuesMatrix",
    mixins: [ PageModel ],
    data(){
        return {
            strategicIssues: [],
            strategicIssuesCategories: [],
            interestGroups: [],
            strategies: [],
            weights: [],
            usersCanReview: [],
            modalRequestShow: false,
            onlyScore: false,
        }
    },
    computed: {
        allWeightsReady(){
            let errors = this.weights.filter(item => {
                return item == null;
            });
            return errors.length == 0;
        },
    },
    methods: {
        afterComplete(data){
            this.strategicIssues = data.strategicIssues;
            this.strategicIssuesCategories = data.strategicIssuesCategories;
            this.interestGroups = data.interestGroups;
            this.strategies = data.strategies;
            this.usersCanReview = data.usersCanReview;
            this.onlyScore = data.onlyScore;
            this.setWeights();
        },
        showTooltip(e){
            const children = e.target.children;
            for(let index in children){
                if(children[index].className != undefined){
                    if(children[index].className.indexOf("tooltip") >= 0){
                        children[index].classList.add("show");
                    }
                }
            }
        },
        hideTooltip(e){
            const children = e.target.children;
            for(let index in children){
                if(children[index].className != undefined){
                    if(children[index].className.indexOf("tooltip") >= 0){
                        children[index].classList.remove("show");
                    }
                }
            }
        },
        setWeights(){
            for(let index in this.strategicIssuesCategories){
                if(this.getTotalRows() != 0) {
                    this.$set(this.weights, this.strategicIssuesCategories[index].id, this.setFormat((this.getTotalByRow(this.strategicIssuesCategories[index]) * 100) / this.getTotalRows()));
                }else{
                    this.$set(this.weights, this.strategicIssuesCategories[index].id, null);
                }
            }
        },
        finishTask(){
            if(this.confirmFinish){
                Axios.post("/api/" + this.$options.name + "/finish", {
                    weights: this.weights
                }, this.axiosConfig)
                    .then(response => {
                        this.showAlert({
                            message: response.data.message,
                            type: "success"
                        });
                        this.page.finalized = true;
                    }).catch(error => {
                    this.showAlert({
                        title: "La operación no se pudo completar",
                        message: error.response.data.message,
                        type: "danger"
                    });
                })
            }else{
                let btn = new Button();
                btn.setText("Finalizar");
                btn.setOnClick(() => {
                    this.confirmFinish = true;
                    this.finishTask();
                })

                this.showAlert({
                    title: "¿Esta seguro?",
                    message: "¿Desea terminar este proceso?",
                    type: "info",
                    button: btn
                })
            }
        },
        getScoreByCategory(data, category){
            for(let index in data.score){
                if(data.score[index].category_id ==  category.id){
                    return parseInt(data.score[index].sum) / data.score[index].count;
                }
            }
        },
        getTotalPositiveByCol(data){
            let total = 0;
            for(let index in data.score){
                let result = parseInt(data.score[index].sum) / data.score[index].count
                total += result >= 0 ? result : 0;
            }
            return total;
        },
        getTotalNegativeByCol(data){
            let total = 0;
            for(let index in data.score){
                let result = parseInt(data.score[index].sum) / data.score[index].count
                total += result < 0 ? result : 0;
            }
            return total;
        },
        getTotalByCol(data){
            let total = 0;
            for(let index in data.score){
                let result = parseInt(data.score[index].sum) / data.score[index].count
                total += result;
            }
            return total;
        },
        getTotalPositiveCols(){
            let total = 0;
            for(let index in this.strategicIssues){
                total += this.getTotalPositiveByCol(this.strategicIssues[index]);
            }
            for(let index in this.strategies){
                total += this.getTotalPositiveByCol(this.strategies[index]);
            }
            for(let index in this.interestGroups){
                total += this.getTotalPositiveByCol(this.interestGroups[index]);
            }
            return total;
        },
        getTotalNegativeCols(){
            let total = 0;
            for(let index in this.strategicIssues){
                total += this.getTotalNegativeByCol(this.strategicIssues[index]);
            }
            for(let index in this.strategies){
                total += this.getTotalNegativeByCol(this.strategies[index]);
            }
            for(let index in this.interestGroups){
                total += this.getTotalNegativeByCol(this.interestGroups[index]);
            }
            return total;
        },
        getTotalCols(){
            let total = 0;
            for(let index in this.strategicIssues){
                total += this.getTotalByCol(this.strategicIssues[index]);
            }
            for(let index in this.strategies){
                total += this.getTotalByCol(this.strategies[index]);
            }
            for(let index in this.interestGroups){
                total += this.getTotalByCol(this.interestGroups[index]);
            }
            return total;
        },
        getTotalPositiveByRow(category){
            let total = 0;
            for(let index in this.strategicIssues){
                for(let i in this.strategicIssues[index].score){
                    if(this.strategicIssues[index].score[i].category_id == category.id){
                        let result = parseInt(this.strategicIssues[index].score[i].sum) / this.strategicIssues[index].score[i].count
                        total += result >= 0 ? result : 0;
                    }
                }
            }
            for(let index in this.strategies){
                for(let i in this.strategies[index].score){
                    if(this.strategies[index].score[i].category_id == category.id){
                        let result = parseInt(this.strategies[index].score[i].sum) / this.strategies[index].score[i].count
                        total += result >= 0 ? result : 0;
                    }
                };
            }
            for(let index in this.interestGroups){
                for(let i in this.interestGroups[index].score){
                    if(this.interestGroups[index].score[i].category_id == category.id){
                        let result = parseInt(this.interestGroups[index].score[i].sum) / this.interestGroups[index].score[i].count
                        total += result >= 0 ? result : 0;
                    }
                };
            }
            return total;
        },
        getTotalNegativeByRow(category){
            let total = 0;
            for(let index in this.strategicIssues){
                for(let i in this.strategicIssues[index].score){
                    if(this.strategicIssues[index].score[i].category_id == category.id){
                        let result = parseInt(this.strategicIssues[index].score[i].sum) / this.strategicIssues[index].score[i].count
                        total += result < 0 ? result : 0;
                    }
                }
            }
            for(let index in this.strategies){
                for(let i in this.strategies[index].score){
                    if(this.strategies[index].score[i].category_id == category.id){
                        let result = parseInt(this.strategies[index].score[i].sum) / this.strategies[index].score[i].count
                        total += result < 0 ? result : 0;
                    }
                };
            }
            for(let index in this.interestGroups){
                for(let i in this.interestGroups[index].score){
                    if(this.interestGroups[index].score[i].category_id == category.id){
                        let result = parseInt(this.interestGroups[index].score[i].sum) / this.interestGroups[index].score[i].count
                        total += result < 0 ? result : 0;
                    }
                };
            }
            return total;
        },
        getTotalByRow(category){
            let total = 0;
            for(let index in this.strategicIssues){
                for(let i in this.strategicIssues[index].score){
                    if(this.strategicIssues[index].score[i].category_id == category.id){
                        let result = parseInt(this.strategicIssues[index].score[i].sum) / this.strategicIssues[index].score[i].count
                        total += result;
                    }
                }
            }
            for(let index in this.strategies){
                for(let i in this.strategies[index].score){
                    if(this.strategies[index].score[i].category_id == category.id){
                        let result = parseInt(this.strategies[index].score[i].sum) / this.strategies[index].score[i].count
                        total += result;
                    }
                };
            }
            for(let index in this.interestGroups){
                for(let i in this.interestGroups[index].score){
                    if(this.interestGroups[index].score[i].category_id == category.id){
                        let result = parseInt(this.interestGroups[index].score[i].sum) / this.interestGroups[index].score[i].count
                        total += result;
                    }
                };
            }
            return total;
        },
        getTotalPositiveRows(){
            let total = 0;
            for(let index in this.strategicIssuesCategories){
                total += this.getTotalPositiveByRow(this.strategicIssuesCategories[index]);
            }
            return total;
        },
        getTotalNegativeRows(){
            let total = 0;
            for(let index in this.strategicIssuesCategories){
                total += this.getTotalNegativeByRow(this.strategicIssuesCategories[index]);
            }
            return total;
        },
        getTotalRows(){
            let total = 0;
            for(let index in this.strategicIssuesCategories){
                total += this.getTotalByRow(this.strategicIssuesCategories[index]);
            }
            return total;
        },
        setFormat(number){
            return new Intl.NumberFormat("es-CO", {maximumSignificantDigits: 3}).format(number);
        }
    },
    components: {
        Pages,
        StrategicIssuesMatrixRequest
    }
}
</script>

<style>
    .title-table-dofa hr{
        transform: rotate(16deg);
    }
    .title-table-dofa span.first{
        display: block;
        text-align: right;
        padding-right: 15%;
    }
    .title-table-dofa span.last{
        display: block;
        text-align: left;
        padding-left: 15%;
    }
    th{
        position: relative;
    }
    th p{
        word-break: break-all;
        white-space: nowrap;
        overflow: hidden;
        cursor:pointer;
    }
    .tooltip {
        background-color: rgba(0, 0, 0, 0.5);
        color: #fff;
        width: 200px;
        padding: 5px;
    }
</style>
