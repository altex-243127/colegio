<template>
    <div>
        <Pages title="Aprobación de presupuesto"
               :page="page"
               :get-page="getPage"
               :authorized="authorized">
            <template slot="body">
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                        <tr>
                            <th>
                                Área
                            </th>
                            <th>Ver presupuesto</th>
                            <th>Valor solicitado</th>
                            <th>Estado</th>
                        </tr>
                        </thead>
                        <tbody>
                        <template v-for="area in areas">
                            <tr>
                                <td>{{ area.name }}</td>
                                <td>
                                    <button class="btn btn-red" type="button" @click="showDetailByArea(area)">
                                        Ver presupuesto
                                    </button>
                                </td>
                                <td class="text-right">
                                    {{ new Intl.NumberFormat().format(getTotalByArea(area)) }}
                                </td>
                                <td>
                                    <button type="button" class="btn btn-success" @click="approve(area)" v-if="!area.processed">
                                        Aprobar
                                    </button>
                                    <button type="button" class="btn btn-red" @click="refuse(area)" v-if="!area.processed">
                                        Rechazar
                                    </button>
                                </td>
                            </tr>
                        </template>
                        </tbody>
                    </table>
                </div>
                <div class="row">
                    <div class="col-12 text-center">
                        <p>Total presupuesto anual solicitado {{ new Intl.NumberFormat().format(getTotal()) }}</p>
                    </div>
                </div>

                <div class="row my-3" v-if="!page.finalized">
                    <div class="col-12">
                        <button class="btn btn-success w-100" :disabled="!allProcesses" @click="finishTask">
                            <i class="material-icons align-middle">check</i> Finalizar este proceso
                        </button>
                    </div>
                </div>

                <hr>

                <h4>Actividades de adición</h4>

                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                        <tr>
                            <th>
                                Área
                            </th>
                            <th>Ver presupuesto</th>
                            <th>Valor solicitado</th>
                            <th>Estado</th>
                        </tr>
                        </thead>
                        <tbody>
                        <template v-for="area in areasExtras">
                            <tr>
                                <td>{{ area.name }}</td>
                                <td>
                                    <button class="btn btn-red" type="button" @click="showDetailByArea(area)">
                                        Ver presupuesto
                                    </button>
                                </td>
                                <td class="text-right">
                                    {{ new Intl.NumberFormat().format(getTotalByArea(area)) }}
                                </td>
                                <td>
                                    <button type="button" class="btn btn-success" @click="approveExtra(area)" v-if="!area.processed">
                                        Aprobar
                                    </button>
                                    <button type="button" class="btn btn-red" @click="refuseExtra(area)" v-if="!area.processed">
                                        Rechazar
                                    </button>
                                </td>
                            </tr>
                        </template>
                        </tbody>
                    </table>
                </div>

            </template>
        </Pages>

        <DetailBudget :show="showDetail"
                      :area="areaDetail"
                      @close="showDetail = false"
                      @success="detailSuccess($event)"
                      @error="detailError($event)"></DetailBudget>


        <Alert :title="alert.title"
               :type="alert.type"
               :message="alert.message"
               :show="alert.show"
               :button1="alert.button1"
               @close="alert.show = false"></Alert>

    </div>
</template>
<script>
    import Axios from "axios";

    // models
    import PageModel from "./PageModel";

    // components
    import Pages from "../components/Pages";
    import DetailBudget from "../components/Budget/DetailByArea"

    export default {
        name: "Budget/Approve",
        mixins: [ PageModel ],
        components: {
            Pages,
            DetailBudget
        },
        data(){
            return {
                areas: [],
                areasExtras: [],
                showDetail: false,
                areaDetail: {}
            }
        },
        methods: {
            afterComplete(data){
                this.areas = data.areas;
                this.areasExtras = data.areasExtras;
            },
            showDetailByArea(area){
                this.showDetail = true;
                this.areaDetail = area;
            },
            getTotalByArea(area){
                let total = 0;
                if(area.budgets != undefined){
                    area.budgets.map(budget => {
                        budget.activities.map(activity => {
                            activity.resources.map(resource =>{
                                total += resource.quantity * resource.value;
                            })
                        })
                    })
                }
                if(area.extras != undefined){
                    area.extras.map(budget => {
                        budget.activities.map(activity => {
                            activity.resources.map(resource =>{
                                total += resource.quantity * resource.value;
                            })
                        })
                    })
                }
                return total;
            },
            getTotal(){
                let total = 0;

                this.areas.map(area => {
                    total += this.getTotalByArea(area);
                })

                return total;
            },
            setStateBudget(){
                this.areas.map((area, index) => {
                    let processed = true;
                    area.budgets.map(budget => {
                        if(budget.state == 0){
                            processed = false;
                        }
                    });
                    this.$set(this.areas[index], "processed", processed);
                });
                this.areasExtras.map((area, index) => {
                    let processed = true;
                    area.extras.map(budget => {
                        if(budget.state == 0){
                            processed = false;
                        }
                    });
                    this.$set(this.areasExtras[index], "processed", processed);
                });
            },
            approve(area){
                Axios.post("/api/Budget/Approve/Area/" + area.id, {}, this.axiosConfig)
                    .then(response => {
                        this.showAlert({
                            title: "La operación se completo con éxito",
                            message: response.data.message,
                            type: "success"
                        })
                        this.getPage();
                    })
                    .catch(error => {
                        this.showAlert({
                            title: "La operación no se pudo completar",
                            message: error.response.data.message,
                            type: "danger"
                        })
                    })
            },
            refuse(area){
                Axios.post("/api/Budget/Refuse/Area/" + area.id, {}, this.axiosConfig)
                    .then(response => {
                        this.showAlert({
                            title: "La operación se completo con éxito",
                            message: response.data.message,
                            type: "success"
                        })
                        this.getPage();
                    })
                    .catch(error => {
                        this.showAlert({
                            title: "La operación no se pudo completar",
                            message: error.response.data.message,
                            type: "danger"
                        })
                    })
            },
            approveExtra(area){
                Axios.post("/api/Budget/ApproveExtra/Area/" + area.id, {}, this.axiosConfig)
                    .then(response => {
                        this.showAlert({
                            title: "La operación se completo con éxito",
                            message: response.data.message,
                            type: "success"
                        })
                        this.getPage();
                    })
                    .catch(error => {
                        this.showAlert({
                            title: "La operación no se pudo completar",
                            message: error.response.data.message,
                            type: "danger"
                        })
                    })
            },
            refuseExtra(area){
                Axios.post("/api/Budget/RefuseExtra/Area/" + area.id, {}, this.axiosConfig)
                    .then(response => {
                        this.showAlert({
                            title: "La operación se completo con éxito",
                            message: response.data.message,
                            type: "success"
                        })
                        this.getPage();
                    })
                    .catch(error => {
                        this.showAlert({
                            title: "La operación no se pudo completar",
                            message: error.response.data.message,
                            type: "danger"
                        })
                    })
            },
            detailSuccess(data){
                this.showAlert(data);
                this.getPage();
            },
            detailError(data){
                this.showAlert(data);
            }
        },
        computed: {
            allProcesses(){
                return this.areas.filter(item => {
                    return item.processed;
                }).length == this.areas.length
            }
        },
        watch: {
            areas(value){
                this.setStateBudget();
            }
        },
        mounted() {
            this.setStateBudget();
        }
    }
</script>

<style>
#DetailBudget{
    overflow: auto !important;
}
</style>
