@extends("mail.layout")

@section("body")
    <p style="text-align: center; padding: 20px;">
        Usted ha sido seleccionado para calificar los factores MATRIZ DE COBERTURA DE LOS TEMAS ESTRATEGICOS puede hacerlo ingresando en el enlace
    </p>
    <p style="text-align: center;">
        <a href="{{ url("/") }}" target="_blank" style="background-color: #ff0125;color: #fff;padding: 10px;width: 200px;display: inline-block;">
            Calificar
        </a>
    </p>
@endsection
