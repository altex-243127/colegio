<?php

return [
    "canNotUserSee" => "El usuario no esta autorizado para visualizar este modulo"
];
