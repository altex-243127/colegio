<?php

return [
    "failedUpdate" => "No fue posible actualizar el usuario",
    "successUpdate" => "El usuario fue actualizado con exito"
];
