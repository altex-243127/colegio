<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ModuleActionUser extends Model
{
    //
}
