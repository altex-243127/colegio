<?php

namespace App;

class Utils{
    static function prefix(){
        return session("year", date("Y")) . "_";
    }
}
