<?php

namespace App\Http\Controllers;

use App\Models\CenterCost;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;

class DashboardController extends Controller
{

    public function PresupuestoAprobado(){
        dd("s");
    }

}
