<?php

namespace App;

use App\Models\Model;

class StrategicIssuesMatrixScore extends Model
{
    //
}
