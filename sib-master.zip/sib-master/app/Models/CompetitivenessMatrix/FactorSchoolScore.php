<?php

namespace App\Models\CompetitivenessMatrix;

use App\Models\Model;

class FactorSchoolScore extends Model
{
    //
}
