<?php

namespace App\Models\InterestGroups;

use App\Models\Model;

class Gestion extends Model
{
    protected $table = "gestion_interest_groups_needs";
}
