<?php

namespace App\Models\StrategicIssues;

use App\Models\Model;

class StrategicIndicator extends Model
{
    //
}
