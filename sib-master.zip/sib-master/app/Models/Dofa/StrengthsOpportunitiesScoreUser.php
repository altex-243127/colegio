<?php

namespace App\Models\Dofa;

use App\Models\Model;

class StrengthsOpportunitiesScoreUser extends Model
{
    //
}
