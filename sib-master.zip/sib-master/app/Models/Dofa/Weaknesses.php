<?php

namespace App\Models\Dofa;

use App\Models\Model;

class Weaknesses extends Model
{
    protected $table = "dofa_weaknesses";
}
