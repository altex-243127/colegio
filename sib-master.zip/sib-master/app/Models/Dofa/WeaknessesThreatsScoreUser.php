<?php

namespace App\Models\Dofa;

use App\Models\Model;

class WeaknessesThreatsScoreUser extends Model
{
    //
}
