<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ModuleAction extends Model
{
    //
}
